<?php
$lang = isset($_GET['lang']) && $_GET['lang'] == 'en' ? 'en' : 'ar';
if ($lang == 'en') {
    include 'includes/header_en.php';
} else {
    include 'includes/header.php';
}

$slug = trim($_GET['slug'] ?? '');
$page = null;

if ($slug !== '') {
    $stmt = $pdo->prepare("SELECT * FROM custom_pages WHERE slug = ? AND is_active = 1 LIMIT 1");
    $stmt->execute([$slug]);
    $page = $stmt->fetch();
}

// تحديد المحتوى حسب اللغة
if ($page) {
    $title = ($lang == 'en' && !empty($page['title_en'])) ? $page['title_en'] : $page['title'];
    $meta = ($lang == 'en' && !empty($page['meta_description_en'])) ? $page['meta_description_en'] : $page['meta_description'];
    $content = ($lang == 'en' && !empty($page['content_en'])) ? $page['content_en'] : $page['content'];
}
?>

<section class="py-5 bg-light border-bottom">
    <div class="container text-center">
        <h1 class="fw-bold text-danger mb-3"><?php echo $page ? htmlspecialchars($title) : ($lang == 'en' ? 'Page Not Available' : 'الصفحة غير متاحة'); ?></h1>
        <p class="lead text-muted mb-0"><?php echo $page ? htmlspecialchars($meta ?: ($lang == 'en' ? 'Custom page added from control panel.' : 'صفحة مخصصة تمت إضافتها من لوحة التحكم.')) : ($lang == 'en' ? 'Sorry, the page you are looking for does not exist or is currently disabled.' : 'عذراً، الصفحة التي تبحث عنها غير موجودة أو تم إيقافها حالياً.'); ?></p>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="bg-white shadow-sm rounded-4 p-4 p-lg-5 border">
                    <?php if ($page): ?>
                        <div class="custom-page-content" style="line-height: 2; font-size: 1.08rem; <?php echo $lang == 'en' ? 'text-align: justify;' : ''; ?>">
                            <?php echo $content; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-file-circle-xmark text-danger" style="font-size: 3rem;"></i>
                            <h3 class="fw-bold mt-3"><?php echo $lang == 'en' ? 'This page does not exist' : 'هذه الصفحة غير موجودة'; ?></h3>
                            <p class="text-muted mb-4"><?php echo $lang == 'en' ? 'You can return to the home page or choose another section from the top menu.' : 'يمكنك العودة إلى الصفحة الرئيسية أو اختيار قسم آخر من القائمة العلوية.'; ?></p>
                            <a href="index.php?lang=<?php echo $lang; ?>" class="btn btn-danger px-4"><?php echo $lang == 'en' ? 'Back to Home' : 'العودة للرئيسية'; ?></a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
if ($lang == 'en') {
    include 'includes/footer_en.php';
} else {
    include 'includes/footer.php';
}
?>
