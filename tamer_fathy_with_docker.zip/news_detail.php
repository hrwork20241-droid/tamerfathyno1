<?php
include 'includes/db.php';

// الحصول على معرف الخبر من الرابط
$news_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// تحديد اللغة من الرابط أو من الجلسة
$lang = isset($_GET['lang']) ? $_GET['lang'] : (isset($_COOKIE['site_lang']) ? $_COOKIE['site_lang'] : 'ar');

if ($news_id <= 0) {
    header("Location: index.php");
    exit;
}

// جلب بيانات الخبر
$stmt = $pdo->prepare("SELECT * FROM news_ticker WHERE id = ?");
$stmt->execute([$news_id]);
$news = $stmt->fetch();

if (!$news) {
    header("Location: index.php");
    exit;
}

// تحديد المحتوى والعنوان حسب اللغة
if ($lang == 'en') {
    $title = $news['title_en'] ?? $news['title_ar'];
    $content = $news['content_en'] ?? $news['content_ar'] ?? '';
} else {
    $title = $news['title_ar'];
    $content = $news['content_ar'] ?? '';
}

// إذا لم يكن هناك محتوى، عرض رسالة
if (empty($content)) {
    $content = '<p>لا يوجد محتوى متاح لهذا الخبر</p>';
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang == 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($title); ?> - تامر فتحي</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.<?php echo $lang == 'ar' ? 'rtl' : 'min'; ?>.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #f8f9fa; }
        .navbar { background: linear-gradient(135deg, #cc0000 0%, #8b0000 100%); box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .navbar-brand { font-weight: bold; font-size: 1.5rem; color: #fff !important; }
        .navbar a { color: #fff !important; margin: 0 10px; transition: 0.3s; }
        .navbar a:hover { color: #ffd700 !important; }
        .breadcrumb { background-color: #f0f0f0; padding: 15px 0; margin-bottom: 30px; }
        .news-container { max-width: 900px; margin: 0 auto; }
        .news-header { background: linear-gradient(135deg, #cc0000 0%, #8b0000 100%); color: #fff; padding: 40px 20px; border-radius: 10px; margin-bottom: 30px; }
        .news-header h1 { font-size: 2.5rem; font-weight: bold; margin-bottom: 15px; }
        .news-meta { font-size: 0.9rem; opacity: 0.9; }
        .news-content { background: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); line-height: 1.8; }
        .news-content img { max-width: 100%; height: auto; border-radius: 8px; margin: 20px 0; }
        .back-btn { margin-bottom: 20px; }
        .back-btn a { color: #cc0000; text-decoration: none; font-weight: bold; }
        .back-btn a:hover { text-decoration: underline; }
        .footer { background: #2c3e50; color: #fff; padding: 30px 0; margin-top: 50px; text-align: center; }
        .lang-switch { position: absolute; top: 20px; left: 20px; }
        .lang-switch a { color: #fff; text-decoration: none; margin: 0 10px; padding: 5px 10px; background: rgba(0,0,0,0.2); border-radius: 5px; }
        .lang-switch a:hover { background: rgba(0,0,0,0.4); }
    </style>
</head>
<body>
<!-- شريط اللغة -->
<div class="lang-switch">
    <a href="news_detail.php?id=<?php echo $news_id; ?>&lang=ar" class="<?php echo $lang == 'ar' ? 'active' : ''; ?>">العربية</a>
    <a href="news_detail.php?id=<?php echo $news_id; ?>&lang=en" class="<?php echo $lang == 'en' ? 'active' : ''; ?>">English</a>
</div>

<!-- شريط التنقل -->
<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">تامر فتحي</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php"><?php echo $lang == 'ar' ? 'الرئيسية' : 'Home'; ?></a></li>
                <li class="nav-item"><a class="nav-link" href="index.php#programs"><?php echo $lang == 'ar' ? 'البرامج' : 'Programs'; ?></a></li>
                <li class="nav-item"><a class="nav-link" href="index.php#news"><?php echo $lang == 'ar' ? 'الأخبار' : 'News'; ?></a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- المحتوى الرئيسي -->
<div class="container news-container mt-5">
    <!-- الفتات -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><?php echo $lang == 'ar' ? 'الرئيسية' : 'Home'; ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo htmlspecialchars($title); ?></li>
        </ol>
    </nav>

    <!-- زر العودة -->
    <div class="back-btn">
        <a href="index.php#news"><i class="fas fa-arrow-<?php echo $lang == 'ar' ? 'right' : 'left'; ?>"></i> <?php echo $lang == 'ar' ? 'العودة إلى الأخبار' : 'Back to News'; ?></a>
    </div>

    <!-- رأس الخبر -->
    <div class="news-header">
        <h1><?php echo htmlspecialchars($title); ?></h1>
        <div class="news-meta">
            <i class="fas fa-calendar-alt"></i> <?php echo date('d/m/Y', strtotime($news['created_at'])); ?>
            <?php if (!empty($news['image'])): ?>
                | <i class="fas fa-image"></i> <?php echo $lang == 'ar' ? 'مع صورة' : 'With Image'; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- محتوى الخبر -->
    <div class="news-content">
        <?php if (!empty($news['image'])): ?>
            <img src="uploads/<?php echo htmlspecialchars($news['image']); ?>" alt="<?php echo htmlspecialchars($title); ?>">
        <?php endif; ?>
        
        <div>
            <?php echo $content; ?>
        </div>

        <!-- الرابط الخارجي (إن وجد) -->
        <?php if(!empty($news['link'])): ?>
            <div class="alert alert-info mt-4">
                <a href="<?php echo htmlspecialchars($news['link']); ?>" target="_blank" class="btn btn-info">
                    <i class="fas fa-external-link-alt"></i> 
                    <?php echo $lang == 'ar' ? 'عرض المصدر الأصلي' : 'View Original Source'; ?>
                </a>
            </div>
        <?php endif; ?>
    </div>

    <!-- أخبار ذات صلة -->
    <div class="mt-5">
        <h3 class="mb-4"><?php echo $lang == 'ar' ? 'أخبار ذات صلة' : 'Related News'; ?></h3>
        <div class="row">
            <?php
            $stmt = $pdo->prepare("SELECT * FROM news_ticker WHERE id != ? ORDER BY created_at DESC LIMIT 3");
            $stmt->execute([$news_id]);
            $related = $stmt->fetchAll();
            
            foreach ($related as $item) {
                $item_title = $lang == 'en' ? ($item['title_en'] ?? $item['title_ar']) : $item['title_ar'];
            ?>
            <div class="col-md-4 mb-3">
                <div class="card h-100">
                    <?php if (!empty($item['image'])): ?>
                        <img src="uploads/<?php echo htmlspecialchars($item['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($item_title); ?>">
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($item_title); ?></h5>
                        <a href="news_detail.php?id=<?php echo $item['id']; ?>&lang=<?php echo $lang; ?>" class="btn btn-sm btn-primary"><?php echo $lang == 'ar' ? 'اقرأ المزيد' : 'Read More'; ?></a>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</div>

<!-- التذييل -->
<footer class="footer mt-5">
    <p>&copy; 2024 تامر فتحي - جميع الحقوق محفوظة</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
