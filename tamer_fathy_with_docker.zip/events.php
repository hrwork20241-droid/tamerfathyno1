<?php 
$lang = isset($_GET['lang']) && $_GET['lang'] == 'en' ? 'en' : 'ar';
if ($lang == 'en') {
    include 'includes/header_en.php';
} else {
    include 'includes/header.php';
}
?>

<section class="py-5 bg-light">
    <div class="container">
        <h2 class="section-title"><?php echo $lang == 'en' ? 'Upcoming <span class="gold-text">Events</span>' : 'الفعاليات <span class="gold-text">القادمة</span>'; ?></h2>
        <div class="row g-4">
            <?php
            $stmt = $pdo->query("SELECT * FROM events ORDER BY sort_order ASC, event_date ASC");
            while ($row = $stmt->fetch()) {
                $title       = ($lang == 'en' && !empty($row['title_en']))       ? $row['title_en']       : $row['title'];
                $location    = ($lang == 'en' && !empty($row['location_en']))    ? $row['location_en']    : $row['location'];
                $description = ($lang == 'en' && !empty($row['description_en'])) ? $row['description_en'] : $row['description'];

                // تحديد رابط الفيديو المناسب
                $video_embed = '';
                if (!empty($row['video_url'])) {
                    $url = $row['video_url'];
                    // تحويل رابط YouTube إلى رابط embed
                    if (preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/', $url, $matches)) {
                        $video_embed = 'https://www.youtube.com/embed/' . $matches[1];
                    }
                }
            ?>
            <div class="col-md-6">
                <div class="card h-100 border-0 shadow-sm overflow-hidden">

                    <?php if (!empty($row['image'])): ?>
                    <!-- صورة الفعالية -->
                    <img src="uploads/<?php echo htmlspecialchars($row['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($title); ?>" style="height: 220px; object-fit: cover;">
                    <?php else: ?>
                    <div class="text-center pt-4 pb-2 text-danger">
                        <i class="fas fa-calendar-check fa-4x"></i>
                    </div>
                    <?php endif; ?>

                    <div class="card-body p-4">
                        <h5 class="fw-bold text-danger mb-3"><?php echo htmlspecialchars($title); ?></h5>
                        <p class="mb-2 text-dark fw-bold">
                            <i class="fas fa-map-marker-alt me-2 text-danger"></i>
                            <?php echo $lang == 'en' ? 'Location: ' : 'الموقع: '; ?><?php echo htmlspecialchars($location); ?>
                        </p>
                        <p class="mb-3 text-muted">
                            <i class="far fa-clock me-2 text-danger"></i>
                            <?php echo $lang == 'en' ? 'Date: ' : 'التاريخ: '; ?><?php echo date('Y-m-d H:i', strtotime($row['event_date'])); ?>
                        </p>
                        <p class="text-muted small mb-3"><?php echo $description; ?></p>

                        <!-- فيديو مضمّن (YouTube embed) -->
                        <?php if ($video_embed): ?>
                        <div class="ratio ratio-16x9 mb-3 rounded overflow-hidden">
                            <iframe src="<?php echo htmlspecialchars($video_embed); ?>" allowfullscreen title="<?php echo htmlspecialchars($title); ?>"></iframe>
                        </div>
                        <?php elseif (!empty($row['video_url'])): ?>
                        <!-- رابط فيديو خارجي غير YouTube -->
                        <a href="<?php echo htmlspecialchars($row['video_url']); ?>" target="_blank" class="btn btn-outline-danger btn-sm mb-3">
                            <i class="fas fa-play-circle me-1"></i> <?php echo $lang == 'en' ? 'Watch Video' : 'مشاهدة الفيديو'; ?>
                        </a>
                        <?php endif; ?>

                        <!-- ملف فيديو مرفوع مباشرة -->
                        <?php if (!empty($row['video_file'])): ?>
                        <div class="mb-3">
                            <video controls class="w-100 rounded" style="max-height: 250px;">
                                <source src="uploads/<?php echo htmlspecialchars($row['video_file']); ?>">
                                <?php echo $lang == 'en' ? 'Your browser does not support video.' : 'المتصفح لا يدعم تشغيل الفيديو.'; ?>
                            </video>
                        </div>
                        <?php endif; ?>

                        <!-- PDF جدول الفعالية -->
                        <?php if (!empty($row['schedule_pdf'])): ?>
                        <a href="uploads/<?php echo htmlspecialchars($row['schedule_pdf']); ?>" target="_blank" class="btn btn-outline-secondary btn-sm">
                            <i class="fas fa-file-pdf me-1 text-danger"></i>
                            <?php echo $lang == 'en' ? 'Download Schedule (PDF)' : 'تحميل جدول الفعالية (PDF)'; ?>
                        </a>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
            <?php } ?>
            <?php if ($stmt->rowCount() == 0): ?>
                <div class="col-12 text-center py-5">
                    <h4 class="text-muted"><?php echo $lang == 'en' ? 'No upcoming events at the moment...' : 'لا توجد فعاليات قادمة في الوقت الحالي...'; ?></h4>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php 
if ($lang == 'en') {
    include 'includes/footer_en.php';
} else {
    include 'includes/footer.php';
}
?>
