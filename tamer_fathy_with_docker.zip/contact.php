<?php 
$lang = isset($_GET['lang']) && $_GET['lang'] == 'en' ? 'en' : 'ar';
if ($lang == 'en') {
    include 'includes/header_en.php';
} else {
    include 'includes/header.php';
}

$message_sent = false;
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    $stmt = $pdo->prepare("INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
    if ($stmt->execute([$name, $email, $subject, $message])) {
        $message_sent = true;
    }
}
?>

<section class="py-5 bg-light">
    <div class="container">
        <h2 class="section-title"><?php echo $lang == 'en' ? 'Contact <span class="gold-text">Me</span>' : 'تواصل <span class="gold-text">معي</span>'; ?></h2>
        <div class="row g-5">
            <!-- بيانات التواصل -->
            <div class="col-md-4">
                <div class="card h-100 p-4 border-0 shadow-sm">
                    <h4 class="fw-bold mb-4 text-danger"><i class="fas fa-id-card me-2"></i> <?php echo $lang == 'en' ? 'Contact Info' : 'بيانات الاتصال'; ?></h4>
                    <div class="mb-4 d-flex align-items-center">
                        <div class="bg-danger text-white rounded-circle p-3 me-3"><i class="fas fa-phone"></i></div>
                        <div>
                            <p class="mb-0 fw-bold"><?php echo $lang == 'en' ? 'Phone Number' : 'رقم الهاتف'; ?></p>
                            <p class="mb-0 text-muted"><?php echo $siteSettings['contact_phone'] ?? '010XXXXXXXX'; ?></p>
                        </div>
                    </div>
                    <div class="mb-4 d-flex align-items-center">
                        <div class="bg-danger text-white rounded-circle p-3 me-3"><i class="fas fa-envelope"></i></div>
                        <div>
                            <p class="mb-0 fw-bold"><?php echo $lang == 'en' ? 'Email Address' : 'البريد الإلكتروني'; ?></p>
                            <p class="mb-0 text-muted"><?php echo $siteSettings['contact_email'] ?? 'info@tamerfathy.com'; ?></p>
                        </div>
                    </div>
                    <div class="mb-4 d-flex align-items-center">
                        <div class="bg-danger text-white rounded-circle p-3 me-3"><i class="fab fa-whatsapp"></i></div>
                        <div>
                            <p class="mb-0 fw-bold"><?php echo $lang == 'en' ? 'WhatsApp' : 'واتساب'; ?></p>
                            <p class="mb-0 text-muted"><?php echo $siteSettings['whatsapp_number'] ?? '010XXXXXXXX'; ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- نموذج الاتصال -->
            <div class="col-md-8">
                <div class="card p-4 border-0 shadow-sm">
                    <?php if ($message_sent): ?>
                        <div class="alert alert-success"><?php echo $lang == 'en' ? 'Your message has been sent successfully! Thank you for contacting me.' : 'تم إرسال رسالتك بنجاح! شكراً لتواصلك معي.'; ?></div>
                    <?php endif; ?>
                    <form method="POST" action="contact.php?lang=<?php echo $lang; ?>">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold"><?php echo $lang == 'en' ? 'Full Name' : 'الاسم الكامل'; ?></label>
                                <input type="text" name="name" class="form-control" required placeholder="<?php echo $lang == 'en' ? 'Enter your name here' : 'أدخل اسمك هنا'; ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold"><?php echo $lang == 'en' ? 'Email Address' : 'البريد الإلكتروني'; ?></label>
                                <input type="email" name="email" class="form-control" required placeholder="example@domain.com">
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-bold"><?php echo $lang == 'en' ? 'Subject' : 'الموضوع'; ?></label>
                                <input type="text" name="subject" class="form-control" required placeholder="<?php echo $lang == 'en' ? 'Message subject' : 'موضوع الرسالة'; ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-bold"><?php echo $lang == 'en' ? 'Message' : 'الرسالة'; ?></label>
                                <textarea name="message" class="form-control" rows="5" required placeholder="<?php echo $lang == 'en' ? 'Write your message here...' : 'اكتب رسالتك هنا...'; ?>"></textarea>
                            </div>
                            <div class="col-12 text-center mt-4">
                                <button type="submit" class="btn btn-primary btn-lg px-5"><?php echo $lang == 'en' ? 'Send Message' : 'إرسال الرسالة'; ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
if ($lang == 'en') {
    include 'includes/footer_en.php';
} else {
    include 'includes/footer.php';
}
?>
