<?php 
$lang = isset($_GET['lang']) && $_GET['lang'] == 'en' ? 'en' : 'ar';
if ($lang == 'en') {
    include 'includes/header_en.php';
} else {
    include 'includes/header.php';
}
?>

<section class="py-5 bg-light">
    <div class="container">
        <h2 class="section-title text-center mb-5 fw-bold"><?php echo $lang == 'en' ? 'Tamer Fathy <span class="gold-text">Blog</span>' : 'مدونة <span class="gold-text">تامر فتحي</span>'; ?></h2>
        
        <!-- المقالات الخاصة بالموقع -->
        <div class="row g-4">
            <div class="col-12">
                <h3 class="mb-4 border-bottom pb-2 text-danger"><i class="fas fa-pen-nib me-2"></i> <?php echo $lang == 'en' ? 'My Articles' : 'مقالاتي الخاصة'; ?></h3>
            </div>
            <?php
            try {
                $stmt = $pdo->query("SELECT DISTINCT * FROM blog ORDER BY sort_order ASC, created_at DESC LIMIT 12");
            } catch (PDOException $e) {
                $stmt = $pdo->query("SELECT * FROM blog GROUP BY id ORDER BY id DESC LIMIT 12");
            }
            $articles_count = 0;
            while ($row = $stmt->fetch()) {
                $articles_count++;
                $title = ($lang == 'en' && !empty($row['title_en'])) ? $row['title_en'] : $row['title'];
                $content = ($lang == 'en' && !empty($row['content_en'])) ? $row['content_en'] : $row['content'];
            ?>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm overflow-hidden">
                    <img src="uploads/<?php echo htmlspecialchars($row['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($title); ?>" style="height: 200px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title fw-bold text-danger"><?php echo htmlspecialchars($title); ?></h5>
                        <p class="card-text text-muted small mb-2"><i class="far fa-calendar-alt"></i> <?php echo date('Y-m-d', strtotime($row['created_at'])); ?></p>
                        <p class="card-text text-muted"><?php echo mb_substr(strip_tags($content), 0, 120) . '...'; ?></p>
                        <a href="blog-single.php?id=<?php echo $row['id']; ?>&lang=<?php echo $lang; ?>" class="btn btn-outline-danger btn-sm fw-bold"><?php echo $lang == 'en' ? 'Read More' : 'اقرأ المزيد'; ?></a>
                    </div>
                </div>
            </div>
            <?php } ?>
            <?php if ($articles_count == 0): ?>
                <div class="col-12 text-center py-5 bg-white rounded shadow-sm">
                    <h5 class="text-muted mb-0"><?php echo $lang == 'en' ? 'Articles coming soon...' : 'سيتم إضافة مقالاتي قريباً...'; ?></h5>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php 
if ($lang == 'en') {
    include 'includes/footer_en.php';
} else {
    include 'includes/footer.php';
}
?>
