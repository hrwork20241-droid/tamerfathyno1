-- قاعدة بيانات موقع الإعلامي تامر فتحي - النسخة v6.1 المحدثة والشاملة

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- 1. جدول الإعدادات العامة
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_title` varchar(255) DEFAULT 'الإعلامي تامر فتحي',
  `hero_title` varchar(255) DEFAULT 'الإعلامي تامر فتحي',
  `hero_description` text DEFAULT NULL,
  `hero_image` varchar(255) DEFAULT NULL,
  `site_logo` varchar(255) DEFAULT NULL,
  `site_favicon` varchar(255) DEFAULT NULL,
  `header_image` varchar(255) DEFAULT NULL,
  `contact_phone` varchar(50) DEFAULT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `whatsapp_number` varchar(50) DEFAULT NULL,
  `facebook_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `instagram_url` varchar(255) DEFAULT NULL,
  `youtube_url` varchar(255) DEFAULT NULL,
  `tiktok_url` varchar(255) DEFAULT NULL,
  `snapchat_url` varchar(255) DEFAULT NULL,
  `linkedin_url` varchar(255) DEFAULT NULL,
  `google_play_url` varchar(255) DEFAULT NULL,
  `app_store_url` varchar(255) DEFAULT NULL,
  `telegram_url` varchar(255) DEFAULT NULL,
  `threads_url` varchar(255) DEFAULT NULL,
  `facebook_show_header` tinyint(1) DEFAULT 1,
  `facebook_show_footer` tinyint(1) DEFAULT 1,
  `twitter_show_header` tinyint(1) DEFAULT 1,
  `twitter_show_footer` tinyint(1) DEFAULT 1,
  `instagram_show_header` tinyint(1) DEFAULT 1,
  `instagram_show_footer` tinyint(1) DEFAULT 1,
  `youtube_show_header` tinyint(1) DEFAULT 1,
  `youtube_show_footer` tinyint(1) DEFAULT 1,
  `tiktok_show_header` tinyint(1) DEFAULT 1,
  `tiktok_show_footer` tinyint(1) DEFAULT 1,
  `snapchat_show_header` tinyint(1) DEFAULT 1,
  `snapchat_show_footer` tinyint(1) DEFAULT 1,
  `linkedin_show_header` tinyint(1) DEFAULT 1,
  `linkedin_show_footer` tinyint(1) DEFAULT 1,
  `telegram_show_header` tinyint(1) DEFAULT 1,
  `telegram_show_footer` tinyint(1) DEFAULT 1,
  `threads_show_header` tinyint(1) DEFAULT 1,
  `threads_show_footer` tinyint(1) DEFAULT 1,
  `whatsapp_show_header` tinyint(1) DEFAULT 1,
  `whatsapp_show_footer` tinyint(1) DEFAULT 1,
  `google_play_show_header` tinyint(1) DEFAULT 1,
  `google_play_show_footer` tinyint(1) DEFAULT 1,
  `app_store_show_header` tinyint(1) DEFAULT 1,
  `app_store_show_footer` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `settings` (`id`, `site_title`) VALUES (1, 'الإعلامي تامر فتحي - نمبر وان');

-- 2. جدول البرامج (تم إضافة video_url و sort_order)
CREATE TABLE IF NOT EXISTS `programs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `channel` varchar(100) DEFAULT 'الحدث اليوم',
  `seasons` varchar(50) DEFAULT '2',
  `image` varchar(255) DEFAULT NULL,
  `short_description` text DEFAULT NULL,
  `video_url` varchar(255) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. جدول البودكاست (تم إضافة فيديو وصورة رمزية وترتيب)
CREATE TABLE IF NOT EXISTS `podcasts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `audio_url` varchar(255) DEFAULT NULL,
  `video_file` varchar(255) DEFAULT NULL,
  `video_url` varchar(255) DEFAULT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. جدول من أنا
CREATE TABLE IF NOT EXISTS `about_me` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. جدول المدونة
CREATE TABLE IF NOT EXISTS `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. جدول الصور والكواليس
CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. جدول الجوائز
CREATE TABLE IF NOT EXISTS `awards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `year` varchar(10) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. جدول الفعاليات
CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `event_date` datetime DEFAULT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL COMMENT 'صورة الفعالية',
  `video_file` varchar(255) DEFAULT NULL COMMENT 'ملف فيديو الفعالية المرفوع',
  `video_url` varchar(255) DEFAULT NULL COMMENT 'رابط فيديو خارجي (YouTube وغيره)',
  `schedule_pdf` varchar(255) DEFAULT NULL COMMENT 'PDF جدول الفعالية',
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. جدول التعاون مع صناع المحتوى
CREATE TABLE IF NOT EXISTS `collaborations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. جدول الأسئلة الشائعة
CREATE TABLE IF NOT EXISTS `faqs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. جدول رسائل اتصل بنا
CREATE TABLE IF NOT EXISTS `contact_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12. جدول مدير الموقع
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `admins` (`username`, `password`) VALUES ('admin', 'admin123');

COMMIT;
