# تعليمات نشر موقع PHP على Render باستخدام Docker و GitHub

لقد قمت بإنشاء ملف `Dockerfile` وملف `.dockerignore` لموقعك. ستساعدك هذه الملفات على نشر موقعك بسهولة على منصة Render عبر GitHub.

## 1. محتويات Dockerfile

ملف `Dockerfile` هو وصف لكيفية بناء صورة Docker لتطبيقك. إليك ما يحتويه الملف الذي تم إنشاؤه لك:

```dockerfile
FROM php:8.2-apache

# تثبيت امتدادات PHP المطلوبة
RUN docker-php-ext-install mysqli pdo pdo_mysql

# تمكين mod_rewrite (مهم للروابط النظيفة إذا كان الموقع يستخدمها)
RUN a2enmod rewrite

# نسخ ملفات المشروع إلى مجلد الويب الافتراضي في Apache
COPY . /var/www/html/

# تعيين أذونات مناسبة لملفات الويب
RUN chown -R www-data:www-data /var/www/html/
RUN chmod -R 755 /var/www/html/

# المنفذ الافتراضي لـ Apache هو 80، والذي سيتم كشفه تلقائياً بواسطة Render
EXPOSE 80
```

**شرح:**

*   `FROM php:8.2-apache`: يبدأ بصورة PHP الرسمية التي تحتوي على Apache، مما يوفر بيئة خادم ويب جاهزة.
*   `RUN docker-php-ext-install mysqli pdo pdo_mysql`: يقوم بتثبيت امتدادات PHP الضرورية للاتصال بقواعد بيانات MySQL، والتي يستخدمها موقعك.
*   `RUN a2enmod rewrite`: يقوم بتمكين وحدة `mod_rewrite` في Apache، وهي ضرورية إذا كان موقعك يستخدم روابط URL صديقة (Pretty URLs).
*   `COPY . /var/www/html/`: ينسخ جميع ملفات مشروعك من المجلد الحالي إلى مجلد الويب الافتراضي في Apache داخل حاوية Docker.
*   `RUN chown -R www-data:www-data /var/www/html/` و `RUN chmod -R 755 /var/www/html/`: يضبط الأذونات لملفات المشروع لضمان أن خادم الويب Apache يمكنه قراءتها وتنفيذها بشكل صحيح.
*   `EXPOSE 80`: يخبر Docker أن الحاوية ستستمع على المنفذ 80، وهو المنفذ الافتراضي لـ HTTP.

## 2. محتويات .dockerignore

ملف `.dockerignore` يحدد الملفات والمجلدات التي يجب استبعادها عند بناء صورة Docker. هذا يساعد في تقليل حجم الصورة وتسريع عملية البناء. الملف الذي تم إنشاؤه لك يستبعد ما يلي:

```
database.sql
*.zip
.git
.gitignore
README.md
SETUP_INSTRUCTIONS.md
UPDATES_SUMMARY.md
```

## 3. خطوات النشر على Render

لرفع موقعك على Render باستخدام GitHub، اتبع الخطوات التالية:

### أ. إعداد مشروعك محلياً

1.  **ضع الملفات:** تأكد من أن ملفات موقعك (بما في ذلك `Dockerfile` و `.dockerignore` التي تم إنشاؤها) موجودة في المجلد الرئيسي لمشروعك.
2.  **تهيئة Git:** إذا لم يكن مشروعك مهيأً لـ Git، قم بذلك:
    ```bash
    cd /path/to/your/project
    git init
    git add .
    git commit -m "Initial commit"
    ```
3.  **إنشاء مستودع GitHub:** أنشئ مستودعاً جديداً على GitHub (اجعله عاماً أو خاصاً حسب رغبتك).
4.  **ربط ورفع الكود:** اربط مشروعك المحلي بالمستودع الجديد وادفع الكود:
    ```bash
    git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY_NAME.git
    git branch -M main
    git push -u origin main
    ```
    (تأكد من استبدال `YOUR_USERNAME` و `YOUR_REPOSITORY_NAME` بالقيم الصحيحة).

### ب. النشر على Render

1.  **سجل الدخول إلى Render:** اذهب إلى [https://render.com/](https://render.com/) وسجل الدخول أو أنشئ حساباً.
2.  **إنشاء خدمة جديدة:**
    *   من لوحة التحكم، انقر على **New** ثم اختر **Web Service**.
    *   اختر **Build and deploy from a Git repository**.
    *   قم بربط حسابك على GitHub إذا لم تكن قد فعلت ذلك بالفعل، ثم اختر المستودع الذي يحتوي على ملفات موقعك.
3.  **إعدادات الخدمة:**
    *   **Name:** اسم لخدمتك (مثال: `tamer-fathy-website`).
    *   **Region:** اختر أقرب منطقة جغرافية لجمهورك.
    *   **Branch:** `main` (أو الفرع الذي يحتوي على كودك).
    *   **Root Directory:** اتركها فارغة إذا كان `Dockerfile` في المجلد الرئيسي للمستودع.
    *   **Runtime:** اختر **Docker** (سيقوم Render تلقائياً باكتشاف `Dockerfile`).
    *   **Build Command:** اتركها فارغة (Docker سيتولى البناء).
    *   **Start Command:** اتركها فارغة (Apache سيبدأ تلقائياً داخل الحاوية).
    *   **Plan Type:** اختر الخطة المناسبة لاحتياجاتك (يمكنك البدء بالخطة المجانية `Free` للاختبار).
4.  **المتغيرات البيئية (Environment Variables):**
    *   **هذا الجزء بالغ الأهمية لإعداد قاعدة البيانات.** موقعك يستخدم قاعدة بيانات MySQL. ستحتاج إلى إعداد خدمة قاعدة بيانات منفصلة على Render (أو استخدام خدمة خارجية مثل PlanetScale أو AWS RDS).
    *   إذا أنشأت قاعدة بيانات MySQL على Render، ستحصل على `DATABASE_URL` أو معلومات اتصال منفصلة (HOST, USER, PASSWORD, DATABASE_NAME).
    *   **يجب عليك تعديل ملف `includes/db.php` في مشروعك لاستخدام متغيرات البيئة بدلاً من القيم الثابتة.**
    *   **مثال على التعديل في `includes/db.php`:**
        ```php
        <?php
        $host = getenv('DB_HOST') ?: 'localhost';
        $db   = getenv('DB_NAME') ?: 'tamer_fathy';
        $user = getenv('DB_USER') ?: 'root';
        $pass = getenv('DB_PASSWORD') ?: '';
        $charset = 'utf8mb4';

        $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        if (!isset($pdo)) {
            try {
                 $pdo = new PDO($dsn, $user, $pass, $options);
                 // ... بقية الكود ...
            } catch (\PDOException $e) {
                 // ... معالجة الأخطاء ...
            }
        }
        // ... بقية الكود ...
        ?>
        ```
    *   بعد التعديل، أضف المتغيرات البيئية التالية في Render (من قسم Environment Variables في إعدادات خدمة الويب الخاصة بك):
        *   `DB_HOST`: عنوان مضيف قاعدة البيانات (مثال: `mysql-service.render.com`)
        *   `DB_NAME`: اسم قاعدة البيانات (مثال: `your_database_name`)
        *   `DB_USER`: اسم مستخدم قاعدة البيانات (مثال: `your_db_user`)
        *   `DB_PASSWORD`: كلمة مرور قاعدة البيانات (مثال: `your_db_password`)
5.  **إنشاء قاعدة البيانات على Render:**
    *   من لوحة التحكم في Render، انقر على **New** ثم اختر **MySQL**.
    *   اتبع التعليمات لإنشاء قاعدة بيانات MySQL. ستحصل على بيانات الاتصال التي ستحتاجها لمتغيرات البيئة المذكورة أعلاه.
    *   **استيراد ملف `database.sql`:** بعد إنشاء قاعدة البيانات، ستحتاج إلى استيراد ملف `database.sql` الخاص بمشروعك إليها. يمكنك القيام بذلك باستخدام أداة مثل phpMyAdmin (إذا كانت Render توفرها أو إذا كنت تستخدم خدمة MySQL خارجية) أو باستخدام عميل MySQL من سطر الأوامر بعد الاتصال بقاعدة البيانات عن بعد.
6.  **إنشاء الخدمة:** انقر على **Create Web Service**. سيبدأ Render في بناء صورتك ونشرها.

## 4. ملاحظات هامة

*   **الأمان:** لا تضع بيانات الاعتماد الحساسة (مثل كلمات مرور قاعدة البيانات) مباشرة في الكود. استخدم متغيرات البيئة كما هو موضح أعلاه.
*   **ملف `database.sql`:** تذكر أن ملف `database.sql` يحتوي على هيكل قاعدة البيانات والبيانات الأولية. يجب استيراده إلى قاعدة البيانات التي تنشئها على Render.
*   **تحديثات الكود:** في كل مرة تدفع فيها تغييرات إلى فرع `main` (أو الفرع الذي قمت بتكوينه) في GitHub، سيقوم Render تلقائياً بإعادة بناء ونشر موقعك.

أتمنى لك نشرًا موفقًا لموقعك!
