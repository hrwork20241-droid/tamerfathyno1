<?php 
$lang = isset($_GET['lang']) && $_GET['lang'] == 'en' ? 'en' : 'ar';
if ($lang == 'en') {
    include 'includes/header_en.php';
} else {
    include 'includes/header.php';
}

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM blog WHERE id = ?");
$stmt->execute([$id]);
$post = $stmt->fetch();

if (!$post) {
    echo "<div class='container py-5 text-center'><h3>" . ($lang == 'en' ? 'Article not found!' : 'المقال غير موجود!') . "</h3><a href='blog.php?lang=$lang' class='btn btn-primary mt-3'>" . ($lang == 'en' ? 'Back to Blog' : 'العودة للمدونة') . "</a></div>";
    if ($lang == 'en') {
        include 'includes/footer_en.php';
    } else {
        include 'includes/footer.php';
    }
    exit;
}
?>

<section class="py-5 bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card border-0 shadow-sm overflow-hidden">
                    <img src="uploads/<?php echo $post['image']; ?>" class="img-fluid w-100" alt="<?php echo $post['title']; ?>" style="max-height: 500px; object-fit: cover;">
                    <div class="card-body p-5">
                        <h1 class="fw-bold text-danger mb-3"><?php 
                        $title = ($lang == 'en' && !empty($post['title_en'])) ? $post['title_en'] : $post['title'];
                        echo htmlspecialchars($title); 
                    ?></h1>
                        <div class="mb-4 text-muted small"><i class="far fa-calendar-alt me-2"></i> <?php echo date('Y-m-d', strtotime($post['created_at'])); ?></div>
                        <div class="post-content lh-lg text-dark fs-5" style="<?php echo $lang == 'en' ? 'text-align: justify;' : ''; ?>">
                            <?php 
                                $content = ($lang == 'en' && !empty($post['content_en'])) ? $post['content_en'] : $post['content'];
                                echo $content; 
                            ?>
                        </div>
                        <hr class="my-5">
                        <div class="text-center">
                            <a href="blog.php?lang=<?php echo $lang; ?>" class="btn btn-outline-danger px-5 fw-bold"><?php echo $lang == 'en' ? 'Back to All Articles' : 'العودة لكافة المقالات'; ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
if ($lang == 'en') {
    include 'includes/footer_en.php';
} else {
    include 'includes/footer.php';
}
?>
