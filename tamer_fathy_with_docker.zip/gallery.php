<?php 
$lang = isset($_GET['lang']) && $_GET['lang'] == 'en' ? 'en' : 'ar';
if ($lang == 'en') {
    include 'includes/header_en.php';
} else {
    include 'includes/header.php';
}
?>

<section class="py-5 bg-light">
    <div class="container">
        <h2 class="section-title"><?php echo $lang == 'en' ? 'Photo <span class="gold-text">Gallery</span>' : 'معرض <span class="gold-text">الصور والكواليس</span>'; ?></h2>
        <div class="row g-4">
            <?php
            try {
                $stmt = $pdo->query("SELECT * FROM gallery ORDER BY sort_order ASC");
            } catch (PDOException $e) {
                $stmt = $pdo->query("SELECT * FROM gallery ORDER BY id DESC");
            }
            while ($row = $stmt->fetch()) {
                // عرض المحتوى بناءً على اللغة
                $title = ($lang == 'en' && !empty($row['title_en'])) ? $row['title_en'] : $row['title'];
            ?>
            <div class="col-md-4 col-sm-6">
                <div class="card h-100 border-0 shadow-sm overflow-hidden">
                    <img src="uploads/<?php echo $row['image']; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($title); ?>" style="height: 250px; object-fit: cover; transition: 0.5s;" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'">
                    <div class="card-body text-center">
                        <h6 class="fw-bold mb-0 text-danger"><?php echo htmlspecialchars($title); ?></h6>
                    </div>
                </div>
            </div>
            <?php } ?>
            <?php if ($stmt->rowCount() == 0): ?>
                <div class="col-12 text-center py-5"><h4 class="text-muted"><?php echo $lang == 'en' ? 'Photos coming soon...' : 'سيتم إضافة الصور قريباً...'; ?></h4></div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php 
if ($lang == 'en') {
    include 'includes/footer_en.php';
} else {
    include 'includes/footer.php';
}
?>
