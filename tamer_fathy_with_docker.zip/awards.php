<?php 
include_once 'includes/db.php'; 
$lang = isset($_GET['lang']) && $_GET['lang'] == 'en' ? 'en' : 'ar';
if ($lang == 'en') {
    include 'includes/header_en.php';
} else {
    include 'includes/header.php';
}
?>

<section class="py-5 bg-light">
    <div class="container">
        <h2 class="section-title text-center mb-5 fw-bold"><?php echo $lang == 'en' ? 'Awards & <span class="gold-text">Honors</span>' : 'الجوائز <span class="gold-text">والتكريمات</span>'; ?></h2>
        <div class="row g-4">
            <?php
            $order_by = "year DESC";
            try {
                $pdo->query("SELECT sort_order FROM awards LIMIT 1");
                $order_by = "sort_order ASC";
            } catch (PDOException $e) { }

            $stmt = $pdo->query("SELECT * FROM awards ORDER BY $order_by");
            while ($row = $stmt->fetch()) {
                $title = ($lang == 'en' && !empty($row['title_en'])) ? $row['title_en'] : $row['title'];
                $description = ($lang == 'en' && !empty($row['description_en'])) ? $row['description_en'] : $row['description'];
                $year = ($lang == 'en' && !empty($row['year_en'])) ? $row['year_en'] : $row['year'];
            ?>
            <div class="col-md-4">
                <div class="card h-100 text-center p-4 border-0 shadow-sm">
                    <div class="mb-3 text-danger"><i class="fas fa-trophy fa-4x"></i></div>
                    <h5 class="fw-bold text-danger"><?php echo htmlspecialchars($title); ?></h5>
                    <p class="text-muted small mb-2"><?php echo htmlspecialchars($year); ?></p>
                    <p class="text-muted"><?php echo nl2br(htmlspecialchars($description)); ?></p>
                    <?php if(!empty($row['image'])): ?>
                        <img src="uploads/<?php echo $row['image']; ?>" class="img-fluid rounded mt-3 shadow-sm" alt="<?php echo htmlspecialchars($title); ?>">
                    <?php endif; ?>
                </div>
            </div>
            <?php } ?>
            <?php if ($stmt->rowCount() == 0): ?>
                <div class="col-12 text-center py-5 bg-white rounded shadow-sm">
                    <h4 class="text-muted"><?php echo $lang == 'en' ? 'Awards coming soon...' : 'سيتم إضافة الجوائز قريباً...'; ?></h4>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php 
if ($lang == 'en') {
    include 'includes/footer_en.php';
} else {
    include 'includes/footer.php';
}
?>
