<?php
include_once 'includes/db.php';

// محاولة إضافة الأعمدة الناقصة تلقائياً إذا لم تكن موجودة لتجنب الأخطاء
try {
    $pdo->query("SELECT video_file FROM podcasts LIMIT 1");
} catch (PDOException $e) {
    $pdo->exec("ALTER TABLE podcasts ADD COLUMN video_file VARCHAR(255) DEFAULT NULL");
}
try {
    $pdo->query("SELECT video_url FROM podcasts LIMIT 1");
} catch (PDOException $e) {
    $pdo->exec("ALTER TABLE podcasts ADD COLUMN video_url VARCHAR(255) DEFAULT NULL");
}
try {
    $pdo->query("SELECT sort_order FROM podcasts LIMIT 1");
} catch (PDOException $e) {
    $pdo->exec("ALTER TABLE podcasts ADD COLUMN sort_order INT DEFAULT 0");
}

$lang = isset($_GET['lang']) && $_GET['lang'] == 'en' ? 'en' : 'ar';
if ($lang == 'en') {
    include 'includes/header_en.php';
} else {
    include 'includes/header.php';
}
?>

<section class="py-5 bg-light">
    <div class="container">
        <h2 class="section-title text-center mb-5 fw-bold"><?php echo $lang == 'en' ? 'Audio & Video <span class="gold-text">Podcast</span>' : 'البودكاست <span class="gold-text">الصوتي والمرئي</span>'; ?></h2>
        <div class="row g-4">
            <?php
            // التحقق من وجود عمود sort_order قبل استخدامه لتجنب الخطأ
            $order_by = "id DESC";
            try {
                $pdo->query("SELECT sort_order FROM podcasts LIMIT 1");
                $order_by = "sort_order ASC";
            } catch (PDOException $e) {
                // العمود غير موجود، سيتم استخدام الترتيب الافتراضي
            }

            $stmt = $pdo->query("SELECT * FROM podcasts ORDER BY $order_by");
            while ($row = $stmt->fetch()) {
                // عرض المحتوى بناءً على اللغة
                $title = ($lang == 'en' && !empty($row['title_en'])) ? $row['title_en'] : $row['title'];
                $description = ($lang == 'en' && !empty($row['description_en'])) ? $row['description_en'] : $row['description'];
                // التأكد من وجود المفاتيح قبل استخدامها لتجنب التحذيرات (Undefined array key)
                $video_file = isset($row['video_file']) ? $row['video_file'] : '';
                $video_url = isset($row['video_url']) ? $row['video_url'] : '';
                $audio_url = isset($row['audio_url']) ? $row['audio_url'] : '';
                $thumbnail = isset($row['thumbnail']) ? $row['thumbnail'] : '';
            ?>
            <div class="col-md-6">
                <div class="card h-100 border-0 shadow-sm p-4 text-center">
                    <div class="mb-3 text-danger"><i class="fas fa-microphone-alt fa-3x"></i></div>
                    <?php if(!empty($thumbnail)): ?>
                        <img src="uploads/<?php echo $thumbnail; ?>" class="img-fluid rounded mb-3 shadow-sm" style="height: 250px; object-fit: cover; width: 100%;">
                    <?php endif; ?>
                    <h5 class="fw-bold text-danger mb-3"><?php echo htmlspecialchars($title); ?></h5>
                    <p class="text-muted small mb-4 lh-lg"><?php echo nl2br(htmlspecialchars($description)); ?></p>
                    
                    <?php if(!empty($audio_url)): ?>
                        <div class="mb-3 p-2 bg-white rounded border">
                            <label class="small fw-bold text-dark mb-2 d-block"><?php echo $lang == 'en' ? 'Listen to Episode (Audio):' : 'استمع للحلقة (صوت):'; ?></label>
                            <audio controls class="w-100">
                                <source src="uploads/<?php echo $audio_url; ?>" type="audio/mpeg">
                                <?php echo $lang == 'en' ? 'Your browser does not support audio playback.' : 'المتصفح الخاص بك لا يدعم تشغيل الصوت.'; ?>
                            </audio>
                        </div>
                    <?php endif; ?>

                    <?php if(!empty($video_file)): ?>
                        <div class="mb-3 p-2 bg-white rounded border">
                            <label class="small fw-bold text-dark mb-2 d-block"><?php echo $lang == 'en' ? 'Watch Episode (Video):' : 'شاهد الحلقة (فيديو):'; ?></label>
                            <video controls class="w-100 rounded">
                                <source src="uploads/<?php echo $video_file; ?>" type="video/mp4">
                                <?php echo $lang == 'en' ? 'Your browser does not support video playback.' : 'المتصفح الخاص بك لا يدعم تشغيل الفيديو.'; ?>
                            </video>
                        </div>
                    <?php elseif(!empty($video_url)): ?>
                        <div class="mt-2">
                            <a href="<?php echo htmlspecialchars($video_url); ?>" target="_blank" class="btn btn-danger btn-lg w-100 fw-bold shadow-sm"><i class="fab fa-youtube me-2"></i><?php echo $lang == 'en' ? 'Watch Episode on YouTube' : 'شاهد الحلقة على يوتيوب'; ?></a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php } ?>
            <?php if ($stmt->rowCount() == 0): ?>
                <div class="col-12 text-center py-5 bg-white rounded shadow-sm"><h4 class="text-muted"><?php echo $lang == 'en' ? 'Podcast episodes coming soon...' : 'سيتم إضافة حلقات البودكاست قريباً...'; ?></h4></div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php 
if ($lang == 'en') {
    include 'includes/footer_en.php';
} else {
    include 'includes/footer.php';
}
?>
