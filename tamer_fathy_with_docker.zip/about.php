<?php 
$lang = isset($_GET['lang']) && $_GET['lang'] == 'en' ? 'en' : 'ar';
if ($lang == 'en') {
    include 'includes/header_en.php';
} else {
    include 'includes/header.php';
}

$stmt = $pdo->query("SELECT * FROM about_me LIMIT 1");
$about = $stmt->fetch();

$content_to_display = '';
if ($lang == 'en') {
    $content_to_display = !empty($about['content_en']) ? $about['content_en'] : 'Welcome, I am Tamer Fathy, a media professional and TV presenter on Al-Hadath Today channel. I present the "Number One" program, which has achieved great success over two seasons. I am interested in social and sports issues and always strive to provide meaningful and distinguished content to my dear audience.';
} else {
    $content_to_display = !empty($about['content']) ? $about['content'] : 'مرحباً بكم، أنا تامر فتحي، إعلامي ومقدم برامج تلفزيونية في قناة الحدث اليوم. أقدم برنامج "نمبر وان" والذي حقق نجاحاً كبيراً خلال موسمين من العرض. أهتم بالقضايا الاجتماعية والرياضية وأسعى دائماً لتقديم محتوى هادف ومتميز لجمهوري الكريم.';
}
?>

<style>
    .about-section { padding: 80px 0; background-color: #fdfdfd; }
    .about-card { background: #fff; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.05); border: none; overflow: hidden; }
    .about-text-container { padding: 40px; }
    .about-content-text { 
        font-size: 1.25rem; 
        line-height: 2.2; 
        color: #333; 
        text-align: justify; 
        text-justify: inter-word;
        word-wrap: break-word;
        display: block;
        width: 100%;
    }
    .about-image-container { height: 100%; min-height: 400px; }
    .about-image { width: 100%; height: 100%; object-fit: cover; }
    
    @media (max-width: 768px) {
        .about-text-container { padding: 25px; }
        .about-content-text { font-size: 1.1rem; line-height: 1.8; }
        .about-image-container { min-height: 300px; }
    }
</style>

<section class="about-section">
    <div class="container">
        <h2 class="section-title"><?php echo $lang == 'en' ? 'About <span class="gold-text">Me</span>' : 'من <span class="gold-text">أنا</span>'; ?></h2>
        
        <div class="about-card">
            <div class="row g-0 align-items-stretch">
                <!-- النص: يأخذ مساحة أكبر ومفرود بالكامل -->
                <div class="col-lg-8 col-md-7">
                    <div class="about-text-container">
                        <div class="about-content-text">
                            <?php echo $content_to_display; ?>
                        </div>
                    </div>
                </div>
                <!-- الصورة: في الجانب الآخر -->
                <div class="col-lg-4 col-md-5">
                    <div class="about-image-container">
                        <?php if(!empty($about['image'])): ?>
                            <img src="uploads/<?php echo $about['image']; ?>" class="about-image" alt="تامر فتحي">
                        <?php else: ?>
                            <div class="bg-light d-flex align-items-center justify-content-center h-100">
                                <i class="fas fa-user-circle fa-10x text-muted"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- الجوائز -->
<section class="py-5">
    <div class="container">
        <h2 class="section-title"><?php echo $lang == 'en' ? 'Awards & <span class="gold-text">Honors</span>' : 'الجوائز <span class="gold-text">والتكريمات</span>'; ?></h2>
        <div class="row g-4">
            <?php
            $stmt = $pdo->query("SELECT * FROM awards ORDER BY year DESC");
            while ($row = $stmt->fetch()) {
                $title = ($lang == 'en' && !empty($row['title_en'])) ? $row['title_en'] : $row['title'];
                $description = ($lang == 'en' && !empty($row['description_en'])) ? $row['description_en'] : $row['description'];
            ?>
            <div class="col-md-4">
                <div class="card h-100 text-center p-4 border-0 shadow-sm" style="border-radius: 15px;">
                    <div class="mb-3 text-warning"><i class="fas fa-trophy fa-3x"></i></div>
                    <h5 class="fw-bold"><?php echo $title; ?></h5>
                    <p class="text-muted small"><?php echo $row['year']; ?></p>
                    <p class="text-muted"><?php echo $description; ?></p>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</section>

<?php 
if ($lang == 'en') {
    include 'includes/footer_en.php';
} else {
    include 'includes/footer.php';
}
?>
