<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}
include '../includes/db.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = trim($_POST['current_password'] ?? '');
    $new_password = trim($_POST['new_password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');
    $admin_id = $_SESSION['admin_id'] ?? 0;

    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = 'يرجى استكمال جميع الحقول المطلوبة.';
    } elseif (mb_strlen($new_password) < 6) {
        $error = 'يجب ألا تقل كلمة المرور الجديدة عن 6 أحرف.';
    } elseif ($new_password !== $confirm_password) {
        $error = 'تأكيد كلمة المرور غير مطابق.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
        $stmt->execute([$admin_id]);
        $admin = $stmt->fetch();

        if (!$admin) {
            $error = 'تعذر العثور على بيانات المدير الحالي.';
        } elseif (!($current_password === $admin['password'] || password_verify($current_password, $admin['password']))) {
            $error = 'كلمة المرور الحالية غير صحيحة.';
        } else {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update = $pdo->prepare("UPDATE admins SET password = ? WHERE id = ?");
            if ($update->execute([$hashed_password, $admin_id])) {
                $success = 'تم تغيير كلمة المرور بنجاح.';
            } else {
                $error = 'حدث خطأ أثناء تحديث كلمة المرور، حاول مرة أخرى.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تغيير كلمة المرور</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #2c3e50; color: #fff; position: fixed; top: 0; right: 0; padding: 20px 10px; overflow-y: auto; z-index: 1000; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.95rem; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }
        .sidebar a i { width: 25px; }
        .main-content { margin-right: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 16px; }
        .btn-primary { background-color: #cc0000; border: none; }
        .btn-primary:hover { background-color: #a30000; }
        .nav-view-site { background: #cc0000 !important; margin-bottom: 20px !important; text-align: center; font-weight: bold; }
        .page-intro { color: #6c757d; margin-bottom: 20px; }
        @media (max-width: 767px) {
            .main-content { margin-right: 0; padding: 20px; }
            .sidebar { position: relative; width: 100%; height: auto; }
        }
    </style>
</head>
<body>
<div class="sidebar">
    <h4 class="text-center mb-4 fw-bold">لوحة التحكم</h4>
    <a href="../index.php" target="_blank" class="nav-view-site"><i class="fas fa-external-link-alt"></i> عرض الموقع</a>
    <a href="control_panel.php"><i class="fas fa-cog"></i> الإعدادات العامة</a>
    <a href="manage_about.php"><i class="fas fa-user"></i> من أنا</a>
    <a href="manage_programs.php"><i class="fas fa-tv"></i> البرامج</a>
    <a href="manage_blog.php"><i class="fas fa-blog"></i> المدونة</a>
    <a href="manage_gallery.php"><i class="fas fa-images"></i> الصور والكواليس</a>
    <a href="manage_awards.php"><i class="fas fa-trophy"></i> الجوائز</a>
    <a href="manage_podcasts.php"><i class="fas fa-microphone"></i> البودكاست</a>
    <a href="manage_events.php"><i class="fas fa-calendar-alt"></i> الفعاليات</a>
    <a href="manage_collaborations.php"><i class="fas fa-handshake"></i> صناع المحتوى</a>
    <a href="manage_faqs.php"><i class="fas fa-question-circle"></i> الأسئلة الشائعة</a>
    <a href="manage_messages.php"><i class="fas fa-envelope"></i> الرسائل</a>
    <a href="manage_pages.php"><i class="fas fa-file-circle-plus"></i> إضافة صفحة</a>
    <a href="change_password.php" class="active"><i class="fas fa-key"></i> تغيير كلمة المرور</a>
    <hr>
    <a href="control_panel_en.php" style="color: #ffc107 !important;"><i class="fas fa-language"></i> English Admin Panel</a>
    <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
</div>

<div class="main-content">
    <div class="container-fluid">
        <h2 class="mb-2 fw-bold text-dark">تغيير كلمة المرور</h2>
        <p class="page-intro">لرفع مستوى أمان لوحة التحكم، يمكنك تحديث كلمة المرور الحالية بكلمة مرور جديدة قوية وسهلة التذكّر بالنسبة لك.</p>

        <?php if ($success): ?>
            <div class="alert alert-success border-0 shadow-sm"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger border-0 shadow-sm"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4 p-lg-5">
                <form method="POST" action="change_password.php">
                    <div class="row">
                        <div class="col-md-12 mb-4">
                            <label class="form-label fw-bold">كلمة المرور الحالية</label>
                            <input type="password" name="current_password" class="form-control form-control-lg" required>
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label fw-bold">كلمة المرور الجديدة</label>
                            <input type="password" name="new_password" class="form-control form-control-lg" required>
                            <small class="text-muted">يفضل استخدام 6 أحرف أو أكثر.</small>
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label fw-bold">تأكيد كلمة المرور الجديدة</label>
                            <input type="password" name="confirm_password" class="form-control form-control-lg" required>
                        </div>
                    </div>
                    <div class="d-flex flex-wrap gap-2">
                        <button type="submit" class="btn btn-primary btn-lg px-5 fw-bold"><i class="fas fa-save ms-2"></i> حفظ كلمة المرور الجديدة</button>
                        <a href="control_panel.php" class="btn btn-outline-secondary btn-lg px-4">العودة للإعدادات</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
