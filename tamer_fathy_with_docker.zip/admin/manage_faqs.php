<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }
include '../includes/db.php';

// إضافة عمود الترتيب والأعمدة الإنجليزية إذا لم تكن موجودة
try { $pdo->exec("ALTER TABLE faqs ADD COLUMN sort_order INT DEFAULT 0"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE faqs ADD COLUMN question_en TEXT DEFAULT NULL"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE faqs ADD COLUMN answer_en TEXT DEFAULT NULL"); } catch (Exception $e) {}

$success = '';
$edit_data = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_faq'])) {
        $question = $_POST['question'];
        $question_en = $_POST['question_en'] ?? '';
        $answer = $_POST['answer'];
        $answer_en = $_POST['answer_en'] ?? '';
        
        $stmt = $pdo->prepare("INSERT INTO faqs (question, question_en, answer, answer_en, sort_order) VALUES (?, ?, ?, ?, (SELECT IFNULL(MAX(sort_order), 0) + 1 FROM faqs AS f))");
        if ($stmt->execute([$question, $question_en, $answer, $answer_en])) {
            $success = "تم إضافة السؤال بنجاح!";
        }
    } elseif (isset($_POST['update_faq'])) {
        $id = $_POST['id'];
        $question = $_POST['question'];
        $question_en = $_POST['question_en'] ?? '';
        $answer = $_POST['answer'];
        $answer_en = $_POST['answer_en'] ?? '';
        
        $stmt = $pdo->prepare("UPDATE faqs SET question = ?, question_en = ?, answer = ?, answer_en = ? WHERE id = ?");
        if ($stmt->execute([$question, $question_en, $answer, $answer_en, $id])) {
            $success = "تم تحديث السؤال بنجاح!";
        }
    }
}

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM faqs WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $edit_data = $stmt->fetch();
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $pdo->prepare("DELETE FROM faqs WHERE id = ?")->execute([$id]);
    header("Location: manage_faqs.php"); exit;
}

if (isset($_GET['move']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $move = $_GET['move'];
    $stmt = $pdo->prepare("SELECT sort_order FROM faqs WHERE id = ?");
    $stmt->execute([$id]);
    $current_order = $stmt->fetchColumn();
    
    if ($move == 'up') {
        $stmt = $pdo->prepare("SELECT id, sort_order FROM faqs WHERE sort_order < ? ORDER BY sort_order DESC LIMIT 1");
    } else {
        $stmt = $pdo->prepare("SELECT id, sort_order FROM faqs WHERE sort_order > ? ORDER BY sort_order ASC LIMIT 1");
    }
    $stmt->execute([$current_order]);
    $swap = $stmt->fetch();
    
    if ($swap) {
        $pdo->prepare("UPDATE faqs SET sort_order = ? WHERE id = ?")->execute([$swap['sort_order'], $id]);
        $pdo->prepare("UPDATE faqs SET sort_order = ? WHERE id = ?")->execute([$current_order, $swap['id']]);
    }
    header("Location: manage_faqs.php"); exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة الأسئلة الشائعة</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #2c3e50; color: #fff; position: fixed; top: 0; right: 0; padding: 20px 10px; overflow-y: auto; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.95rem; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }
        .main-content { margin-right: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 12px; }
        .btn-primary { background-color: #cc0000; border: none; }
        .btn-primary:hover { background-color: #a30000; }
        .nav-view-site { background: #cc0000 !important; margin-bottom: 20px !important; text-align: center; font-weight: bold; }
        .sort-btn { padding: 2px 8px; font-size: 0.8rem; }
        .lang-section-ar { border-right: 4px solid #cc0000; padding-right: 12px; }
        .lang-section-en { border-right: 4px solid #0066cc; padding-right: 12px; }
        .lang-badge-ar { background: #cc0000; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .lang-badge-en { background: #0066cc; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .auto-translate-badge { background: #28a745; color: #fff; padding: 2px 6px; border-radius: 5px; font-size: 0.7rem; margin-right: 5px; }
    </style>
</head>
<body>
<div class="sidebar">
    <h4 class="text-center mb-4 fw-bold">لوحة التحكم</h4>
    <a href="../index.php" target="_blank" class="nav-view-site"><i class="fas fa-external-link-alt"></i> عرض الموقع</a>
    <a href="control_panel.php"><i class="fas fa-cog"></i> الإعدادات العامة</a>
    <a href="manage_about.php"><i class="fas fa-user"></i> من أنا</a>
    <a href="manage_programs.php"><i class="fas fa-tv"></i> البرامج</a>
    <a href="manage_blog.php"><i class="fas fa-blog"></i> المدونة</a>
    <a href="manage_gallery.php"><i class="fas fa-images"></i> الصور والكواليس</a>
    <a href="manage_awards.php"><i class="fas fa-trophy"></i> الجوائز</a>
    <a href="manage_podcasts.php"><i class="fas fa-microphone"></i> البودكاست</a>
    <a href="manage_events.php"><i class="fas fa-calendar-alt"></i> الفعاليات</a>
    <a href="manage_collaborations.php"><i class="fas fa-handshake"></i> صناع المحتوى</a>
    <a href="manage_faqs.php" class="active"><i class="fas fa-question-circle"></i> الأسئلة الشائعة</a>
    <a href="manage_ticker.php"><i class="fas fa-bolt"></i> شريط الأخبار</a>
    <a href="manage_messages.php"><i class="fas fa-envelope"></i> الرسائل</a>
    <hr>
    <a href="control_panel_en.php" style="color: #ffc107 !important;"><i class="fas fa-language"></i> English Admin Panel</a>
    <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
</div>
<div class="main-content">
    <div class="container-fluid">
        <h2 class="mb-4 fw-bold">إدارة الأسئلة الشائعة</h2>
        <?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
        
        <div class="card mb-4">
            <div class="card-header bg-primary text-white fw-bold">
                <?php echo $edit_data ? 'تعديل السؤال' : 'إضافة سؤال جديد'; ?>
            </div>
            <div class="card-body">
                <form method="POST" action="manage_faqs.php">
                    <?php if($edit_data): ?><input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>"><?php endif; ?>
                    <div class="row g-3">
                        <!-- قسم العربية -->
                        <div class="col-12">
                            <div class="lang-section-ar mb-2">
                                <span class="lang-badge-ar"><i class="fas fa-language me-1"></i> عربي</span>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-bold">السؤال بالعربية <span class="text-danger">*</span></label>
                            <input type="text" name="question" id="question_ar" class="form-control" value="<?php echo htmlspecialchars($edit_data['question'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-bold">الإجابة بالعربية <span class="text-danger">*</span></label>
                            <textarea name="answer" id="answer_ar" class="form-control" rows="3" required><?php echo htmlspecialchars($edit_data['answer'] ?? ''); ?></textarea>
                        </div>

                        <!-- قسم الإنجليزية -->
                        <div class="col-12 mt-3">
                            <hr>
                            <div class="lang-section-en mb-2">
                                <span class="lang-badge-en"><i class="fas fa-language me-1"></i> English</span>
                                <span class="auto-translate-badge"><i class="fas fa-magic"></i> ترجمة تلقائية</span>
                                <small class="text-muted">يظهر في الموقع الإنجليزي فقط - يُترجم تلقائياً من العربية</small>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-bold">Question (English)</label>
                            <input type="text" name="question_en" id="question_en" class="form-control" dir="ltr" value="<?php echo htmlspecialchars($edit_data['question_en'] ?? ''); ?>">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-bold">Answer (English)</label>
                            <textarea name="answer_en" id="answer_en" class="form-control" rows="3" dir="ltr"><?php echo htmlspecialchars($edit_data['answer_en'] ?? ''); ?></textarea>
                        </div>
                        <div class="col-12 text-center d-flex justify-content-center gap-3">
                            <button type="button" id="previewBtn" class="btn btn-info px-4 fw-bold text-white"><i class="fas fa-eye me-1"></i> معاينة</button>
                            <button type="submit" name="<?php echo $edit_data ? 'update_faq' : 'add_faq'; ?>" class="btn btn-success px-5 fw-bold"><i class="fas fa-save me-1"></i> <?php echo $edit_data ? 'تحديث نهائي' : 'إضافة واعتماد'; ?></button>
                            <?php if($edit_data): ?><a href="manage_faqs.php" class="btn btn-secondary px-4">إلغاء</a><?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <table class="table table-hover align-middle text-center">
                    <thead><tr><th>الترتيب</th><th>السؤال</th><th>الإجابة</th><th>إجراءات</th></tr></thead>
                    <tbody>
                        <?php
                        $stmt = $pdo->query("SELECT * FROM faqs ORDER BY sort_order ASC");
                        while ($row = $stmt->fetch()) {
                        ?>
                        <tr>
                            <td>
                                <a href="manage_faqs.php?move=up&id=<?php echo $row['id']; ?>" class="btn btn-outline-dark sort-btn"><i class="fas fa-arrow-up"></i></a>
                                <a href="manage_faqs.php?move=down&id=<?php echo $row['id']; ?>" class="btn btn-outline-dark sort-btn"><i class="fas fa-arrow-down"></i></a>
                            </td>
                            <td class="text-start">
                                <strong><?php echo htmlspecialchars($row['question']); ?></strong>
                                <?php if(!empty($row['question_en'])): ?>
                                    <br><small class="text-muted" dir="ltr"><?php echo htmlspecialchars($row['question_en']); ?></small>
                                <?php endif; ?>
                            </td>
                            <td class="text-start">
                                <small><?php echo mb_substr(htmlspecialchars($row['answer']), 0, 100) . '...'; ?></small>
                            </td>
                            <td>
                                <a href="manage_faqs.php?edit=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning text-white"><i class="fas fa-edit"></i></a>
                                <a href="manage_faqs.php?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد من الحذف؟')"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="auto_translate.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // ربط حقول الترجمة الفورية
    liveTranslator.bindTranslationField('#question_ar', '#question_en', 800);
    liveTranslator.bindTranslationField('#answer_ar', '#answer_en', 1000);
});

document.getElementById('previewBtn').addEventListener('click', function() {
    const questionAr = document.querySelector('input[name="question"]').value;
    const answerAr = document.querySelector('textarea[name="answer"]').value;
    const questionEn = document.querySelector('input[name="question_en"]').value;
    const answerEn = document.querySelector('textarea[name="answer_en"]').value;
    
    const previewWin = window.open('', 'Preview', 'width=900,height=700');
    previewWin.document.write(`
        <html>
        <head>
            <title>معاينة السؤال الشائع</title>
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
            <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
            <style>body{padding:20px; font-family: 'Tajawal', sans-serif; background-color: #f8f9fa;}</style>
        </head>
        <body>
            <div class="alert alert-info text-center shadow-sm">معاينة السؤال الشائع</div>
            <div class="container mt-4">
                <div class="row">
                    <div class="col-md-6">
                        <h5 class="text-danger fw-bold mb-3">العربية</h5>
                        <div class="card shadow-lg border-0 rounded-4 mb-4">
                            <div class="card-body p-4" dir="rtl">
                                <h6 class="text-danger fw-bold mb-3"><i class="fas fa-question-circle me-2"></i> \${questionAr || 'السؤال هنا'}</h6>
                                <div class="p-3 bg-light rounded-3 border-start border-4 border-danger fs-6" style="line-height: 1.8;">
                                    \${answerAr || 'الإجابة هنا'}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h5 style="color:#0066cc;" class="fw-bold mb-3">English</h5>
                        <div class="card shadow-lg border-0 rounded-4 mb-4">
                            <div class="card-body p-4" dir="ltr">
                                <h6 style="color:#0066cc;" class="fw-bold mb-3"><i class="fas fa-question-circle me-2"></i> \${questionEn || 'Question here'}</h6>
                                <div class="p-3 bg-light rounded-3 border-start border-4" style="border-color:#0066cc !important; line-height: 1.8;">
                                    \${answerEn || 'Answer here'}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-center mt-5"><button onclick="window.close()" class="btn btn-dark px-4 rounded-pill">إغلاق المعاينة</button></div>
            </div>
        </body>
        </html>
    `);
});
</script>
</body>
</html>
