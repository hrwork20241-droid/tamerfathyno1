/**
 * ملف الترجمة الفورية
 * يترجم النص من العربية إلى الإنجليزية فوراً عند الكتابة
 */

class LiveTranslator {
    constructor() {
        this.translationCache = {};
        this.isTranslating = false;
    }

    /**
     * الترجمة باستخدام Google Translate API عبر واجهة ويب
     */
    async translateText(text) {
        if (!text || text.trim() === '') {
            return '';
        }

        // التحقق من الكاش
        if (this.translationCache[text]) {
            return this.translationCache[text];
        }

        // إذا كان النص يحتوي على HTML، نقوم بتقسيمه وترجمته لضمان عدم تلف الأكواد
        const hasHtml = /<[a-z][\s\S]*>/i.test(text);
        
        if (hasHtml) {
            return this.translateHtml(text);
        }

        return this.fetchTranslation(text);
    }

    async fetchTranslation(text) {
        try {
            const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=ar&tl=en&dt=t&q=${encodeURIComponent(text)}`;
            const response = await fetch(url);
            if (!response.ok) return text;
            const data = await response.json();
            if (data && data[0]) {
                let translated = data[0].map(item => item[0]).join('');
                this.translationCache[text] = translated;
                return translated;
            }
        } catch (e) { console.error(e); }
        return text;
    }

    async translateHtml(html) {
        const div = document.createElement('div');
        div.innerHTML = html;
        
        // ترجمة النصوص داخل العناصر فقط للحفاظ على الـ HTML
        const walk = async (node) => {
            if (node.nodeType === 3) { // Text node
                if (node.nodeValue.trim() !== '') {
                    node.nodeValue = await this.fetchTranslation(node.nodeValue);
                }
            } else {
                for (let child of node.childNodes) {
                    await walk(child);
                }
            }
        };
        
        await walk(div);
        return div.innerHTML;
    }

    /**
     * ربط حقل إدخال عربي بحقل إنجليزي للترجمة الفورية
     */
    bindTranslationField(arabicInputSelector, englishInputSelector, debounceTime = 500) {
        const arabicInput = document.querySelector(arabicInputSelector);
        const englishInput = document.querySelector(englishInputSelector);

        if (!arabicInput || !englishInput) {
            console.warn(`Could not find elements: ${arabicInputSelector} or ${englishInputSelector}`);
            return;
        }

        let debounceTimer;

        arabicInput.addEventListener('input', async (e) => {
            clearTimeout(debounceTimer);
            
            debounceTimer = setTimeout(async () => {
                const arabicText = arabicInput.value;
                
                if (arabicText.trim() === '') {
                    englishInput.value = '';
                    return;
                }

                // إظهار مؤشر التحميل
                englishInput.style.opacity = '0.6';
                englishInput.style.pointerEvents = 'none';

                const translatedText = await this.translateText(arabicText);
                
                englishInput.value = translatedText;
                englishInput.style.opacity = '1';
                englishInput.style.pointerEvents = 'auto';

                // تحديث حدث التغيير للتطبيقات التي تستمع له
                englishInput.dispatchEvent(new Event('input', { bubbles: true }));
            }, debounceTime);
        });
    }

    /**
     * ربط حقول متعددة
     */
    bindMultipleFields(bindings) {
        bindings.forEach(binding => {
            this.bindTranslationField(binding.arabic, binding.english, binding.debounceTime || 500);
        });
    }
}

// إنشاء instance عام
const liveTranslator = new LiveTranslator();

// دالة مساعدة للاستخدام السريع
function setupAutoTranslation(arabicSelector, englishSelector) {
    liveTranslator.bindTranslationField(arabicSelector, englishSelector);
}

// تهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    // سيتم استدعاء هذا من صفحات الإدارة المختلفة
});
