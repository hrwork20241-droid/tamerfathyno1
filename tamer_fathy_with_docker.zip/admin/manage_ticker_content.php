<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }
include '../includes/db.php';

// إضافة الأعمدة إذا لم تكن موجودة
try { $pdo->exec("ALTER TABLE news_ticker ADD COLUMN content_ar LONGTEXT DEFAULT NULL"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE news_ticker ADD COLUMN content_en LONGTEXT DEFAULT NULL"); } catch (Exception $e) {}

$success = '';
$edit_data = null;

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM news_ticker WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $edit_data = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_content'])) {
        $id = $_POST['id'];
        $content_ar = $_POST['content_ar'] ?? '';
        $content_en = $_POST['content_en'] ?? '';
        
        $stmt = $pdo->prepare("UPDATE news_ticker SET content_ar = ?, content_en = ? WHERE id = ?");
        if ($stmt->execute([$content_ar, $content_en, $id])) {
            $success = "تم تحديث محتوى الخبر بنجاح!";
            header("Location: manage_ticker_content.php?success=1");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة محتوى الأخبار</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.tiny.cloud/1/d6i6qfdtjejdaj7tmki3r3180lhn7nagpexwc26vwzlos32z/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #2c3e50; color: #fff; position: fixed; top: 0; right: 0; padding: 20px 10px; overflow-y: auto; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.95rem; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }
        .main-content { margin-right: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 12px; }
        .btn-primary { background-color: #cc0000; border: none; }
        .btn-primary:hover { background-color: #a30000; }
        .nav-view-site { background: #cc0000 !important; margin-bottom: 20px !important; text-align: center; font-weight: bold; }
        .lang-section-ar { border-right: 4px solid #cc0000; padding-right: 12px; }
        .lang-section-en { border-right: 4px solid #0066cc; padding-right: 12px; }
        .lang-badge-ar { background: #cc0000; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .lang-badge-en { background: #0066cc; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .auto-translate-badge { background: #28a745; color: #fff; padding: 2px 6px; border-radius: 5px; font-size: 0.7rem; margin-right: 5px; }
    </style>
</head>
<body>
<div class="sidebar">
    <h4 class="text-center mb-4 fw-bold">لوحة التحكم</h4>
    <a href="../index.php" target="_blank" class="nav-view-site"><i class="fas fa-external-link-alt"></i> عرض الموقع</a>
    <a href="control_panel.php"><i class="fas fa-cog"></i> الإعدادات العامة</a>
    <a href="manage_ticker.php"><i class="fas fa-bolt"></i> شريط الأخبار</a>
    <a href="manage_ticker_content.php" class="active"><i class="fas fa-file-alt"></i> محتوى الأخبار</a>
    <hr>
    <a href="control_panel_en.php" style="color: #ffc107 !important;"><i class="fas fa-language"></i> English Admin Panel</a>
    <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
</div>

<div class="main-content">
    <div class="container-fluid">
        <h2 class="mb-4 fw-bold">إدارة محتوى الأخبار</h2>
        <?php if (isset($_GET['success'])): ?><div class="alert alert-success">تم تحديث محتوى الخبر بنجاح!</div><?php endif; ?>
        
        <?php if ($edit_data): ?>
        <div class="card mb-4">
            <div class="card-header bg-primary text-white fw-bold">تعديل محتوى الخبر: <?php echo htmlspecialchars($edit_data['title_ar']); ?></div>
            <div class="card-body">
                <form method="POST" action="manage_ticker_content.php">
                    <input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>">
                    <div class="row g-3">
                        <!-- قسم العربية -->
                        <div class="col-12">
                            <div class="lang-section-ar mb-2">
                                <span class="lang-badge-ar"><i class="fas fa-language me-1"></i> عربي</span>
                            </div>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-bold">محتوى الخبر بالعربية</label>
                            <textarea name="content_ar" id="content_ar" class="form-control"><?php echo htmlspecialchars($edit_data['content_ar'] ?? ''); ?></textarea>
                        </div>

                        <!-- قسم الإنجليزية -->
                        <div class="col-12 mt-3">
                            <hr>
                            <div class="lang-section-en mb-2">
                                <span class="lang-badge-en"><i class="fas fa-language me-1"></i> English</span>
                                <span class="auto-translate-badge"><i class="fas fa-magic"></i> ترجمة تلقائية</span>
                            </div>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-bold">News Content (English)</label>
                            <textarea name="content_en" id="content_en" class="form-control" dir="ltr"><?php echo htmlspecialchars($edit_data['content_en'] ?? ''); ?></textarea>
                        </div>

                        <div class="col-12 text-center d-flex justify-content-center gap-3">
                            <button type="submit" name="update_content" class="btn btn-success px-5 fw-bold"><i class="fas fa-save me-1"></i> حفظ المحتوى</button>
                            <a href="manage_ticker_content.php" class="btn btn-secondary px-4">إلغاء</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <?php else: ?>
        <div class="alert alert-info">اختر خبراً من الجدول أدناه لتعديل محتواه</div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <table class="table table-hover align-middle">
                    <thead><tr><th>العنوان (عربي / إنجليزي)</th><th>المحتوى</th><th>العمليات</th></tr></thead>
                    <tbody>
                        <?php
                        $stmt = $pdo->query("SELECT * FROM news_ticker ORDER BY sort_order ASC, id DESC");
                        while ($row = $stmt->fetch()) {
                        ?>
                        <tr>
                            <td class="text-start">
                                <strong><?php echo htmlspecialchars($row['title_ar']); ?></strong>
                                <?php if(!empty($row['title_en'])): ?>
                                    <br><small class="text-muted" dir="ltr"><?php echo htmlspecialchars($row['title_en']); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(!empty($row['content_ar'])): ?>
                                    <span class="badge bg-success">عربي</span>
                                <?php endif; ?>
                                <?php if(!empty($row['content_en'])): ?>
                                    <span class="badge bg-primary">English</span>
                                <?php endif; ?>
                                <?php if(empty($row['content_ar']) && empty($row['content_en'])): ?>
                                    <span class="badge bg-secondary">بدون محتوى</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="manage_ticker_content.php?edit=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning text-white"><i class="fas fa-edit"></i> تعديل</a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="auto_translate.js"></script>
<script>
tinymce.init({
    selector: '#content_ar',
    language: 'ar',
    directionality: 'rtl',
    height: 300,
    plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table help wordcount',
    toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
    content_style: 'body { font-family:Tajawal,Helvetica,Arial,sans-serif; font-size:14px }',
    branding: false,
    promotion: false
});

tinymce.init({
    selector: '#content_en',
    language: 'en',
    directionality: 'ltr',
    height: 300,
    plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table help wordcount',
    toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
    content_style: 'body { font-family:Tajawal,Helvetica,Arial,sans-serif; font-size:14px }',
    branding: false,
    promotion: false
});

document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        const arEditor = tinymce.get('content_ar');
        if(arEditor) {
            const updateTranslation = function() {
                const arabicText = arEditor.getContent();
                if(arabicText.trim().length > 0) {
                    fetch('translate.php', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'text=' + encodeURIComponent(arabicText)
                    })
                    .then(response => response.json())
                    .then(data => {
                        const translatedContent = data.translatedText || data.translated;
                        if(translatedContent) {
                            const enEditor = tinymce.get('content_en');
                            if(enEditor) {
                                enEditor.setContent(translatedContent);
                            }
                        }
                    })
                    .catch(error => console.error('Translation error:', error));
                }
            };
            arEditor.on('change', updateTranslation);
            arEditor.on('blur', updateTranslation);
        }
    }, 1500);
});
</script>
</body>
</html>
