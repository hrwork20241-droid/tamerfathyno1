<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }
include '../includes/db.php';

$success = '';
$error = '';

// جلب البيانات الحالية
$stmt = $pdo->query("SELECT * FROM about_me LIMIT 1");
$about = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $content_ar = $_POST['content_ar'] ?? '';
    $content_en = $_POST['content_en'] ?? '';
    $image = $about['image'] ?? '';
    
    if (!empty($_FILES['image']['name'])) {
        $image = time() . '_' . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $image);
    }
    
    try {
        // التأكد من وجود العمود
        try { $pdo->exec("ALTER TABLE about_me ADD COLUMN content_en LONGTEXT AFTER content"); } catch (Exception $e) {}
        
        if ($about) {
            $update_stmt = $pdo->prepare("UPDATE about_me SET content = ?, content_en = ?, image = ? WHERE id = ?");
            $update_stmt->execute([$content_ar, $content_en, $image, $about['id']]);
        } else {
            $insert_stmt = $pdo->prepare("INSERT INTO about_me (content, content_en, image) VALUES (?, ?, ?)");
            $insert_stmt->execute([$content_ar, $content_en, $image]);
        }
        $success = "تم تحديث بيانات (من أنا) بنجاح!";
        $stmt = $pdo->query("SELECT * FROM about_me LIMIT 1"); 
        $about = $stmt->fetch();
    } catch (Exception $e) {
        $error = "حدث خطأ: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة من أنا</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.tiny.cloud/1/d6i6qfdtjejdaj7tmki3r3180lhn7nagpexwc26vwzlos32z/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #2c3e50; color: #fff; position: fixed; top: 0; right: 0; padding: 20px 10px; overflow-y: auto; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.95rem; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }
        .main-content { margin-right: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 12px; }
        .lang-section { padding: 20px; background: #f8f9fa; border-radius: 8px; margin-bottom: 20px; border-right: 4px solid #cc0000; }
        .lang-section h5 { color: #cc0000; font-weight: bold; margin-bottom: 15px; }
        .lang-section.en { border-right-color: #007bff; }
        .lang-section.en h5 { color: #007bff; }
        .auto-translate-info { background: #e8f5e9; color: #2e7d32; padding: 10px 15px; border-radius: 5px; margin-bottom: 15px; font-size: 0.9rem; }
    </style>
</head>
<body>
<div class="sidebar">
    <h4 class="text-center mb-4 fw-bold">لوحة التحكم</h4>
    <a href="../index.php" target="_blank" class="btn btn-danger w-100 mb-3">عرض الموقع</a>
    <a href="manage_about.php" class="active">من أنا</a>
    <a href="manage_faqs.php">الأسئلة الشائعة</a>
    <hr>
    <a href="logout.php" class="text-danger">تسجيل الخروج</a>
</div>
<div class="main-content">
    <div class="container-fluid">
        <h2 class="mb-4 fw-bold">إدارة محتوى (من أنا)</h2>
        <?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
        <div class="card">
            <div class="card-body p-4">
                <form method="POST" enctype="multipart/form-data">
                    <!-- قسم المحتوى العربي -->
                    <div class="lang-section ar">
                        <h5><i class="fas fa-language me-2"></i>المحتوى التعريفي بالعربية</h5>
                        <textarea name="content_ar" id="content_ar" class="form-control"><?php echo htmlspecialchars($about['content'] ?? ''); ?></textarea>
                    </div>

                    <!-- قسم المحتوى الإنجليزي (ترجمة تلقائية) -->
                    <div class="lang-section en">
                        <div class="auto-translate-info">
                            <i class="fas fa-sync-alt me-2"></i>هذا الحقل يتم ملؤه تلقائياً بالترجمة الإنجليزية عند الانتهاء من كتابة النص بالعربية
                        </div>
                        <h5><i class="fas fa-language me-2"></i>Content in English (Auto-Translated)</h5>
                        <textarea name="content_en" id="content_en" class="form-control"><?php echo htmlspecialchars($about['content_en'] ?? ''); ?></textarea>
                    </div>

                    <!-- الصورة الشخصية -->
                    <div class="mb-4">
                        <label class="form-label fw-bold">الصورة الشخصية</label>
                        <input type="file" name="image" class="form-control" accept="image/*">
                        <?php if(!empty($about['image'])): ?>
                            <div class="mt-3">
                                <img src="../uploads/<?php echo $about['image']; ?>" class="rounded shadow-sm border" height="150" alt="صورة شخصية">
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="text-center mt-4">
                        <button type="submit" class="btn btn-success btn-lg px-5 fw-bold">حفظ التغييرات</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="auto_translate.js"></script>
<script>
tinymce.init({
    selector: '#content_ar',
    language: 'ar',
    directionality: 'rtl',
    height: 400,
    plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table help wordcount',
    toolbar: 'undo redo | blocks | bold italic | alignleft aligncenter alignright | bullist numlist | link image',
    setup: function(editor) {
        editor.on('change', function() {
            const arabicText = editor.getContent();
            if(arabicText.trim().length > 0) {
                fetch('translate.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'text=' + encodeURIComponent(arabicText)
                })
                .then(response => response.json())
                .then(data => {
                    if(data.translatedText) {
                        const enEditor = tinymce.get('content_en');
                        if(enEditor) {
                            enEditor.setContent(data.translatedText);
                        }
                    }
                })
                .catch(error => console.error('Translation error:', error));
            }
        });
    }
});
tinymce.init({
    selector: '#content_en',
    language: 'en',
    directionality: 'ltr',
    height: 400,
    plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table help wordcount',
    toolbar: 'undo redo | blocks | bold italic | alignleft aligncenter alignright | bullist numlist | link image',
    readonly: true
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
