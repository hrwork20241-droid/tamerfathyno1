<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }
include '../includes/db.php';

// إضافة الأعمدة الإنجليزية إذا لم تكن موجودة
try { $pdo->exec("ALTER TABLE podcasts ADD COLUMN title_en VARCHAR(255) DEFAULT NULL"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE podcasts ADD COLUMN description_en TEXT DEFAULT NULL"); } catch (Exception $e) {}

$success = '';

// إضافة بودكاست جديد
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_podcast'])) {
    $title = $_POST['title'];
    $title_en = $_POST['title_en'] ?? '';
    $description = $_POST['description'];
    $description_en = $_POST['description_en'] ?? '';
    $video_url = $_POST['video_url'];
    $audio = ''; $video_file = ''; $thumbnail = '';
    
    if (!empty($_FILES['audio']['name'])) { 
        $audio = time() . '_a_' . $_FILES['audio']['name']; 
        move_uploaded_file($_FILES['audio']['tmp_name'], "../uploads/" . $audio); 
    }
    if (!empty($_FILES['video_file']['name'])) { 
        $video_file = time() . '_v_' . $_FILES['video_file']['name']; 
        move_uploaded_file($_FILES['video_file']['tmp_name'], "../uploads/" . $video_file); 
    }
    if (!empty($_FILES['thumbnail']['name'])) { 
        $thumbnail = time() . '_t_' . $_FILES['thumbnail']['name']; 
        move_uploaded_file($_FILES['thumbnail']['tmp_name'], "../uploads/" . $thumbnail); 
    }

    $stmt_order = $pdo->query("SELECT MAX(sort_order) as max_order FROM podcasts");
    $max_order = $stmt_order->fetch()['max_order'] ?? 0;
    $new_order = $max_order + 1;

    $stmt = $pdo->prepare("INSERT INTO podcasts (title, title_en, description, description_en, audio_url, video_file, video_url, thumbnail, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt->execute([$title, $title_en, $description, $description_en, $audio, $video_file, $video_url, $thumbnail, $new_order])) { 
        $success = "تم إضافة البودكاست بنجاح!"; 
    }
}

// تعديل بودكاست
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_podcast'])) {
    $id = $_POST['id']; 
    $title = $_POST['title'];
    $title_en = $_POST['title_en'] ?? '';
    $description = $_POST['description'];
    $description_en = $_POST['description_en'] ?? '';
    $video_url = $_POST['video_url'];
    $audio = $_POST['old_audio']; 
    $video_file = $_POST['old_video_file']; 
    $thumbnail = $_POST['old_thumbnail'];
    
    if (!empty($_FILES['audio']['name'])) { 
        $audio = time() . '_a_' . $_FILES['audio']['name']; 
        move_uploaded_file($_FILES['audio']['tmp_name'], "../uploads/" . $audio); 
    }
    if (!empty($_FILES['video_file']['name'])) { 
        $video_file = time() . '_v_' . $_FILES['video_file']['name']; 
        move_uploaded_file($_FILES['video_file']['tmp_name'], "../uploads/" . $video_file); 
    }
    if (!empty($_FILES['thumbnail']['name'])) { 
        $thumbnail = time() . '_t_' . $_FILES['thumbnail']['name']; 
        move_uploaded_file($_FILES['thumbnail']['tmp_name'], "../uploads/" . $thumbnail); 
    }

    $stmt = $pdo->prepare("UPDATE podcasts SET title = ?, title_en = ?, description = ?, description_en = ?, audio_url = ?, video_file = ?, video_url = ?, thumbnail = ? WHERE id = ?");
    if ($stmt->execute([$title, $title_en, $description, $description_en, $audio, $video_file, $video_url, $thumbnail, $id])) { 
        $success = "تم تعديل البودكاست بنجاح!"; 
    }
}

// حذف وترتيب (مختصر)
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM podcasts WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: manage_podcasts.php"); exit;
}
if (isset($_GET['move']) && isset($_GET['id'])) {
    $id = $_GET['id']; $move = $_GET['move'];
    $stmt = $pdo->prepare("SELECT sort_order FROM podcasts WHERE id = ?");
    $stmt->execute([$id]); $current_order = $stmt->fetch()['sort_order'];
    if ($move == 'up') { $stmt = $pdo->prepare("SELECT id, sort_order FROM podcasts WHERE sort_order < ? ORDER BY sort_order DESC LIMIT 1"); }
    else { $stmt = $pdo->prepare("SELECT id, sort_order FROM podcasts WHERE sort_order > ? ORDER BY sort_order ASC LIMIT 1"); }
    $stmt->execute([$current_order]); $target = $stmt->fetch();
    if ($target) {
        $pdo->prepare("UPDATE podcasts SET sort_order = ? WHERE id = ?")->execute([$target['sort_order'], $id]);
        $pdo->prepare("UPDATE podcasts SET sort_order = ? WHERE id = ?")->execute([$current_order, $target['id']]);
    }
    header("Location: manage_podcasts.php"); exit;
}

$edit_data = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM podcasts WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $edit_data = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة البودكاست</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #2c3e50; color: #fff; position: fixed; top: 0; right: 0; padding: 20px 10px; overflow-y: auto; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.95rem; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }
        .main-content { margin-right: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 12px; }
        .lang-section-ar { border-right: 4px solid #cc0000; padding-right: 12px; }
        .lang-section-en { border-right: 4px solid #0066cc; padding-right: 12px; }
        .lang-badge-ar { background: #cc0000; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .lang-badge-en { background: #0066cc; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .auto-translate-badge { background: #28a745; color: #fff; padding: 2px 6px; border-radius: 5px; font-size: 0.7rem; margin-right: 5px; }
    </style>
</head>
<body>
<div class="sidebar">
    <h4 class="text-center mb-4 fw-bold">لوحة التحكم</h4>
    <a href="../index.php" target="_blank" class="btn btn-danger w-100 mb-3">عرض الموقع</a>
    <a href="manage_podcasts.php" class="active">البودكاست</a>
    <a href="manage_faqs.php">الأسئلة الشائعة</a>
    <hr>
    <a href="logout.php" class="text-danger">تسجيل الخروج</a>
</div>
<div class="main-content">
    <div class="container-fluid">
        <h2 class="mb-4 fw-bold">إدارة البودكاست</h2>
        <?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
        <div class="card mb-4">
            <div class="card-body p-4">
                <form method="POST" enctype="multipart/form-data">
                    <?php if($edit_data): ?>
                        <input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>">
                        <input type="hidden" name="old_audio" value="<?php echo $edit_data['audio_url']; ?>">
                        <input type="hidden" name="old_video_file" value="<?php echo $edit_data['video_file']; ?>">
                        <input type="hidden" name="old_thumbnail" value="<?php echo $edit_data['thumbnail']; ?>">
                    <?php endif; ?>
                    <div class="row g-3">
                        <!-- قسم العربية -->
                        <div class="col-12"><div class="lang-section-ar"><span class="lang-badge-ar">عربي</span></div></div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">عنوان الحلقة بالعربية</label>
                            <input type="text" name="title" id="title_ar" class="form-control" value="<?php echo htmlspecialchars($edit_data['title'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">الصورة الرمزية</label>
                            <input type="file" name="thumbnail" class="form-control" accept="image/*">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-bold">الوصف بالعربية</label>
                            <textarea name="description" id="description_ar" class="form-control" rows="3"><?php echo htmlspecialchars($edit_data['description'] ?? ''); ?></textarea>
                        </div>

                        <!-- قسم الإنجليزية -->
                        <div class="col-12 mt-3"><hr><div class="lang-section-en"><span class="lang-badge-en">English</span> <span class="auto-translate-badge">ترجمة تلقائية</span></div></div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Podcast Title (English)</label>
                            <input type="text" name="title_en" id="title_en" class="form-control" dir="ltr" value="<?php echo htmlspecialchars($edit_data['title_en'] ?? ''); ?>">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-bold">Description (English)</label>
                            <textarea name="description_en" id="description_en" class="form-control" rows="3" dir="ltr"><?php echo htmlspecialchars($edit_data['description_en'] ?? ''); ?></textarea>
                        </div>

                        <div class="col-12 mt-3"><hr><p class="fw-bold text-muted">ملفات الوسائط</p></div>
                        <div class="col-md-4"><label class="form-label fw-bold">ملف الصوت</label><input type="file" name="audio" class="form-control"></div>
                        <div class="col-md-4"><label class="form-label fw-bold">ملف الفيديو</label><input type="file" name="video_file" class="form-control"></div>
                        <div class="col-md-4"><label class="form-label fw-bold">رابط فيديو (YouTube)</label><input type="url" name="video_url" class="form-control" value="<?php echo htmlspecialchars($edit_data['video_url'] ?? ''); ?>"></div>

                        <div class="col-12 text-center mt-4">
                            <button type="submit" name="<?php echo $edit_data ? 'edit_podcast' : 'add_podcast'; ?>" class="btn btn-success px-5 fw-bold">حفظ الحلقة</button>
                            <?php if($edit_data): ?><a href="manage_podcasts.php" class="btn btn-secondary px-4">إلغاء</a><?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="card"><div class="card-body">
            <table class="table table-hover align-middle">
                <thead><tr><th>الترتيب</th><th>الصورة</th><th>الحلقة</th><th>العمليات</th></tr></thead>
                <tbody>
                    <?php
                    $stmt = $pdo->query("SELECT * FROM podcasts ORDER BY sort_order ASC, id DESC");
                    while ($row = $stmt->fetch()) {
                    ?>
                    <tr>
                        <td>
                            <a href="manage_podcasts.php?move=up&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-dark"><i class="fas fa-arrow-up"></i></a>
                            <a href="manage_podcasts.php?move=down&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-dark"><i class="fas fa-arrow-down"></i></a>
                        </td>
                        <td><img src="../uploads/<?php echo $row['thumbnail']; ?>" height="50" class="rounded"></td>
                        <td>
                            <strong><?php echo htmlspecialchars($row['title']); ?></strong>
                            <?php if(!empty($row['title_en'])): ?><br><small class="text-muted" dir="ltr"><?php echo htmlspecialchars($row['title_en']); ?></small><?php endif; ?>
                        </td>
                        <td>
                            <a href="manage_podcasts.php?edit=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning text-white"><i class="fas fa-edit"></i></a>
                            <a href="manage_podcasts.php?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد؟')"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div></div>
    </div>
</div>
<script src="auto_translate.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    liveTranslator.bindTranslationField('#title_ar', '#title_en', 800);
    liveTranslator.bindTranslationField('#description_ar', '#description_en', 1000);
});
</script>
</body>
</html>
