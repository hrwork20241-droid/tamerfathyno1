<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }
include '../includes/db.php';

// إضافة الأعمدة الإنجليزية والجديدة إذا لم تكن موجودة
try { $pdo->exec("ALTER TABLE collaborations ADD COLUMN title_en VARCHAR(255) DEFAULT NULL"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE collaborations ADD COLUMN description_en TEXT DEFAULT NULL"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE collaborations ADD COLUMN image VARCHAR(255) DEFAULT NULL"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE collaborations ADD COLUMN video_url VARCHAR(500) DEFAULT NULL"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE collaborations ADD COLUMN is_active TINYINT(1) DEFAULT 1"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE collaborations ADD COLUMN show_in_header TINYINT(1) DEFAULT 0"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE collaborations ADD COLUMN show_in_footer TINYINT(1) DEFAULT 0"); } catch (Exception $e) {}

$success = '';
$edit_data = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_collab'])) {
        $title = $_POST['title'];
        $title_en = $_POST['title_en'] ?? '';
        $description = $_POST['description'];
        $description_en = $_POST['description_en'] ?? '';
        $link = $_POST['link'];
        $show_header = isset($_POST['show_in_header']) ? 1 : 0;
        $show_footer = isset($_POST['show_in_footer']) ? 1 : 0;
        
        $image = '';
        if (!empty($_FILES['image']['name'])) {
            $image = time() . '_collab_' . $_FILES['image']['name'];
            move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $image);
        }
        
        $stmt = $pdo->prepare("INSERT INTO collaborations (title, title_en, description, description_en, link, image, show_in_header, show_in_footer, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, (SELECT IFNULL(MAX(sort_order), 0) + 1 FROM collaborations AS c))");
        if ($stmt->execute([$title, $title_en, $description, $description_en, $link, $image, $show_header, $show_footer])) { 
            header("Location: manage_collaborations.php?added=1");
            exit;
        }
    } elseif (isset($_POST['update_collab'])) {
        $id = $_POST['id'];
        $title = $_POST['title'];
        $title_en = $_POST['title_en'] ?? '';
        $description = $_POST['description'];
        $description_en = $_POST['description_en'] ?? '';
        $link = $_POST['link'];
        $video_url = $_POST['video_url'] ?? '';
        $show_header = isset($_POST['show_in_header']) ? 1 : 0;
        $show_footer = isset($_POST['show_in_footer']) ? 1 : 0;
        
        $image = $_POST['old_image'] ?? '';
        if (!empty($_FILES['image']['name'])) {
            $image = time() . '_collab_' . $_FILES['image']['name'];
            move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $image);
        }
        
        $stmt = $pdo->prepare("UPDATE collaborations SET title = ?, title_en = ?, description = ?, description_en = ?, link = ?, image = ?, video_url = ?, show_in_header = ?, show_in_footer = ? WHERE id = ?");
        if ($stmt->execute([$title, $title_en, $description, $description_en, $link, $image, $video_url, $show_header, $show_footer, $id])) { 
            header("Location: manage_collaborations.php?updated=1");
            exit;
        }
    }
}

if (isset($_GET['added'])) { $success = 'تم إضافة التعاون بنجاح!'; }
if (isset($_GET['updated'])) { $success = 'تم تحديث التعاون بنجاح!'; }

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM collaborations WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $edit_data = $stmt->fetch();
}

if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM collaborations WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: manage_collaborations.php"); exit;
}

$collaborations = $pdo->query("SELECT * FROM collaborations ORDER BY sort_order ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة صناع المحتوى</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #2c3e50; color: #fff; position: fixed; top: 0; right: 0; padding: 20px 10px; overflow-y: auto; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.95rem; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }
        .main-content { margin-right: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 12px; }
        .lang-section-ar { border-right: 4px solid #cc0000; padding-right: 12px; }
        .lang-section-en { border-right: 4px solid #0066cc; padding-right: 12px; }
        .lang-badge-ar { background: #cc0000; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .lang-badge-en { background: #0066cc; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .auto-translate-badge { background: #28a745; color: #fff; padding: 2px 6px; border-radius: 5px; font-size: 0.7rem; margin-right: 5px; }
    </style>
</head>
<body>
<div class="sidebar">
    <h4 class="text-center mb-4 fw-bold">لوحة التحكم</h4>
    <a href="../index.php" target="_blank" class="nav-view-site"><i class="fas fa-external-link-alt"></i> عرض الموقع</a>
    <a href="control_panel.php"><i class="fas fa-cog"></i> الإعدادات العامة</a>
    <a href="manage_about.php"><i class="fas fa-user"></i> من أنا</a>
    <a href="manage_programs.php"><i class="fas fa-tv"></i> البرامج</a>
    <a href="manage_blog.php"><i class="fas fa-blog"></i> المدونة</a>
    <a href="manage_gallery.php"><i class="fas fa-images"></i> الصور والكواليس</a>
    <a href="manage_awards.php"><i class="fas fa-trophy"></i> الجوائز</a>
    <a href="manage_podcasts.php"><i class="fas fa-microphone"></i> البودكاست</a>
    <a href="manage_events.php"><i class="fas fa-calendar-alt"></i> الفعاليات</a>
    <a href="manage_ticker.php"><i class="fas fa-bolt"></i> شريط الأخبار</a>
    <a href="manage_collaborations.php" class="active"><i class="fas fa-handshake"></i> صناع المحتوى</a>
    <a href="manage_faqs.php"><i class="fas fa-question-circle"></i> الأسئلة الشائعة</a>
    <a href="manage_messages.php"><i class="fas fa-envelope"></i> الرسائل</a>
    <a href="manage_pages.php"><i class="fas fa-file-circle-plus"></i> إدارة الصفحات</a>
    <a href="change_password.php"><i class="fas fa-key"></i> تغيير كلمة المرور</a>
    <hr>
    <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
</div>

<div class="main-content">
    <div class="container-fluid">
        <h2 class="mb-4 fw-bold">إدارة صناع المحتوى</h2>
        <?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>

        <div class="card mb-4">
            <div class="card-header bg-primary text-white fw-bold"><?php echo $edit_data ? 'تعديل التعاون' : 'إضافة تعاون جديد'; ?></div>
            <div class="card-body p-4">
                <form method="POST" enctype="multipart/form-data">
                    <?php if($edit_data): ?>
                        <input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>">
                        <input type="hidden" name="old_image" value="<?php echo $edit_data['image']; ?>">
                    <?php endif; ?>

                    <div class="row g-3">
                        <!-- قسم العربية -->
                        <div class="col-12"><div class="lang-section-ar"><span class="lang-badge-ar">عربي</span></div></div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">عنوان التعاون</label>
                            <input type="text" name="title" id="title_ar" class="form-control" value="<?php echo htmlspecialchars($edit_data['title'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">الرابط</label>
                            <input type="url" name="link" class="form-control" value="<?php echo htmlspecialchars($edit_data['link'] ?? ''); ?>" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-bold">الوصف</label>
                            <textarea name="description" id="description_ar" class="form-control" rows="3"><?php echo htmlspecialchars($edit_data['description'] ?? ''); ?></textarea>
                        </div>

                        <!-- قسم الإنجليزية -->
                        <div class="col-12 mt-3"><hr><div class="lang-section-en"><span class="lang-badge-en">English</span> <span class="auto-translate-badge">ترجمة تلقائية</span></div></div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Collaboration Title (EN)</label>
                            <input type="text" name="title_en" id="title_en" class="form-control" dir="ltr" value="<?php echo htmlspecialchars($edit_data['title_en'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6"></div>
                        <div class="col-12">
                            <label class="form-label fw-bold">Description (EN)</label>
                            <textarea name="description_en" id="description_en" class="form-control" rows="3" dir="ltr"><?php echo htmlspecialchars($edit_data['description_en'] ?? ''); ?></textarea>
                        </div>

                        <!-- الصور والفيديو -->
                        <div class="col-12 mt-3"><hr><h5 class="fw-bold text-info">الصور والفيديو</h5></div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">صورة التعاون</label>
                            <input type="file" name="image" class="form-control" accept="image/*">
                            <?php if(!empty($edit_data['image'])): ?>
                                <small class="text-muted">الصورة الحالية: <?php echo $edit_data['image']; ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">رابط الفيديو (YouTube)</label>
                            <input type="url" name="video_url" class="form-control" placeholder="https://youtube.com/..." value="<?php echo htmlspecialchars($edit_data['video_url'] ?? ''); ?>">
                        </div>

                        <!-- التحكم في الظهور -->
                        <div class="col-12 mt-3"><hr><h5 class="fw-bold text-info">التحكم في الظهور</h5></div>
                        <div class="col-md-6">
                            <div class="form-check">
                                <input type="checkbox" name="show_in_header" class="form-check-input" id="show_header" <?php echo (!isset($edit_data) || $edit_data['show_in_header']) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="show_header">عرض في الهيدر</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check">
                                <input type="checkbox" name="show_in_footer" class="form-check-input" id="show_footer" <?php echo (!isset($edit_data) || $edit_data['show_in_footer']) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="show_footer">عرض في الفوتر</label>
                            </div>
                        </div>

                        <div class="col-12 text-center mt-4">
                            <button type="submit" name="<?php echo $edit_data ? 'update_collab' : 'add_collab'; ?>" class="btn btn-success btn-lg px-5 fw-bold">
                                <?php echo $edit_data ? 'تحديث' : 'إضافة'; ?>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- قائمة التعاونات -->
        <div class="card">
            <div class="card-header bg-secondary text-white fw-bold">التعاونات الموجودة</div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>العنوان</th>
                            <th>الهيدر</th>
                            <th>الفوتر</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($collaborations as $collab): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($collab['title']); ?></td>
                            <td><span class="badge <?php echo $collab['show_in_header'] ? 'bg-success' : 'bg-secondary'; ?>">
                                <?php echo $collab['show_in_header'] ? 'نعم' : 'لا'; ?></span></td>
                            <td><span class="badge <?php echo $collab['show_in_footer'] ? 'bg-success' : 'bg-secondary'; ?>">
                                <?php echo $collab['show_in_footer'] ? 'نعم' : 'لا'; ?></span></td>
                            <td>
                                <a href="manage_collaborations.php?edit=<?php echo $collab['id']; ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                <a href="manage_collaborations.php?delete=<?php echo $collab['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد؟')"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="auto_translate.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    liveTranslator.bindTranslationField('#title_ar', '#title_en', 800);
    liveTranslator.bindTranslationField('#description_ar', '#description_en', 1000);
});
</script>
</body>
</html>
