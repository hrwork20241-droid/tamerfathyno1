<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }
include '../includes/db.php';

// تحديث قاعدة البيانات التلقائي
try {
    $pdo->exec("ALTER TABLE custom_pages ADD COLUMN IF NOT EXISTS title_en VARCHAR(255) DEFAULT NULL AFTER title");
    $pdo->exec("ALTER TABLE custom_pages ADD COLUMN IF NOT EXISTS meta_description_en VARCHAR(255) DEFAULT NULL AFTER meta_description");
    $pdo->exec("ALTER TABLE custom_pages ADD COLUMN IF NOT EXISTS content_en LONGTEXT AFTER content");
} catch (PDOException $e) { }

$success = '';
$error = '';
$edit_data = null;

function make_slug($text) {
    $text = trim($text);
    $text = preg_replace('/\s+/u', '-', $text);
    $text = preg_replace('/[^\p{Arabic}\p{L}\p{N}\-_]+/u', '-', $text);
    $text = preg_replace('/-+/', '-', $text);
    return trim($text, '-');
}

if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM custom_pages WHERE id = ?")->execute([(int) $_GET['delete']]);
    header("Location: manage_pages.php?deleted=1"); exit;
}

if (isset($_GET['toggle'])) {
    $pdo->prepare("UPDATE custom_pages SET is_active = IF(is_active = 1, 0, 1) WHERE id = ?")->execute([(int) $_GET['toggle']]);
    header("Location: manage_pages.php?toggled=1"); exit;
}

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM custom_pages WHERE id = ?");
    $stmt->execute([(int) $_GET['edit']]);
    $edit_data = $stmt->fetch();
}

if (isset($_GET['deleted'])) { $success = 'تم حذف الصفحة بنجاح.'; }
if (isset($_GET['toggled'])) { $success = 'تم تحديث حالة الصفحة بنجاح.'; }
if (isset($_GET['updated'])) { $success = 'تم تحديث الصفحة بنجاح.'; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $title_en = trim($_POST['title_en'] ?? '');
    $slug_input = trim($_POST['slug'] ?? '');
    $meta_description = trim($_POST['meta_description'] ?? '');
    $meta_description_en = trim($_POST['meta_description_en'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $content_en = trim($_POST['content_en'] ?? '');
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $show_in_home = isset($_POST['show_in_home']) ? 1 : 0;
    $display_location = $_POST['display_location'] ?? 'none';
    $sort_order = (int)($_POST['sort_order'] ?? 0);
    $slug = make_slug($slug_input !== '' ? $slug_input : $title);

    if ($title === '' || $content === '') {
        $error = 'يرجى إدخال عنوان الصفحة والمحتوى.';
    } else {
        if (isset($_POST['add_page'])) {
            $stmt = $pdo->prepare("INSERT INTO custom_pages (title, title_en, slug, meta_description, meta_description_en, content, content_en, is_active, display_location, show_in_home, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$title, $title_en, $slug, $meta_description, $meta_description_en, $content, $content_en, $is_active, $display_location, $show_in_home, $sort_order])) {
                $success = 'تم إنشاء الصفحة الجديدة بنجاح.';
            }
        }
        if (isset($_POST['edit_page'])) {
            $page_id = (int) ($_POST['page_id'] ?? 0);
            $stmt = $pdo->prepare("UPDATE custom_pages SET title = ?, title_en = ?, slug = ?, meta_description = ?, meta_description_en = ?, content = ?, content_en = ?, is_active = ?, display_location = ?, show_in_home = ?, sort_order = ? WHERE id = ?");
            if ($stmt->execute([$title, $title_en, $slug, $meta_description, $meta_description_en, $content, $content_en, $is_active, $display_location, $show_in_home, $sort_order, $page_id])) {
                header("Location: manage_pages.php?updated=1"); exit;
            }
        }
    }
}

$pages = $pdo->query("SELECT * FROM custom_pages ORDER BY sort_order ASC, id DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة الصفحات</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.tiny.cloud/1/d6i6qfdtjejdaj7tmki3r3180lhn7nagpexwc26vwzlos32z/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #2c3e50; color: #fff; position: fixed; top: 0; right: 0; padding: 20px 10px; overflow-y: auto; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.95rem; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }
        .main-content { margin-right: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 16px; }
        .nav-tabs .nav-link { color: #333; font-weight: bold; }
        .nav-tabs .nav-link.active { color: #cc0000; border-bottom: 3px solid #cc0000; }
        .auto-translate-badge { background: #28a745; color: #fff; padding: 2px 6px; border-radius: 5px; font-size: 0.7rem; margin-right: 10px; }
    </style>
</head>
<body>
<div class="sidebar">
    <h4 class="text-center mb-4 fw-bold">لوحة التحكم</h4>
    <a href="../index.php" target="_blank" class="btn btn-danger w-100 mb-3">عرض الموقع</a>
    <a href="manage_pages.php" class="active">إدارة الصفحات</a>
    <a href="manage_faqs.php">الأسئلة الشائعة</a>
    <hr>
    <?php foreach ($pages as $p): ?>
        <a href="manage_pages.php?edit=<?php echo $p['id']; ?>" style="font-size: 0.8rem;"><i class="fas fa-file-alt"></i> <?php echo htmlspecialchars($p['title']); ?></a>
    <?php endforeach; ?>
</div>
<div class="main-content">
    <div class="container-fluid">
        <h2 class="mb-4 fw-bold"><?php echo $edit_data ? 'تعديل صفحة' : 'إضافة صفحة جديدة'; ?></h2>
        <?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
        <form method="POST">
            <?php if($edit_data): ?><input type="hidden" name="page_id" value="<?php echo $edit_data['id']; ?>"><?php endif; ?>
            <div class="card mb-4">
                <div class="card-body p-4">
                    <ul class="nav nav-tabs mb-4" id="langTabs" role="tablist">
                        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#ar-content" type="button">العربية</button></li>
                        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#en-content" type="button">English <span class="auto-translate-badge">ترجمة تلقائية</span></button></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="ar-content">
                            <div class="row g-3">
                                <div class="col-md-6"><label class="form-label fw-bold">عنوان الصفحة</label><input type="text" name="title" id="title_ar" class="form-control" value="<?php echo htmlspecialchars($edit_data['title'] ?? ''); ?>"></div>
                                <div class="col-md-6"><label class="form-label fw-bold">الرابط (Slug)</label><input type="text" name="slug" class="form-control" value="<?php echo htmlspecialchars($edit_data['slug'] ?? ''); ?>"></div>
                                <div class="col-12"><label class="form-label fw-bold">وصف الميتا</label><input type="text" name="meta_description" id="meta_ar" class="form-control" value="<?php echo htmlspecialchars($edit_data['meta_description'] ?? ''); ?>"></div>
                                <div class="col-12"><label class="form-label fw-bold">المحتوى</label><textarea name="content" id="content_ar" class="form-control"><?php echo htmlspecialchars($edit_data['content'] ?? ''); ?></textarea></div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="en-content">
                            <div class="row g-3">
                                <div class="col-md-12"><label class="form-label fw-bold">Page Title (EN)</label><input type="text" name="title_en" id="title_en" class="form-control" dir="ltr" value="<?php echo htmlspecialchars($edit_data['title_en'] ?? ''); ?>"></div>
                                <div class="col-12"><label class="form-label fw-bold">Meta Description (EN)</label><input type="text" name="meta_description_en" id="meta_en" class="form-control" dir="ltr" value="<?php echo htmlspecialchars($edit_data['meta_description_en'] ?? ''); ?>"></div>
                                <div class="col-12"><label class="form-label fw-bold">Content (EN)</label><textarea name="content_en" id="content_en" class="form-control"><?php echo htmlspecialchars($edit_data['content_en'] ?? ''); ?></textarea></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card mb-4"><div class="card-body p-4">
                <div class="row g-3">
                    <div class="col-md-3"><div class="form-check form-switch mt-4"><input class="form-check-input" type="checkbox" name="is_active" <?php echo (!isset($edit_data) || $edit_data['is_active']) ? 'checked' : ''; ?>><label class="form-check-label fw-bold">صفحة نشطة</label></div></div>
                    <div class="col-md-3"><div class="form-check form-switch mt-4"><input class="form-check-input" type="checkbox" name="show_in_home" <?php echo ($edit_data['show_in_home'] ?? 0) ? 'checked' : ''; ?>><label class="form-check-label fw-bold">عرض في الرئيسية</label></div></div>
                    <div class="col-md-3"><label class="form-label fw-bold">مكان العرض</label><select name="display_location" class="form-select"><option value="none" <?php echo ($edit_data['display_location'] ?? '') == 'none' ? 'selected' : ''; ?>>لا يظهر في القوائم</option><option value="header" <?php echo ($edit_data['display_location'] ?? '') == 'header' ? 'selected' : ''; ?>>الهيدر</option><option value="footer" <?php echo ($edit_data['display_location'] ?? '') == 'footer' ? 'selected' : ''; ?>>الفوتر</option><option value="both" <?php echo ($edit_data['display_location'] ?? '') == 'both' ? 'selected' : ''; ?>>كلاهما</option></select></div>
                    <div class="col-md-3"><label class="form-label fw-bold">الترتيب</label><input type="number" name="sort_order" class="form-control" value="<?php echo $edit_data['sort_order'] ?? 0; ?>"></div>
                </div>
            </div></div>
            <div class="text-center mb-5"><button type="submit" name="<?php echo $edit_data ? 'edit_page' : 'add_page'; ?>" class="btn btn-success btn-lg px-5 fw-bold">حفظ الصفحة</button></div>
        </form>
    </div>
</div>
<script src="auto_translate.js"></script>
<script>
tinymce.init({
    selector: '#content_ar', language: 'ar', directionality: 'rtl', height: 400,
    plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table help wordcount',
    toolbar: 'undo redo | blocks | bold italic | alignleft aligncenter alignright | bullist numlist | link image',
    setup: function(editor) {
        editor.on('blur', function() {
            const content = editor.getContent({format: 'text'});
            if(content.trim() !== "") {
                liveTranslator.translateText(content, 'ar', 'en').then(translated => {
                    tinymce.get('content_en').setContent(translated);
                });
            }
        });
    }
});
tinymce.init({ selector: '#content_en', language: 'en', directionality: 'ltr', height: 400, plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table help wordcount', toolbar: 'undo redo | blocks | bold italic | alignleft aligncenter alignright | bullist numlist | link image' });
document.addEventListener('DOMContentLoaded', function() {
    liveTranslator.bindTranslationField('#title_ar', '#title_en', 800);
    liveTranslator.bindTranslationField('#meta_ar', '#meta_en', 1000);
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
