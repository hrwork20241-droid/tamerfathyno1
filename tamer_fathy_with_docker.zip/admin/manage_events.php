<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }
include '../includes/db.php';

// إضافة الأعمدة الإنجليزية إذا لم تكن موجودة
try { $pdo->exec("ALTER TABLE events ADD COLUMN title_en VARCHAR(255) DEFAULT NULL"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE events ADD COLUMN location_en VARCHAR(255) DEFAULT NULL"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE events ADD COLUMN description_en TEXT DEFAULT NULL"); } catch (Exception $e) {}

$success = '';
$edit_data = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_event'])) {
        $title       = $_POST['title'];
        $title_en    = $_POST['title_en'] ?? '';
        $location    = $_POST['location'];
        $location_en = $_POST['location_en'] ?? '';
        $event_date  = $_POST['event_date'];
        $description = $_POST['description'];
        $description_en = $_POST['description_en'] ?? '';
        $video_url   = $_POST['video_url'];
        $image = ''; $video_file = ''; $schedule_pdf = '';

        if (!empty($_FILES['image']['name'])) {
            $image = time() . '_img_' . basename($_FILES['image']['name']);
            move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $image);
        }
        if (!empty($_FILES['video_file']['name'])) {
            $video_file = time() . '_vid_' . basename($_FILES['video_file']['name']);
            move_uploaded_file($_FILES['video_file']['tmp_name'], "../uploads/" . $video_file);
        }
        if (!empty($_FILES['schedule_pdf']['name'])) {
            $schedule_pdf = time() . '_pdf_' . basename($_FILES['schedule_pdf']['name']);
            move_uploaded_file($_FILES['schedule_pdf']['tmp_name'], "../uploads/" . $schedule_pdf);
        }

        $stmt = $pdo->prepare("INSERT INTO events (title, title_en, location, location_en, event_date, description, description_en, image, video_file, video_url, schedule_pdf, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, (SELECT IFNULL(MAX(sort_order), 0) + 1 FROM events AS e))");
        if ($stmt->execute([$title, $title_en, $location, $location_en, $event_date, $description, $description_en, $image, $video_file, $video_url, $schedule_pdf])) {
            $success = "تم إضافة الفعالية بنجاح!";
        }

    } elseif (isset($_POST['update_event'])) {
        $id          = $_POST['id'];
        $title       = $_POST['title'];
        $title_en    = $_POST['title_en'] ?? '';
        $location    = $_POST['location'];
        $location_en = $_POST['location_en'] ?? '';
        $event_date  = $_POST['event_date'];
        $description = $_POST['description'];
        $description_en = $_POST['description_en'] ?? '';
        $video_url   = $_POST['video_url'];
        $image       = $_POST['old_image'];
        $video_file  = $_POST['old_video_file'];
        $schedule_pdf = $_POST['old_schedule_pdf'];

        if (!empty($_FILES['image']['name'])) {
            $image = time() . '_img_' . basename($_FILES['image']['name']);
            move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $image);
        }
        if (!empty($_FILES['video_file']['name'])) {
            $video_file = time() . '_vid_' . basename($_FILES['video_file']['name']);
            move_uploaded_file($_FILES['video_file']['tmp_name'], "../uploads/" . $video_file);
        }
        if (!empty($_FILES['schedule_pdf']['name'])) {
            $schedule_pdf = time() . '_pdf_' . basename($_FILES['schedule_pdf']['name']);
            move_uploaded_file($_FILES['schedule_pdf']['tmp_name'], "../uploads/" . $schedule_pdf);
        }

        $stmt = $pdo->prepare("UPDATE events SET title=?, title_en=?, location=?, location_en=?, event_date=?, description=?, description_en=?, image=?, video_file=?, video_url=?, schedule_pdf=? WHERE id=?");
        if ($stmt->execute([$title, $title_en, $location, $location_en, $event_date, $description, $description_en, $image, $video_file, $video_url, $schedule_pdf, $id])) {
            $success = "تم تحديث الفعالية بنجاح!";
        }
    }
}

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM events WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $edit_data = $stmt->fetch();
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $pdo->prepare("DELETE FROM events WHERE id = ?")->execute([$id]);
    header("Location: manage_events.php"); exit;
}

if (isset($_GET['move']) && isset($_GET['id'])) {
    $id   = $_GET['id'];
    $move = $_GET['move'];
    $stmt = $pdo->prepare("SELECT sort_order FROM events WHERE id = ?");
    $stmt->execute([$id]);
    $current_order = $stmt->fetchColumn();

    if ($move == 'up') {
        $stmt = $pdo->prepare("SELECT id, sort_order FROM events WHERE sort_order < ? ORDER BY sort_order DESC LIMIT 1");
    } else {
        $stmt = $pdo->prepare("SELECT id, sort_order FROM events WHERE sort_order > ? ORDER BY sort_order ASC LIMIT 1");
    }
    $stmt->execute([$current_order]);
    $swap = $stmt->fetch();

    if ($swap) {
        $pdo->prepare("UPDATE events SET sort_order = ? WHERE id = ?")->execute([$swap['sort_order'], $id]);
        $pdo->prepare("UPDATE events SET sort_order = ? WHERE id = ?")->execute([$current_order, $swap['id']]);
    }
    header("Location: manage_events.php"); exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة الفعاليات</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #2c3e50; color: #fff; position: fixed; top: 0; right: 0; padding: 20px 10px; overflow-y: auto; z-index: 1000; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.95rem; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }
        .main-content { margin-right: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 12px; }
        .btn-primary { background-color: #cc0000; border: none; }
        .btn-primary:hover { background-color: #a30000; }
        .nav-view-site { background: #cc0000 !important; margin-bottom: 20px !important; text-align: center; font-weight: bold; }
        .lang-section-ar { border-right: 4px solid #cc0000; padding-right: 12px; }
        .lang-section-en { border-right: 4px solid #0066cc; padding-right: 12px; }
        .lang-badge-ar { background: #cc0000; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .lang-badge-en { background: #0066cc; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .auto-translate-badge { background: #28a745; color: #fff; padding: 2px 6px; border-radius: 5px; font-size: 0.7rem; margin-right: 5px; }
    </style>
</head>
<body>
<div class="sidebar">
    <h4 class="text-center mb-4 fw-bold">لوحة التحكم</h4>
    <a href="../index.php" target="_blank" class="nav-view-site"><i class="fas fa-external-link-alt"></i> عرض الموقع</a>
    <a href="control_panel.php"><i class="fas fa-cog"></i> الإعدادات العامة</a>
    <a href="manage_events.php" class="active"><i class="fas fa-calendar-alt"></i> الفعاليات</a>
    <a href="manage_faqs.php"><i class="fas fa-question-circle"></i> الأسئلة الشائعة</a>
    <hr>
    <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
</div>

<div class="main-content">
    <div class="container-fluid">
        <h2 class="mb-4 fw-bold">إدارة الفعاليات</h2>
        <?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>

        <div class="card mb-4">
            <div class="card-header bg-primary text-white fw-bold"><?php echo $edit_data ? 'تعديل الفعالية' : 'إضافة فعالية جديدة'; ?></div>
            <div class="card-body p-4">
                <form method="POST" enctype="multipart/form-data">
                    <?php if($edit_data): ?>
                        <input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>">
                        <input type="hidden" name="old_image" value="<?php echo $edit_data['image'] ?? ''; ?>">
                        <input type="hidden" name="old_video_file" value="<?php echo $edit_data['video_file'] ?? ''; ?>">
                        <input type="hidden" name="old_schedule_pdf" value="<?php echo $edit_data['schedule_pdf'] ?? ''; ?>">
                    <?php endif; ?>

                    <div class="row g-3">
                        <!-- قسم العربية -->
                        <div class="col-12"><div class="lang-section-ar"><span class="lang-badge-ar">عربي</span></div></div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">عنوان الفعالية بالعربية</label>
                            <input type="text" name="title" id="title_ar" class="form-control" value="<?php echo htmlspecialchars($edit_data['title'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">الموقع بالعربية</label>
                            <input type="text" name="location" id="location_ar" class="form-control" value="<?php echo htmlspecialchars($edit_data['location'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-bold">الوصف بالعربية</label>
                            <textarea name="description" id="description_ar" class="form-control" rows="3"><?php echo htmlspecialchars($edit_data['description'] ?? ''); ?></textarea>
                        </div>

                        <!-- قسم الإنجليزية -->
                        <div class="col-12 mt-3"><hr><div class="lang-section-en"><span class="lang-badge-en">English</span> <span class="auto-translate-badge">ترجمة تلقائية</span></div></div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Event Title (English)</label>
                            <input type="text" name="title_en" id="title_en" class="form-control" dir="ltr" value="<?php echo htmlspecialchars($edit_data['title_en'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Location (English)</label>
                            <input type="text" name="location_en" id="location_en" class="form-control" dir="ltr" value="<?php echo htmlspecialchars($edit_data['location_en'] ?? ''); ?>">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-bold">Description (English)</label>
                            <textarea name="description_en" id="description_en" class="form-control" rows="3" dir="ltr"><?php echo htmlspecialchars($edit_data['description_en'] ?? ''); ?></textarea>
                        </div>

                        <div class="col-12 mt-3"><hr><p class="fw-bold text-muted">الوسائط والتاريخ</p></div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">التاريخ والوقت</label>
                            <input type="datetime-local" name="event_date" class="form-control" value="<?php echo $edit_data ? date('Y-m-d\TH:i', strtotime($edit_data['event_date'])) : ''; ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">صورة الفعالية</label>
                            <input type="file" name="image" class="form-control" accept="image/*">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">رابط فيديو (YouTube)</label>
                            <input type="url" name="video_url" class="form-control" value="<?php echo htmlspecialchars($edit_data['video_url'] ?? ''); ?>">
                        </div>

                        <div class="col-12 text-center mt-4">
                            <button type="submit" name="<?php echo $edit_data ? 'update_event' : 'add_event'; ?>" class="btn btn-success px-5 fw-bold">حفظ الفعالية</button>
                            <?php if($edit_data): ?><a href="manage_events.php" class="btn btn-secondary px-4">إلغاء</a><?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <table class="table table-hover align-middle">
                    <thead><tr><th>الفعالية</th><th>الموقع</th><th>التاريخ</th><th>العمليات</th></tr></thead>
                    <tbody>
                        <?php
                        $stmt = $pdo->query("SELECT * FROM events ORDER BY sort_order ASC, event_date DESC");
                        while ($row = $stmt->fetch()) {
                        ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($row['title']); ?></strong>
                                <?php if(!empty($row['title_en'])): ?><br><small class="text-muted" dir="ltr"><?php echo htmlspecialchars($row['title_en']); ?></small><?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($row['location']); ?></td>
                            <td><?php echo date('d/m/Y H:i', strtotime($row['event_date'])); ?></td>
                            <td>
                                <a href="manage_events.php?edit=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning text-white"><i class="fas fa-edit"></i></a>
                                <a href="manage_events.php?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد؟')"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="auto_translate.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    liveTranslator.bindTranslationField('#title_ar', '#title_en', 800);
    liveTranslator.bindTranslationField('#location_ar', '#location_en', 800);
    liveTranslator.bindTranslationField('#description_ar', '#description_en', 1000);
});
</script>
</body>
</html>
