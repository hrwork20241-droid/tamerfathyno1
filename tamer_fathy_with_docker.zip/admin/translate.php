<?php
/**
 * translate.php - نقطة نهاية API للترجمة من العربية إلى الإنجليزية
 * يستخدم Google Translate غير الرسمي لترجمة النصوص والـ HTML
 */

session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

header('Content-Type: application/json; charset=utf-8');

$text = $_POST['text'] ?? '';

if (empty(trim($text))) {
    echo json_encode(['translated' => '', 'original' => '']);
    exit;
}

/**
 * ترجمة نص عبر Google Translate غير الرسمي
 */
function translateViaGoogle($text) {
    // تقسيم النص إذا كان طويلاً (الحد الأقصى 5000 حرف لكل طلب)
    if (mb_strlen($text) > 4500) {
        return translateLongText($text);
    }
    
    $url = 'https://translate.googleapis.com/translate_a/single';
    $params = http_build_query([
        'client' => 'gtx',
        'sl'     => 'ar',
        'tl'     => 'en',
        'dt'     => 't',
        'q'      => $text
    ]);
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url . '?' . $params,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        CURLOPT_HTTPHEADER     => ['Accept: application/json'],
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($response === false || $httpCode !== 200) {
        return null;
    }
    
    $data = json_decode($response, true);
    
    if (!$data || !isset($data[0]) || !is_array($data[0])) {
        return null;
    }
    
    $translated = '';
    foreach ($data[0] as $item) {
        if (is_array($item) && isset($item[0])) {
            $translated .= $item[0];
        }
    }
    
    return $translated ?: null;
}

/**
 * ترجمة نص طويل عبر تقسيمه إلى أجزاء
 */
function translateLongText($text) {
    // تقسيم على أساس الفقرات
    $chunks = [];
    $paragraphs = preg_split('/(\n{2,}|<\/p>|<br\s*\/?>)/i', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
    
    $currentChunk = '';
    foreach ($paragraphs as $para) {
        if (mb_strlen($currentChunk . $para) > 4000) {
            if (!empty($currentChunk)) {
                $chunks[] = $currentChunk;
                $currentChunk = $para;
            } else {
                $chunks[] = $para;
            }
        } else {
            $currentChunk .= $para;
        }
    }
    if (!empty($currentChunk)) {
        $chunks[] = $currentChunk;
    }
    
    $translatedParts = [];
    foreach ($chunks as $chunk) {
        $translated = translateViaGoogle($chunk);
        $translatedParts[] = $translated ?? $chunk;
        usleep(200000); // تأخير 200ms بين الطلبات
    }
    
    return implode('', $translatedParts);
}

/**
 * ترجمة محتوى HTML مع الحفاظ على التنسيق
 */
function translateHtmlContent($html) {
    if (empty(trim($html))) {
        return '';
    }
    
    // التحقق إذا كان المحتوى يحتوي على HTML
    $hasHtml = $html !== strip_tags($html);
    
    if (!$hasHtml) {
        // نص عادي - ترجمة مباشرة
        return translateViaGoogle($html) ?? $html;
    }
    
    // محتوى HTML - نستخرج النصوص ونترجمها مع الحفاظ على التنسيق
    // نهج بسيط: ترجمة المحتوى كاملاً (Google يتعامل مع HTML بشكل جيد)
    $translated = translateViaGoogle($html);
    
    if ($translated) {
        return $translated;
    }
    
    // في حالة الفشل، نحاول ترجمة النص فقط
    $plainText = strip_tags($html);
    $translatedText = translateViaGoogle($plainText);
    
    if ($translatedText) {
        // استبدال النص في HTML
        return str_replace($plainText, $translatedText, $html);
    }
    
    return $html;
}

// تنفيذ الترجمة
$translated = translateHtmlContent($text);

if ($translated !== null && $translated !== $text) {
    echo json_encode([
        'translated' => $translated,
        'translatedText' => $translated,
        'original'   => $text,
        'success'    => true
    ], JSON_UNESCAPED_UNICODE);
} else {
    // إرجاع النص الأصلي في حالة الفشل
    echo json_encode([
        'translated' => $text,
        'translatedText' => $text,
        'original'   => $text,
        'success'    => false,
        'message'    => 'Translation failed, returning original text'
    ], JSON_UNESCAPED_UNICODE);
}
