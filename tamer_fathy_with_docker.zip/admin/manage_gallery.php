<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }
include '../includes/db.php';

// إضافة الأعمدة الإنجليزية إذا لم تكن موجودة
try { $pdo->exec("ALTER TABLE gallery ADD COLUMN title_en VARCHAR(255) DEFAULT NULL"); } catch (Exception $e) {}

$success = '';

// إضافة صورة جديدة
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_gallery'])) {
    $title = $_POST['title'];
    $title_en = $_POST['title_en'] ?? '';
    $image = '';
    if (!empty($_FILES['image']['name'])) {
        $image = time() . '_' . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $image);
    }
    
    try {
        $stmt_order = $pdo->query("SELECT MAX(sort_order) as max_order FROM gallery");
        $max_order = $stmt_order->fetch()['max_order'] ?? 0;
        $new_order = $max_order + 1;
        $stmt = $pdo->prepare("INSERT INTO gallery (title, title_en, image, sort_order) VALUES (?, ?, ?, ?)");
        $stmt->execute([$title, $title_en, $image, $new_order]);
    } catch (PDOException $e) {
        $stmt = $pdo->prepare("INSERT INTO gallery (title, title_en, image) VALUES (?, ?, ?)");
        $stmt->execute([$title, $title_en, $image]);
    }
    header("Location: manage_gallery.php?added=1");
    exit;
}

// تعديل صورة
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_gallery'])) {
    $id = $_POST['id']; 
    $title = $_POST['title'];
    $title_en = $_POST['title_en'] ?? '';
    $image = $_POST['old_image'];
    if (!empty($_FILES['image']['name'])) {
        $image = time() . '_' . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $image);
    }
    
    $stmt = $pdo->prepare("UPDATE gallery SET title = ?, title_en = ?, image = ? WHERE id = ?");
    $stmt->execute([$title, $title_en, $image, $id]);
    header("Location: manage_gallery.php?edited=1");
    exit;
}

// حذف صورة
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM gallery WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: manage_gallery.php"); exit;
}

// تغيير الترتيب
if (isset($_GET['move']) && isset($_GET['id'])) {
    try {
        $id = $_GET['id']; $move = $_GET['move'];
        $stmt = $pdo->prepare("SELECT sort_order FROM gallery WHERE id = ?");
        $stmt->execute([$id]);
        $current_order = $stmt->fetch()['sort_order'];
        if ($move == 'up') {
            $stmt = $pdo->prepare("SELECT id, sort_order FROM gallery WHERE sort_order < ? ORDER BY sort_order DESC LIMIT 1");
        } else {
            $stmt = $pdo->prepare("SELECT id, sort_order FROM gallery WHERE sort_order > ? ORDER BY sort_order ASC LIMIT 1");
        }
        $stmt->execute([$current_order]);
        $target = $stmt->fetch();
        if ($target) {
            $pdo->prepare("UPDATE gallery SET sort_order = ? WHERE id = ?")->execute([$target['sort_order'], $id]);
            $pdo->prepare("UPDATE gallery SET sort_order = ? WHERE id = ?")->execute([$current_order, $target['id']]);
        }
    } catch (PDOException $e) {}
    header("Location: manage_gallery.php"); exit;
}

$success = '';
if (isset($_GET['added'])) { $success = 'تم إضافة الصورة بنجاح!'; }
if (isset($_GET['edited'])) { $success = 'تم تعديل الصورة بنجاح!'; }

$edit_data = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM gallery WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $edit_data = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة معرض الصور</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #2c3e50; color: #fff; position: fixed; top: 0; right: 0; padding: 20px 10px; overflow-y: auto; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.95rem; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }
        .main-content { margin-right: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 12px; }
        .btn-primary { background-color: #cc0000; border: none; }
        .btn-primary:hover { background-color: #a30000; }
        .nav-view-site { background: #cc0000 !important; margin-bottom: 20px !important; text-align: center; font-weight: bold; }
        .lang-section-ar { border-right: 4px solid #cc0000; padding-right: 12px; }
        .lang-section-en { border-right: 4px solid #0066cc; padding-right: 12px; }
        .lang-badge-ar { background: #cc0000; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .lang-badge-en { background: #0066cc; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .auto-translate-badge { background: #28a745; color: #fff; padding: 2px 6px; border-radius: 5px; font-size: 0.7rem; margin-right: 5px; }
    </style>
</head>
<body>
<div class="sidebar">
    <h4 class="text-center mb-4 fw-bold">لوحة التحكم</h4>
    <a href="../index.php" target="_blank" class="nav-view-site"><i class="fas fa-external-link-alt"></i> عرض الموقع</a>
    <a href="control_panel.php"><i class="fas fa-cog"></i> الإعدادات العامة</a>
    <a href="manage_about.php"><i class="fas fa-user"></i> من أنا</a>
    <a href="manage_programs.php"><i class="fas fa-tv"></i> البرامج</a>
    <a href="manage_blog.php"><i class="fas fa-blog"></i> المدونة</a>
    <a href="manage_gallery.php" class="active"><i class="fas fa-images"></i> الصور والكواليس</a>
    <a href="manage_awards.php"><i class="fas fa-trophy"></i> الجوائز</a>
    <a href="manage_podcasts.php"><i class="fas fa-microphone"></i> البودكاست</a>
    <a href="manage_events.php"><i class="fas fa-calendar-alt"></i> الفعاليات</a>
    <a href="manage_ticker.php"><i class="fas fa-bolt"></i> شريط الأخبار</a>
    <a href="manage_collaborations.php"><i class="fas fa-handshake"></i> صناع المحتوى</a>
    <a href="manage_faqs.php"><i class="fas fa-question-circle"></i> الأسئلة الشائعة</a>
    <a href="manage_messages.php"><i class="fas fa-envelope"></i> الرسالل</a>
    <a href="manage_pages.php"><i class="fas fa-file-circle-plus"></i> إدارة الصفحات</a>
    <a href="change_password.php"><i class="fas fa-key"></i> تغيير كلمة المرور</a>
    <hr>
    <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
</div>
<div class="main-content">
    <div class="container-fluid">
        <h2 class="mb-4 fw-bold">إدارة معرض الصور</h2>
        <?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
        <div class="card mb-4">
            <div class="card-header bg-primary text-white fw-bold"><?php echo $edit_data ? 'تعديل صورة' : 'إضافة صورة جديدة'; ?></div>
            <div class="card-body">
                <form method="POST" action="manage_gallery.php" enctype="multipart/form-data" id="galleryForm">
                    <?php if($edit_data): ?>
                        <input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>"><input type="hidden" name="old_image" value="<?php echo $edit_data['image']; ?>">
                    <?php endif; ?>
                    <div class="row g-3">
                        <!-- قسم العربية -->
                        <div class="col-12"><div class="lang-section-ar"><span class="lang-badge-ar">عربي</span></div></div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">عنوان الصورة بالعربية</label>
                            <input type="text" name="title" id="title_ar" class="form-control" value="<?php echo htmlspecialchars($edit_data['title'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">اختيار الصورة</label>
                            <input type="file" name="image" class="form-control" accept="image/*">
                        </div>

                        <!-- قسم الإنجليزية -->
                        <div class="col-12 mt-3"><hr><div class="lang-section-en"><span class="lang-badge-en">English</span> <span class="auto-translate-badge">ترجمة تلقائية</span></div></div>
                        <div class="col-12">
                            <label class="form-label fw-bold">Image Title (English)</label>
                            <input type="text" name="title_en" id="title_en" class="form-control" dir="ltr" value="<?php echo htmlspecialchars($edit_data['title_en'] ?? ''); ?>">
                        </div>

                        <div class="col-12 text-center d-flex justify-content-center gap-3 mt-4">
                            <button type="submit" name="<?php echo $edit_data ? 'edit_gallery' : 'add_gallery'; ?>" class="btn btn-success px-5 fw-bold"><i class="fas fa-save me-1"></i> <?php echo $edit_data ? 'تحديث نهائي' : 'إضافة واعتماد'; ?></button>
                            <?php if($edit_data): ?><a href="manage_gallery.php" class="btn btn-secondary px-4">إلغاء</a><?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="card"><div class="card-body">
            <table class="table table-hover align-middle text-center">
                <thead><tr><th>الترتيب</th><th>الصورة</th><th>العنوان</th><th>العمليات</th></tr></thead>
                <tbody>
                    <?php
                    $stmt = $pdo->query("SELECT * FROM gallery ORDER BY sort_order ASC, id DESC");
                    while ($row = $stmt->fetch()) {
                    ?>
                    <tr>
                        <td>
                            <a href="manage_gallery.php?move=up&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-dark"><i class="fas fa-arrow-up"></i></a>
                            <a href="manage_gallery.php?move=down&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-dark"><i class="fas fa-arrow-down"></i></a>
                        </td>
                        <td><img src="../uploads/<?php echo $row['image']; ?>" height="60" class="rounded shadow-sm"></td>
                        <td class="text-start">
                            <strong><?php echo htmlspecialchars($row['title']); ?></strong>
                            <?php if(!empty($row['title_en'])): ?><br><small class="text-muted" dir="ltr"><?php echo htmlspecialchars($row['title_en']); ?></small><?php endif; ?>
                        </td>
                        <td>
                            <a href="manage_gallery.php?edit=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning text-white"><i class="fas fa-edit"></i></a>
                            <a href="manage_gallery.php?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد؟')"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div></div>
    </div>
</div>
<script src="auto_translate.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    liveTranslator.bindTranslationField('#title_ar', '#title_en', 800);
});
</script>
</body>
</html>
