<?php
/**
 * ملف مساعد لإصلاح مشكلة الرفع
 * قم بزيارة هذا الملف مرة واحدة لإنشاء مجلد uploads وإصلاح الصلاحيات
 */

$uploads_dir = '../uploads';

// إنشاء المجلد إذا لم يكن موجوداً
if (!is_dir($uploads_dir)) {
    if (mkdir($uploads_dir, 0755, true)) {
        echo "<div style='direction:rtl; text-align:right; padding:20px; background:#d4edda; border:1px solid #c3e6cb; border-radius:5px; margin:20px;'>";
        echo "<h3 style='color:green;'>✓ تم إنشاء مجلد uploads بنجاح!</h3>";
        echo "<p>يمكنك الآن محاولة رفع الملفات من جديد في الإعدادات العامة.</p>";
        echo "</div>";
    } else {
        echo "<div style='direction:rtl; text-align:right; padding:20px; background:#f8d7da; border:1px solid #f5c6cb; border-radius:5px; margin:20px;'>";
        echo "<h3 style='color:red;'>✗ فشل إنشاء المجلد</h3>";
        echo "<p>تأكد من أن لديك صلاحيات الكتابة على السيرفر.</p>";
        echo "</div>";
    }
} else {
    echo "<div style='direction:rtl; text-align:right; padding:20px; background:#d1ecf1; border:1px solid #bee5eb; border-radius:5px; margin:20px;'>";
    echo "<h3 style='color:blue;'>✓ مجلد uploads موجود بالفعل</h3>";
    echo "<p>يمكنك الآن محاولة رفع الملفات من جديد.</p>";
    echo "</div>";
}

// التحقق من الصلاحيات
if (is_writable($uploads_dir)) {
    echo "<div style='direction:rtl; text-align:right; padding:20px; background:#d4edda; border:1px solid #c3e6cb; border-radius:5px; margin:20px;'>";
    echo "<h3 style='color:green;'>✓ الصلاحيات صحيحة</h3>";
    echo "<p>المجلد قابل للكتابة والرفع يجب أن يعمل بشكل صحيح الآن.</p>";
    echo "</div>";
} else {
    echo "<div style='direction:rtl; text-align:right; padding:20px; background:#f8d7da; border:1px solid #f5c6cb; border-radius:5px; margin:20px;'>";
    echo "<h3 style='color:red;'>✗ مشكلة في الصلاحيات</h3>";
    echo "<p>المجلد موجود لكن لا يمكن الكتابة عليه. تأكد من الصلاحيات (chmod 755).</p>";
    echo "</div>";
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إصلاح مشكلة الرفع</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f6f9; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; }
    </style>
</head>
<body>
<div class="container">
    <h1 style="text-align:center; color:#333;">إصلاح مشكلة رفع الملفات</h1>
    <p style="text-align:center; color:#666;">تم التحقق من حالة مجلد uploads والصلاحيات</p>
</div>
</body>
</html>
