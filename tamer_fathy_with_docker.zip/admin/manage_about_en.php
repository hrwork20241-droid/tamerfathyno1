<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { 
    header("Location: login.php"); 
    exit; 
}
include '../includes/db.php';

$success = '';
if (isset($pdo)) {
    $stmt = $pdo->query("SELECT * FROM about_me LIMIT 1");
    $about = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($pdo)) {
    $content_en = $_POST['content_en']; 
    
    if ($about) {
        $stmt = $pdo->prepare("UPDATE about_me SET content_en = ? WHERE id = ?");
        $stmt->execute([$content_en, $about['id']]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO about_me (content_en) VALUES (?)");
        $stmt->execute([$content_en]);
    }
    $success = "About Me (English) updated successfully!";
    $stmt = $pdo->query("SELECT * FROM about_me LIMIT 1"); 
    $about = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage About Me - Control Panel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- TinyMCE Editor -->
    <script src="https://cdn.tiny.cloud/1/d6i6qfdtjejdaj7tmki3r3180lhn7nagpexwc26vwzlos32z/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    
    <script>
        tinymce.init({
            selector: 'textarea[name="content_en"]',
            language: 'en',
            directionality: 'ltr',
            plugins: 'advlist autolink lists link image charmap preview anchor searchreplace vertical-align visualblocks code fullscreen insertdatetime media table code help wordcount',
            toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
            font_size_formats: '8pt 10pt 12pt 14pt 16pt 18pt 24pt 36pt 48pt',
            content_style: 'body { font-family:Poppins,Helvetica,Arial,sans-serif; font-size:14px }',
            branding: false,
            promotion: false,
            setup: function (editor) {
                editor.on('change', function () {
                    editor.save();
                });
            }
        });
    </script>

    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #2c3e50; color: #fff; position: fixed; top: 0; left: 0; padding: 20px 10px; overflow-y: auto; z-index: 1000; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.95rem; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }
        .sidebar a i { width: 25px; }
        .main-content { margin-left: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 12px; }
        .btn-primary { background-color: #cc0000; border: none; }
        .btn-primary:hover { background-color: #a30000; }
        .nav-view-site { background: #cc0000 !important; margin-bottom: 20px !important; text-align: center; font-weight: bold; }
        .alert { border-radius: 8px; }
    </style>
</head>
<body>
<div class="sidebar">
    <h4 class="text-center mb-4 fw-bold">Control Panel</h4>
    <a href="../index_en.php" target="_blank" class="nav-view-site"><i class="fas fa-external-link-alt"></i> View Website</a>
    <a href="control_panel_en.php"><i class="fas fa-cog"></i> General Settings</a>
    <a href="manage_about_en.php" class="active"><i class="fas fa-user"></i> About Me</a>
    <a href="manage_programs_en.php"><i class="fas fa-tv"></i> Programs</a>
    <a href="manage_blog_en.php"><i class="fas fa-blog"></i> Blog</a>
    <a href="manage_gallery_en.php"><i class="fas fa-images"></i> Gallery</a>
    <a href="manage_awards_en.php"><i class="fas fa-trophy"></i> Awards</a>
    <a href="manage_podcasts_en.php"><i class="fas fa-microphone"></i> Podcasts</a>
    <a href="manage_events_en.php"><i class="fas fa-calendar-alt"></i> Events</a>
    <a href="manage_collaborations_en.php"><i class="fas fa-handshake"></i> Collaborations</a>
    <a href="manage_faqs_en.php"><i class="fas fa-question-circle"></i> FAQs</a>
    <a href="manage_messages.php"><i class="fas fa-envelope"></i> Messages</a>
    <hr>
    <a href="manage_about.php" style="color: #ffc107 !important;"><i class="fas fa-language"></i> لوحة التحكم العربية</a>
    <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main-content">
    <div class="container-fluid">
        <div class="row mb-4">
            <div class="col-12">
                <h1 class="fw-bold text-danger mb-3"><i class="fas fa-user"></i> Manage About Me</h1>
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-8">
                <div class="card p-4">
                    <h5 class="fw-bold mb-4 text-danger"><i class="fas fa-edit"></i> Edit About Me Content (English)</h5>
                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-4">
                            <label class="form-label fw-bold">Content (English)</label>
                            <textarea name="content_en" class="form-control" rows="10" required><?php echo htmlspecialchars($about['content_en'] ?? ''); ?></textarea>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary btn-lg fw-bold">
                                <i class="fas fa-save"></i> Save Changes
                            </button>
                            <button type="button" class="btn btn-outline-secondary btn-lg fw-bold" onclick="previewContent()">
                                <i class="fas fa-eye"></i> Preview
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card p-4 bg-light">
                    <h5 class="fw-bold mb-3 text-danger"><i class="fas fa-info-circle"></i> Information</h5>
                    <p class="text-muted">
                        <strong>Note:</strong> This section manages the English version of the "About Me" page. 
                        The Arabic version is managed separately in the Arabic Control Panel.
                    </p>
                    <hr>
                    <p class="text-muted small">
                        <i class="fas fa-lightbulb"></i> <strong>Tip:</strong> Use the editor toolbar to format your text, add links, and insert images.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function previewContent() {
    const content = tinymce.get('content_en').getContent();
    const previewWindow = window.open('', 'Preview', 'width=800,height=600');
    previewWindow.document.write(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Preview - About Me</title>
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
            <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
            <style>
                body { font-family: 'Poppins', sans-serif; padding: 20px; }
                .preview-container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            </style>
        </head>
        <body>
            <div class="preview-container">
                <h2 class="fw-bold text-danger mb-4">About Me - Preview</h2>
                <div class="content-preview">
                    ${content}
                </div>
            </div>
        </body>
        </html>
    `);
    previewWindow.document.close();
}
</script>
</body>
</html>
