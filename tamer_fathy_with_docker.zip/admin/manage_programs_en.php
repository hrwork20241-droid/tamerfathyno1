<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }
include '../includes/db.php';
$success = '';

// Add program (English)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_program'])) {
    $title_en = $_POST['title_en']; 
    $description_en = $_POST['description_en']; 
    $channel_en = $_POST['channel_en']; 
    $seasons = $_POST['seasons']; 
    $video_url = $_POST['video_url'];
    
    try {
        $stmt_order = $pdo->query("SELECT MAX(sort_order) as max_order FROM programs");
        $max_order = $stmt_order->fetch()['max_order'] ?? 0;
        $new_order = $max_order + 1;
        $stmt = $pdo->prepare("INSERT INTO programs (title_en, description_en, channel_en, seasons, video_url, sort_order) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$title_en, $description_en, $channel_en, $seasons, $video_url, $new_order]);
    } catch (PDOException $e) {
        $stmt = $pdo->prepare("INSERT INTO programs (title_en, description_en, channel_en, seasons) VALUES (?, ?, ?, ?)");
        $stmt->execute([$title_en, $description_en, $channel_en, $seasons]);
    }
    $success = "Program added successfully!";
}

// Edit program (English)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_program'])) {
    $id = $_POST['id']; 
    $title_en = $_POST['title_en']; 
    $description_en = $_POST['description_en']; 
    $channel_en = $_POST['channel_en']; 
    $seasons = $_POST['seasons']; 
    $video_url = $_POST['video_url'];
    
    try {
        $stmt = $pdo->prepare("UPDATE programs SET title_en = ?, description_en = ?, channel_en = ?, seasons = ?, video_url = ? WHERE id = ?");
        $stmt->execute([$title_en, $description_en, $channel_en, $seasons, $video_url, $id]);
    } catch (PDOException $e) {
        $stmt = $pdo->prepare("UPDATE programs SET title_en = ?, description_en = ?, channel_en = ? WHERE id = ?");
        $stmt->execute([$title_en, $description_en, $channel_en, $id]);
    }
    $success = "Program updated successfully!";
}

// Delete program
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM programs WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: manage_programs_en.php"); exit;
}

// Move program order
if (isset($_GET['move']) && isset($_GET['id'])) {
    try {
        $id = $_GET['id']; $move = $_GET['move'];
        $stmt = $pdo->prepare("SELECT sort_order FROM programs WHERE id = ?");
        $stmt->execute([$id]);
        $current_order = $stmt->fetch()['sort_order'];
        if ($move == 'up') {
            $stmt = $pdo->prepare("SELECT id, sort_order FROM programs WHERE sort_order < ? ORDER BY sort_order DESC LIMIT 1");
        } else {
            $stmt = $pdo->prepare("SELECT id, sort_order FROM programs WHERE sort_order > ? ORDER BY sort_order ASC LIMIT 1");
        }
        $stmt->execute([$current_order]);
        $target = $stmt->fetch();
        if ($target) {
            $pdo->prepare("UPDATE programs SET sort_order = ? WHERE id = ?")->execute([$target['sort_order'], $id]);
            $pdo->prepare("UPDATE programs SET sort_order = ? WHERE id = ?")->execute([$current_order, $target['id']]);
        }
    } catch (PDOException $e) {}
    header("Location: manage_programs_en.php"); exit;
}

$edit_data = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM programs WHERE id = ?");
    $stmt->execute([$id]);
    $edit_data = $stmt->fetch();
}

$stmt = $pdo->query("SELECT * FROM programs ORDER BY sort_order ASC");
$programs = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Programs - Control Panel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <script src="https://cdn.tiny.cloud/1/d6i6qfdtjejdaj7tmki3r3180lhn7nagpexwc26vwzlos32z/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
        tinymce.init({
            selector: 'textarea[name="description_en"]',
            language: 'en',
            directionality: 'ltr',
            plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table code help wordcount',
            toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
            content_style: 'body { font-family:Poppins,Helvetica,Arial,sans-serif; font-size:14px }',
            branding: false,
            promotion: false
        });
    </script>

    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #2c3e50; color: #fff; position: fixed; top: 0; left: 0; padding: 20px 10px; overflow-y: auto; z-index: 1000; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.95rem; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }
        .sidebar a i { width: 25px; }
        .main-content { margin-left: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 12px; }
        .btn-primary { background-color: #cc0000; border: none; }
        .btn-primary:hover { background-color: #a30000; }
        .nav-view-site { background: #cc0000 !important; margin-bottom: 20px !important; text-align: center; font-weight: bold; }
        .table-hover tbody tr:hover { background-color: #f8f9fa; }
    </style>
</head>
<body>
<div class="sidebar">
    <h4 class="text-center mb-4 fw-bold">Control Panel</h4>
    <a href="../index_en.php" target="_blank" class="nav-view-site"><i class="fas fa-external-link-alt"></i> View Website</a>
    <a href="control_panel_en.php"><i class="fas fa-cog"></i> General Settings</a>
    <a href="manage_about_en.php"><i class="fas fa-user"></i> About Me</a>
    <a href="manage_programs_en.php" class="active"><i class="fas fa-tv"></i> Programs</a>
    <a href="manage_blog_en.php"><i class="fas fa-blog"></i> Blog</a>
    <a href="manage_gallery_en.php"><i class="fas fa-images"></i> Gallery</a>
    <a href="manage_awards_en.php"><i class="fas fa-trophy"></i> Awards</a>
    <a href="manage_podcasts_en.php"><i class="fas fa-microphone"></i> Podcasts</a>
    <a href="manage_events_en.php"><i class="fas fa-calendar-alt"></i> Events</a>
    <a href="manage_collaborations_en.php"><i class="fas fa-handshake"></i> Collaborations</a>
    <a href="manage_faqs_en.php"><i class="fas fa-question-circle"></i> FAQs</a>
    <a href="manage_messages.php"><i class="fas fa-envelope"></i> Messages</a>
    <hr>
    <a href="manage_programs.php" style="color: #ffc107 !important;"><i class="fas fa-language"></i> لوحة التحكم العربية</a>
    <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main-content">
    <div class="container-fluid">
        <div class="row mb-4">
            <div class="col-12">
                <h1 class="fw-bold text-danger mb-3"><i class="fas fa-tv"></i> Manage Programs</h1>
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-8">
                <div class="card p-4 mb-4">
                    <h5 class="fw-bold mb-4 text-danger"><i class="fas fa-<?php echo $edit_data ? 'edit' : 'plus'; ?>"></i> <?php echo $edit_data ? 'Edit Program' : 'Add New Program'; ?></h5>
                    <form method="POST" enctype="multipart/form-data">
                        <?php if ($edit_data): ?>
                            <input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>">
                        <?php endif; ?>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Program Title (English)</label>
                            <input type="text" name="title_en" class="form-control" value="<?php echo htmlspecialchars($edit_data['title_en'] ?? ''); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Description (English)</label>
                            <textarea name="description_en" class="form-control" rows="6"><?php echo htmlspecialchars($edit_data['description_en'] ?? ''); ?></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Channel (English)</label>
                                <input type="text" name="channel_en" class="form-control" value="<?php echo htmlspecialchars($edit_data['channel_en'] ?? 'Al Hadath Today'); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Seasons</label>
                                <input type="text" name="seasons" class="form-control" value="<?php echo htmlspecialchars($edit_data['seasons'] ?? '2'); ?>">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Video URL (YouTube)</label>
                            <input type="url" name="video_url" class="form-control" value="<?php echo htmlspecialchars($edit_data['video_url'] ?? ''); ?>" placeholder="https://youtube.com/...">
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" name="<?php echo $edit_data ? 'edit_program' : 'add_program'; ?>" class="btn btn-primary btn-lg fw-bold">
                                <i class="fas fa-<?php echo $edit_data ? 'save' : 'plus'; ?>"></i> <?php echo $edit_data ? 'Update Program' : 'Add Program'; ?>
                            </button>
                            <?php if ($edit_data): ?>
                                <a href="manage_programs_en.php" class="btn btn-secondary btn-lg fw-bold">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card p-4 bg-light">
                    <h5 class="fw-bold mb-3 text-danger"><i class="fas fa-info-circle"></i> Information</h5>
                    <p class="text-muted small">
                        <strong>Note:</strong> This section manages the English version of programs. The Arabic version is managed separately in the Arabic Control Panel.
                    </p>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-12">
                <div class="card p-4">
                    <h5 class="fw-bold mb-4 text-danger"><i class="fas fa-list"></i> Programs List</h5>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Title (EN)</th>
                                    <th>Channel (EN)</th>
                                    <th>Seasons</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($programs as $program): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($program['title_en'] ?? 'N/A'); ?></strong></td>
                                        <td><?php echo htmlspecialchars($program['channel_en'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($program['seasons'] ?? '2'); ?></td>
                                        <td>
                                            <a href="?edit=<?php echo $program['id']; ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i> Edit</a>
                                            <a href="?delete=<?php echo $program['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this program?');"><i class="fas fa-trash"></i> Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
