<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }
include '../includes/db.php';

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS news_ticker (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title_ar VARCHAR(255) NOT NULL,
        title_en VARCHAR(255) DEFAULT NULL,
        content_ar LONGTEXT DEFAULT NULL,
        content_en LONGTEXT DEFAULT NULL,
        image VARCHAR(255) DEFAULT NULL,
        link VARCHAR(255) DEFAULT NULL,
        is_active TINYINT(1) DEFAULT 1,
        sort_order INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (PDOException $e) { }

try { $pdo->exec("ALTER TABLE news_ticker ADD COLUMN content_ar LONGTEXT DEFAULT NULL"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE news_ticker ADD COLUMN content_en LONGTEXT DEFAULT NULL"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE news_ticker ADD COLUMN image VARCHAR(255) DEFAULT NULL"); } catch (Exception $e) {}

$success = '';
$error = '';
$edit_data = null;

if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM news_ticker WHERE id = ?");
    $stmt->execute([(int) $_GET['delete']]);
    header("Location: manage_ticker.php?deleted=1");
    exit;
}

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM news_ticker WHERE id = ?");
    $stmt->execute([(int) $_GET['edit']]);
    $edit_data = $stmt->fetch();
}

if (isset($_GET['added'])) { $success = 'تم إضافة الخبر بنجاح.'; }
if (isset($_GET['deleted'])) { $success = 'تم حذف الخبر بنجاح.'; }
if (isset($_GET['updated'])) { $success = 'تم تحديث الخبر بنجاح.'; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title_ar = trim($_POST['title_ar'] ?? '');
    $title_en = trim($_POST['title_en'] ?? '');
    $content_ar = $_POST['content_ar'] ?? '';
    $content_en = $_POST['content_en'] ?? '';
    $link = trim($_POST['link'] ?? '');
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $sort_order = (int)($_POST['sort_order'] ?? 0);
    
    $image = $_POST['old_image'] ?? '';
    if (!empty($_FILES['image']['name'])) {
        $image = time() . '_' . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $image);
    }

    if ($title_ar === '') {
        $error = 'يرجى إدخال عنوان الخبر بالعربية.';
    } else {
        if (isset($_POST['add_news'])) {
            $stmt = $pdo->prepare("INSERT INTO news_ticker (title_ar, title_en, content_ar, content_en, image, link, is_active, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$title_ar, $title_en, $content_ar, $content_en, $image, $link, $is_active, $sort_order])) {
                header("Location: manage_ticker.php?added=1");
                exit;
            } else {
                $error = 'تعذر إضافة الخبر.';
            }
        }

        if (isset($_POST['edit_news'])) {
            $news_id = (int) ($_POST['news_id'] ?? 0);
            $stmt = $pdo->prepare("UPDATE news_ticker SET title_ar = ?, title_en = ?, content_ar = ?, content_en = ?, image = ?, link = ?, is_active = ?, sort_order = ? WHERE id = ?");
            if ($stmt->execute([$title_ar, $title_en, $content_ar, $content_en, $image, $link, $is_active, $sort_order, $news_id])) {
                header("Location: manage_ticker.php?updated=1");
                exit;
            } else {
                $error = 'تعذر تحديث الخبر.';
            }
        }
    }
}

$news_items = $pdo->query("SELECT * FROM news_ticker ORDER BY sort_order ASC, id DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة شريط الأخبار</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.tiny.cloud/1/d6i6qfdtjejdaj7tmki3r3180lhn7nagpexwc26vwzlos32z/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #2c3e50; color: #fff; position: fixed; top: 0; right: 0; padding: 20px 10px; overflow-y: auto; z-index: 1000; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.95rem; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }
        .main-content { margin-right: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 12px; }
        .lang-section-ar { border-right: 4px solid #cc0000; padding-right: 12px; }
        .lang-section-en { border-right: 4px solid #0066cc; padding-right: 12px; }
        .lang-badge-ar { background: #cc0000; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .lang-badge-en { background: #0066cc; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .auto-translate-badge { background: #28a745; color: #fff; padding: 2px 6px; border-radius: 5px; font-size: 0.7rem; margin-right: 5px; }
    </style>
</head>
<body>
<div class="sidebar">
    <h4 class="text-center mb-4 fw-bold">لوحة التحكم</h4>
    <a href="../index.php" target="_blank" class="nav-view-site"><i class="fas fa-external-link-alt"></i> عرض الموقع</a>
    <a href="control_panel.php"><i class="fas fa-cog"></i> الإعدادات العامة</a>
    <a href="manage_about.php"><i class="fas fa-user"></i> من أنا</a>
    <a href="manage_programs.php"><i class="fas fa-tv"></i> البرامج</a>
    <a href="manage_blog.php"><i class="fas fa-blog"></i> المدونة</a>
    <a href="manage_gallery.php"><i class="fas fa-images"></i> الصور والكواليس</a>
    <a href="manage_awards.php"><i class="fas fa-trophy"></i> الجوائز</a>
    <a href="manage_podcasts.php"><i class="fas fa-microphone"></i> البودكاست</a>
    <a href="manage_events.php"><i class="fas fa-calendar-alt"></i> الفعاليات</a>
    <a href="manage_ticker.php" class="active"><i class="fas fa-bolt"></i> شريط الأخبار</a>
    <a href="manage_collaborations.php"><i class="fas fa-handshake"></i> صناع المحتوى</a>
    <a href="manage_faqs.php"><i class="fas fa-question-circle"></i> الأسئلة الشائعة</a>
    <a href="manage_messages.php"><i class="fas fa-envelope"></i> الرسائل</a>
    <a href="manage_pages.php"><i class="fas fa-file-circle-plus"></i> إدارة الصفحات</a>
    <a href="change_password.php"><i class="fas fa-key"></i> تغيير كلمة المرور</a>
    <hr>
    <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
</div>

<div class="main-content">
    <div class="container-fluid">
        <h2 class="mb-4 fw-bold">إدارة شريط الأخبار</h2>
        <?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>

        <div class="card mb-4">
            <div class="card-header bg-primary text-white fw-bold"><?php echo $edit_data ? 'تعديل الخبر' : 'إضافة خبر جديد'; ?></div>
            <div class="card-body p-4">
                <form method="POST" enctype="multipart/form-data">
                    <?php if($edit_data): ?>
                        <input type="hidden" name="news_id" value="<?php echo $edit_data['id']; ?>">
                        <input type="hidden" name="old_image" value="<?php echo $edit_data['image']; ?>">
                    <?php endif; ?>

                    <!-- قسم العربية -->
                    <div class="row g-3">
                        <div class="col-12"><div class="lang-section-ar"><span class="lang-badge-ar">عربي</span></div></div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">عنوان الخبر</label>
                            <input type="text" name="title_ar" id="title_ar" class="form-control" value="<?php echo htmlspecialchars($edit_data['title_ar'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">الرابط الخارجي (اختياري)</label>
                            <input type="url" name="link" class="form-control" value="<?php echo htmlspecialchars($edit_data['link'] ?? ''); ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-bold">تفاصيل الخبر (محتوى الخبر الكامل)</label>
                            <textarea name="content_ar" id="content_ar" class="form-control" rows="6"><?php echo htmlspecialchars($edit_data['content_ar'] ?? ''); ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">صورة الخبر</label>
                            <input type="file" name="image" class="form-control" accept="image/*">
                            <?php if(!empty($edit_data['image'])): ?>
                                <small class="text-muted">الصورة الحالية: <?php echo $edit_data['image']; ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">ترتيب الظهور</label>
                            <input type="number" name="sort_order" class="form-control" value="<?php echo $edit_data['sort_order'] ?? 0; ?>">
                        </div>

                        <!-- قسم الإنجليزية -->
                        <div class="col-12 mt-4"><hr><div class="lang-section-en"><span class="lang-badge-en">English</span> <span class="auto-translate-badge">ترجمة تلقائية</span></div></div>
                        <div class="col-12">
                            <label class="form-label fw-bold">News Title (English)</label>
                            <input type="text" name="title_en" id="title_en" class="form-control" dir="ltr" value="<?php echo htmlspecialchars($edit_data['title_en'] ?? ''); ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-bold">News Details (English)</label>
                            <textarea name="content_en" id="content_en" class="form-control" rows="6" dir="ltr"><?php echo htmlspecialchars($edit_data['content_en'] ?? ''); ?></textarea>
                        </div>

                        <div class="col-12">
                            <div class="form-check">
                                <input type="checkbox" name="is_active" class="form-check-input" id="is_active" <?php echo (!isset($edit_data) || $edit_data['is_active']) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="is_active">تفعيل الخبر</label>
                            </div>
                        </div>

                        <div class="col-12 text-center mt-4">
                            <button type="submit" name="<?php echo $edit_data ? 'edit_news' : 'add_news'; ?>" class="btn btn-success btn-lg px-5 fw-bold">
                                <?php echo $edit_data ? 'تحديث الخبر' : 'إضافة الخبر'; ?>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- قائمة الأخبار -->
        <div class="card">
            <div class="card-header bg-secondary text-white fw-bold">الأخبار الموجودة</div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>العنوان</th>
                            <th>الحالة</th>
                            <th>التاريخ</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($news_items as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['title_ar']); ?></td>
                            <td><span class="badge <?php echo $item['is_active'] ? 'bg-success' : 'bg-danger'; ?>"><?php echo $item['is_active'] ? 'مفعل' : 'معطل'; ?></span></td>
                            <td><?php echo date('Y-m-d', strtotime($item['created_at'])); ?></td>
                            <td>
                                <a href="manage_ticker.php?edit=<?php echo $item['id']; ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                <a href="manage_ticker.php?delete=<?php echo $item['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد؟')"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="auto_translate.js"></script>
<script src="https://cdn.jsdelivr.net/npm/tinymce@6/tinymce.min.js"></script>
<script>
tinymce.init({
    selector: '#content_ar',
    directionality: 'rtl',
    language: 'ar',
    height: 300,
    plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table help wordcount',
    toolbar: 'undo redo | blocks | bold italic underline forecolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media | removeformat | help',
    setup: function(editor) {
        editor.on('blur', function() {
            const content = editor.getContent();
            if (content.trim() !== '') {
                const englishEditor = tinymce.get('content_en');
                if (englishEditor) {
                    englishEditor.setContent('<p style="color: #999; font-style: italic;">Translating...</p>');
                    liveTranslator.translateText(content).then(translated => {
                        englishEditor.setContent(translated);
                    });
                }
            }
        });
    }
});

tinymce.init({
    selector: '#content_en',
    directionality: 'ltr',
    language: 'en',
    height: 300,
    plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table help wordcount',
    toolbar: 'undo redo | blocks | bold italic underline forecolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media | removeformat | help'
});

document.addEventListener('DOMContentLoaded', function() {
    // ترجمة العنوان
    const titleAr = document.getElementById('title_ar');
    const titleEn = document.getElementById('title_en');
    if (titleAr && titleEn) {
        liveTranslator.bindTranslationField('#title_ar', '#title_en', 800);
    }
});
</script>
</body>
</html>
