<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }
include '../includes/db.php';
$success = '';

// 1. إضافة الأعمدة إذا لم تكن موجودة
try { $pdo->query("SELECT sort_order FROM blog LIMIT 1"); } catch (PDOException $e) { try { $pdo->exec("ALTER TABLE blog ADD COLUMN sort_order INT DEFAULT 0"); } catch (PDOException $ex) {} }
try { $pdo->exec("ALTER TABLE blog ADD COLUMN title_en VARCHAR(255) DEFAULT NULL"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE blog ADD COLUMN content_en LONGTEXT DEFAULT NULL"); } catch (Exception $e) {}

// 2. إضافة مقال جديد
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_blog'])) {
    $title = $_POST['title'];
    $title_en = $_POST['title_en'] ?? '';
    $content = $_POST['content'];
    $content_en = $_POST['content_en'] ?? '';
    $image = '';
    if (!empty($_FILES['image']['name'])) {
        $image = time() . '_' . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $image);
    }
    
    try {
        $stmt_order = $pdo->query("SELECT MAX(sort_order) as max_order FROM blog");
        $max_order = $stmt_order->fetch()['max_order'] ?? 0;
        $new_order = $max_order + 1;
        $stmt = $pdo->prepare("INSERT INTO blog (title, title_en, content, content_en, image, sort_order) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$title, $title_en, $content, $content_en, $image, $new_order]);
    } catch (PDOException $e) {
        $stmt = $pdo->prepare("INSERT INTO blog (title, title_en, content, content_en, image) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$title, $title_en, $content, $content_en, $image]);
    }
    header("Location: manage_blog.php?added=1");
    exit;
}

// 3. تعديل مقال
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_blog'])) {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $title_en = $_POST['title_en'] ?? '';
    $content = $_POST['content'];
    $content_en = $_POST['content_en'] ?? '';
    $image = $_POST['old_image'];
    if (!empty($_FILES['image']['name'])) {
        $image = time() . '_' . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $image);
    }
    
    $stmt = $pdo->prepare("UPDATE blog SET title = ?, title_en = ?, content = ?, content_en = ?, image = ? WHERE id = ?");
    $stmt->execute([$title, $title_en, $content, $content_en, $image, $id]);
    header("Location: manage_blog.php?edited=1");
    exit;
}

// 4. حذف مقال
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM blog WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: manage_blog.php"); exit;
}

// 5. تغيير الترتيب (الأسهم)
if (isset($_GET['move']) && isset($_GET['id'])) {
    $id = (int)$_GET['id']; $move = $_GET['move'];
    $stmt = $pdo->prepare("SELECT id, sort_order FROM blog WHERE id = ?");
    $stmt->execute([$id]);
    $current_row = $stmt->fetch();
    
    if ($current_row) {
        $current_order = $current_row['sort_order'];
        if ($move == 'up') {
            $stmt = $pdo->prepare("SELECT id, sort_order FROM blog WHERE sort_order < ? ORDER BY sort_order DESC LIMIT 1");
        } else {
            $stmt = $pdo->prepare("SELECT id, sort_order FROM blog WHERE sort_order > ? ORDER BY sort_order ASC LIMIT 1");
        }
        $stmt->execute([$current_order]);
        $target = $stmt->fetch();
        
        if ($target) {
            $pdo->beginTransaction();
            $pdo->prepare("UPDATE blog SET sort_order = ? WHERE id = ?")->execute([$target['sort_order'], $id]);
            $pdo->prepare("UPDATE blog SET sort_order = ? WHERE id = ?")->execute([$current_order, $target['id']]);
            $pdo->commit();
        }
    }
    header("Location: manage_blog.php"); exit;
}

$success = '';
if (isset($_GET['added'])) { $success = 'تم إضافة المقال بنجاح!'; }
if (isset($_GET['edited'])) { $success = 'تم تعديل المقال بنجاح!'; }

$edit_data = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM blog WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $edit_data = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة المدونة</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.tiny.cloud/1/d6i6qfdtjejdaj7tmki3r3180lhn7nagpexwc26vwzlos32z/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #2c3e50; color: #fff; position: fixed; top: 0; right: 0; padding: 20px 10px; overflow-y: auto; z-index: 1000; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.95rem; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }
        .main-content { margin-right: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 12px; margin-bottom: 20px; }
        .btn-primary { background-color: #cc0000; border: none; }
        .btn-primary:hover { background-color: #a30000; }
        .nav-view-site { background: #cc0000 !important; margin-bottom: 20px !important; text-align: center; font-weight: bold; }
        .lang-section-ar { border-right: 4px solid #cc0000; padding-right: 12px; }
        .lang-section-en { border-right: 4px solid #0066cc; padding-right: 12px; }
        .lang-badge-ar { background: #cc0000; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .lang-badge-en { background: #0066cc; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .auto-translate-badge { background: #28a745; color: #fff; padding: 2px 6px; border-radius: 5px; font-size: 0.7rem; margin-right: 5px; }
    </style>
</head>
<body>
<div class="sidebar">
    <h4 class="text-center mb-4 fw-bold">لوحة التحكم</h4>
    <a href="../index.php" target="_blank" class="nav-view-site"><i class="fas fa-external-link-alt"></i> عرض الموقع</a>
    <a href="control_panel.php"><i class="fas fa-cog"></i> الإعدادات العامة</a>
    <a href="manage_about.php"><i class="fas fa-user"></i> من أنا</a>
    <a href="manage_programs.php"><i class="fas fa-tv"></i> البرامج</a>
    <a href="manage_blog.php" class="active"><i class="fas fa-blog"></i> المدونة</a>
    <a href="manage_gallery.php"><i class="fas fa-images"></i> الصور والكواليس</a>
    <a href="manage_awards.php"><i class="fas fa-trophy"></i> الجوائز</a>
    <a href="manage_podcasts.php"><i class="fas fa-microphone"></i> البودكاست</a>
    <a href="manage_events.php"><i class="fas fa-calendar-alt"></i> الفعاليات</a>
    <a href="manage_ticker.php"><i class="fas fa-bolt"></i> شريط الأخبار</a>
    <a href="manage_collaborations.php"><i class="fas fa-handshake"></i> صناع المحتوى</a>
    <a href="manage_faqs.php"><i class="fas fa-question-circle"></i> الأسئلة الشائعة</a>
    <a href="manage_messages.php"><i class="fas fa-envelope"></i> الرسالل</a>
    <a href="manage_pages.php"><i class="fas fa-file-circle-plus"></i> إدارة الصفحات</a>
    <a href="change_password.php"><i class="fas fa-key"></i> تغيير كلمة المرور</a>
    <hr>
    <a href="control_panel_en.php" style="color: #ffc107 !important;"><i class="fas fa-language"></i> English Admin Panel</a>
    <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
</div>
<div class="main-content">
    <div class="container-fluid">
        <h2 class="mb-4 fw-bold">إدارة المدونة</h2>
        <?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
        <div class="card">
            <div class="card-header bg-primary text-white fw-bold"><?php echo $edit_data ? 'تعديل مقال' : 'إضافة مقال جديد'; ?></div>
            <div class="card-body">
                <form method="POST" action="manage_blog.php" enctype="multipart/form-data" id="blogForm">
                    <?php if($edit_data): ?>
                        <input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>"><input type="hidden" name="old_image" value="<?php echo $edit_data['image']; ?>">
                    <?php endif; ?>
                    <div class="row g-3">
                        <!-- قسم العربية -->
                        <div class="col-12">
                            <div class="lang-section-ar mb-2">
                                <span class="lang-badge-ar"><i class="fas fa-language me-1"></i> عربي</span>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <label class="form-label fw-bold">عنوان المقال <span class="text-danger">*</span></label>
                            <input type="text" name="title" id="blog_title" class="form-control" value="<?php echo htmlspecialchars($edit_data['title'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">الصورة الرئيسية</label>
                            <input type="file" name="image" class="form-control">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-bold">محتوى المقال بالعربية (تنسيق النص، صور، فيديو)</label>
                            <textarea name="content" id="editor" class="form-control" style="min-height: 400px;"><?php echo htmlspecialchars($edit_data['content'] ?? ''); ?></textarea>
                        </div>

                        <!-- قسم الإنجليزية -->
                        <div class="col-12 mt-3">
                            <hr>
                            <div class="lang-section-en mb-2">
                                <span class="lang-badge-en"><i class="fas fa-language me-1"></i> English</span>
                                <span class="auto-translate-badge"><i class="fas fa-magic"></i> ترجمة تلقائية</span>
                                <small class="text-muted">يظهر في الموقع الإنجليزي فقط - يُترجم تلقائياً من العربية</small>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-bold">Article Title (English)</label>
                            <input type="text" name="title_en" id="blog_title_en" class="form-control" dir="ltr" value="<?php echo htmlspecialchars($edit_data['title_en'] ?? ''); ?>">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-bold">Article Content (English)</label>
                            <textarea name="content_en" id="editor_en" class="form-control" style="min-height: 400px;" dir="ltr"><?php echo htmlspecialchars($edit_data['content_en'] ?? ''); ?></textarea>
                        </div>
                        <div class="col-12 text-center d-flex justify-content-center gap-3">
                            <button type="button" id="previewBtn" class="btn btn-info px-4 fw-bold text-white"><i class="fas fa-eye me-1"></i> معاينة</button>
                            <button type="submit" name="<?php echo $edit_data ? 'edit_blog' : 'add_blog'; ?>" class="btn btn-success px-5 fw-bold"><i class="fas fa-save me-1"></i> <?php echo $edit_data ? 'تحديث نهائي' : 'إضافة واعتماد'; ?></button>
                            <?php if($edit_data): ?><a href="manage_blog.php" class="btn btn-secondary px-4 ms-2">إلغاء</a><?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="card"><div class="card-body">
            <table class="table table-hover align-middle text-center">
                <thead><tr><th>الترتيب</th><th>الصورة</th><th>العنوان</th><th>العمليات</th></tr></thead>
                <tbody>
                    <?php
                    try {
                        $stmt = $pdo->query("SELECT * FROM blog ORDER BY sort_order ASC");
                    } catch (PDOException $e) {
                        $stmt = $pdo->query("SELECT * FROM blog ORDER BY id DESC");
                    }
                    while ($row = $stmt->fetch()) {
                    ?>
                    <tr>
                        <td>
                            <div class="d-flex flex-column align-items-center">
                                <a href="manage_blog.php?move=up&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-dark mb-1"><i class="fas fa-arrow-up"></i></a>
                                <a href="manage_blog.php?move=down&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-dark"><i class="fas fa-arrow-down"></i></a>
                            </div>
                        </td>
                        <td><img src="../uploads/<?php echo $row['image']; ?>" height="50" class="rounded shadow-sm"></td>
                        <td class="text-start">
                                <strong><?php echo htmlspecialchars($row['title']); ?></strong>
                                <?php if(!empty($row['title_en'])): ?>
                                    <br><small class="text-muted" dir="ltr"><?php echo htmlspecialchars($row['title_en']); ?></small>
                                <?php endif; ?>
                            </td>
                        <td>
                            <a href="manage_blog.php?edit=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                            <a href="manage_blog.php?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد؟')"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div></div>
    </div>
</div>
<script src="auto_translate.js"></script>
<script>
    tinymce.init({
        selector: '#editor',
        directionality: 'rtl',
        language: 'ar',
        height: 400,
        plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table help wordcount',
        toolbar: 'undo redo | blocks | bold italic underline forecolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media | removeformat | help',
        content_style: 'body { font-family:Tajawal,Helvetica,Arial,sans-serif; font-size:16px }',
        setup: function (editor) {
            editor.on('blur', function() {
                const content = editor.getContent();
                if (content.trim() !== '') {
                    const englishEditor = tinymce.get('editor_en');
                    if (englishEditor) {
                        englishEditor.setContent('<p style="color: #999; font-style: italic;">Translating...</p>');
                        liveTranslator.translateText(content).then(translated => {
                            englishEditor.setContent(translated);
                        });
                    }
                }
            });
        }
    });

    tinymce.init({
        selector: '#editor_en',
        directionality: 'ltr',
        language: 'en',
        height: 400,
        plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table help wordcount',
        toolbar: 'undo redo | blocks | bold italic underline forecolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media | removeformat | help',
        content_style: 'body { font-family:Tajawal,Helvetica,Arial,sans-serif; font-size:16px }'
    });

    document.addEventListener('DOMContentLoaded', function() {
        // ربط حقل العنوان
        liveTranslator.bindTranslationField('#blog_title', '#blog_title_en', 800);
    });

    document.getElementById('previewBtn').addEventListener('click', function() {
        const title = document.getElementById('blog_title').value;
        let content = '';
        if (typeof tinymce !== 'undefined' && tinymce.get('editor')) {
            content = tinymce.get('editor').getContent();
        } else {
            content = document.getElementById('editor').value;
        }

        const previewWin = window.open('', 'Preview', 'width=900,height=700');
        previewWin.document.write(`
            <html dir="rtl">
            <head>
                <title>معاينة المقال</title>
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
                <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
                <style>body{padding:20px; font-family: 'Tajawal', sans-serif; background-color: #f8f9fa;}</style>
            </head>
            <body>
                <div class="alert alert-info text-center shadow-sm">هذه مجرد معاينة، اضغط على "تحديث نهائي" أو "إضافة واعتماد" في لوحة التحكم لحفظ التغييرات.</div>
                <div class="container mt-4">
                    <div class="card shadow-lg border-0 rounded-4 overflow-hidden">
                        <div class="card-body p-4">
                            <h2 class="text-danger fw-bold mb-4">${title || 'بدون عنوان'}</h2>
                            <hr>
                            <div class="content fs-5" style="line-height: 1.9;">${content || 'لا يوجد محتوى'}</div>
                        </div>
                    </div>
                    <div class="text-center mt-5"><button onclick="window.close()" class="btn btn-dark px-4 rounded-pill">إغلاق المعاينة</button></div>
                </div>
            </body>
            </html>
        `);
    });
</script>
</body>
</html>
