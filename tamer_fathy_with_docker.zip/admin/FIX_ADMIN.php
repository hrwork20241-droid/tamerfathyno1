<?php
/**
 * ملف إصلاح لوحة التحكم - FIX_ADMIN.php
 * هذا الملف يقوم بإصلاح ملف admin/index.php تلقائياً
 */

$correct_code = '<?php
session_start();
if (!isset($_SESSION[\'admin_logged_in\'])) {
    header("Location: login.php");
    exit;
}
header("Location: control_panel.php");
exit;
?>';

$file_path = __DIR__ . '/index.php';

// محاولة كتابة الملف الصحيح
if (file_put_contents($file_path, $correct_code)) {
    echo '<div style="background-color: #4CAF50; color: white; padding: 20px; text-align: center; font-size: 18px; border-radius: 5px; margin: 20px;">';
    echo '<strong>✓ تم إصلاح لوحة التحكم بنجاح!</strong><br>';
    echo 'سيتم توجيهك إلى لوحة التحكم خلال 3 ثوان...';
    echo '</div>';
    echo '<script>setTimeout(function() { window.location.href = "index.php"; }, 3000);</script>';
} else {
    echo '<div style="background-color: #f44336; color: white; padding: 20px; text-align: center; font-size: 18px; border-radius: 5px; margin: 20px;">';
    echo '<strong>✗ حدث خطأ في الإصلاح</strong><br>';
    echo 'يرجى التأكد من صلاحيات الكتابة على المجلد admin';
    echo '</div>';
}
?>
