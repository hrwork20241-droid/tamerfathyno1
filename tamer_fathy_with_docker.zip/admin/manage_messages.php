<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}
include '../includes/db.php';

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM contact_messages WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: manage_messages.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الرسائل - لوحة التحكم</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #2c3e50; color: #fff; position: fixed; top: 0; right: 0; padding: 20px 10px; overflow-y: auto; z-index: 1000; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.95rem; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }
        .sidebar a i { width: 25px; }
        .main-content { margin-right: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 12px; }
        .btn-primary { background-color: #cc0000; border: none; }
        .btn-primary:hover { background-color: #a30000; }
        .nav-view-site { background: #cc0000 !important; margin-bottom: 20px !important; text-align: center; font-weight: bold; }
        .table-responsive { border-radius: 10px; }
        .btn-reply { background-color: #28a745; color: white; border: none; }
        .btn-reply:hover { background-color: #218838; color: white; }
    </style>
</head>
<body>

<div class="sidebar">
    <h4 class="text-center mb-4 fw-bold">لوحة التحكم</h4>
    <a href="../index.php" target="_blank" class="nav-view-site"><i class="fas fa-external-link-alt"></i> عرض الموقع</a>
    <a href="control_panel.php"><i class="fas fa-cog"></i> الإعدادات العامة</a>
    <a href="manage_about.php"><i class="fas fa-user"></i> من أنا</a>
    <a href="manage_programs.php"><i class="fas fa-tv"></i> البرامج</a>
    <a href="manage_blog.php"><i class="fas fa-blog"></i> المدونة</a>
    <a href="manage_gallery.php"><i class="fas fa-images"></i> الصور والكواليس</a>
    <a href="manage_awards.php"><i class="fas fa-trophy"></i> الجوائز</a>
    <a href="manage_podcasts.php"><i class="fas fa-microphone"></i> البودكاست</a>
    <a href="manage_events.php"><i class="fas fa-calendar-alt"></i> الفعاليات</a>
    <a href="manage_collaborations.php"><i class="fas fa-handshake"></i> صناع المحتوى</a>
    <a href="manage_faqs.php"><i class="fas fa-question-circle"></i> الأسئلة الشائعة</a>
    <a href="manage_messages.php" class="active"><i class="fas fa-envelope"></i> الرسائل</a>
    <hr>
    <a href="control_panel_en.php" style="color: #ffc107 !important;"><i class="fas fa-language"></i> English Admin Panel</a>
    <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
</div>

<div class="main-content">
    <div class="container-fluid">
        <h2 class="mb-4 fw-bold text-dark">رسائل المتابعين</h2>
        
        <div class="card">
            <div class="card-body p-4">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>الاسم</th>
                                <th>البريد الإلكتروني</th>
                                <th>الموضوع</th>
                                <th>الرسالة</th>
                                <th>التاريخ</th>
                                <th class="text-center">إجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $stmt = $pdo->query("SELECT * FROM contact_messages ORDER BY created_at DESC");
                            while ($row = $stmt->fetch()) {
                            ?>
                            <tr>
                                <td class="fw-bold"><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo htmlspecialchars($row['subject']); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-dark" data-bs-toggle="modal" data-bs-target="#msgModal<?php echo $row['id']; ?>">
                                        عرض الرسالة
                                    </button>
                                    
                                    <!-- Modal لعرض الرسالة كاملة -->
                                    <div class="modal fade" id="msgModal<?php echo $row['id']; ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">رسالة من: <?php echo htmlspecialchars($row['name']); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p class="fw-bold">الموضوع: <?php echo htmlspecialchars($row['subject']); ?></p>
                                                    <hr>
                                                    <p><?php echo nl2br(htmlspecialchars($row['message'])); ?></p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                                                    <a href="mailto:<?php echo $row['email']; ?>?subject=رد على: <?php echo urlencode($row['subject']); ?>" class="btn btn-reply">
                                                        <i class="fas fa-reply me-1"></i> رد الآن
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo date('Y-m-d', strtotime($row['created_at'])); ?></td>
                                <td class="text-center">
                                    <div class="btn-group">
                                        <a href="mailto:<?php echo $row['email']; ?>?subject=رد على: <?php echo urlencode($row['subject']); ?>" class="btn btn-sm btn-reply" title="رد">
                                            <i class="fas fa-reply"></i>
                                        </a>
                                        <a href="manage_messages.php?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد من الحذف؟')" title="حذف">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
