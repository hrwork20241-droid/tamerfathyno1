<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}
include '../includes/db.php';

// Auto-update database
try {
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS google_play_url VARCHAR(255) AFTER whatsapp_number");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS app_store_url VARCHAR(255) AFTER google_play_url");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS telegram_url VARCHAR(255) AFTER app_store_url");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS threads_url VARCHAR(255) AFTER telegram_url");
} catch (PDOException $e) {}

$success = '';
$siteSettings = getSettings($pdo);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['site_title'] ?? '';
    $phone = $_POST['contact_phone'] ?? '';
    $email = $_POST['contact_email'] ?? '';
    $facebook = $_POST['facebook_url'] ?? '';
    $twitter = $_POST['twitter_url'] ?? '';
    $instagram = $_POST['instagram_url'] ?? '';
    $youtube = $_POST['youtube_url'] ?? '';
    $tiktok = $_POST['tiktok_url'] ?? '';
    $snapchat = $_POST['snapchat_url'] ?? '';
    $linkedin = $_POST['linkedin_url'] ?? '';
    $whatsapp = $_POST['whatsapp_number'] ?? '';
    $google_play = $_POST['google_play_url'] ?? '';
    $app_store = $_POST['app_store_url'] ?? '';
    $telegram = $_POST['telegram_url'] ?? '';
    $threads = $_POST['threads_url'] ?? '';

    $logo = $siteSettings['site_logo'];
    if (!empty($_FILES['site_logo']['name']) && $_FILES['site_logo']['error'] == 0) {
        $logo = time() . '_' . basename($_FILES['site_logo']['name']);
        move_uploaded_file($_FILES['site_logo']['tmp_name'], "../uploads/" . $logo);
    }

    $favicon = $siteSettings['site_favicon'];
    if (!empty($_FILES['site_favicon']['name']) && $_FILES['site_favicon']['error'] == 0) {
        $favicon = time() . '_' . basename($_FILES['site_favicon']['name']);
        move_uploaded_file($_FILES['site_favicon']['tmp_name'], "../uploads/" . $favicon);
    }

    $header_image = $siteSettings['header_image'];
    if (!empty($_FILES['header_image']['name']) && $_FILES['header_image']['error'] == 0) {
        $header_image = time() . '_' . basename($_FILES['header_image']['name']);
        move_uploaded_file($_FILES['header_image']['tmp_name'], "../uploads/" . $header_image);
    }

    $stmt = $pdo->prepare("UPDATE settings SET site_title = ?, site_logo = ?, site_favicon = ?, header_image = ?, contact_phone = ?, contact_email = ?, facebook_url = ?, twitter_url = ?, instagram_url = ?, youtube_url = ?, tiktok_url = ?, snapchat_url = ?, linkedin_url = ?, whatsapp_number = ?, google_play_url = ?, app_store_url = ?, telegram_url = ?, threads_url = ? WHERE id = 1");
    if ($stmt->execute([$title, $logo, $favicon, $header_image, $phone, $email, $facebook, $twitter, $instagram, $youtube, $tiktok, $snapchat, $linkedin, $whatsapp, $google_play, $app_store, $telegram, $threads])) {
        $success = "Settings updated successfully!";
        $siteSettings = getSettings($pdo);
    }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Settings (EN)</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #1a252f; color: #fff; position: fixed; top: 0; left: 0; padding: 20px 10px; overflow-y: auto; z-index: 1000; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.9rem; }
        .sidebar a:hover, .sidebar a.active { background: #2c3e50; color: #fff; }
        .sidebar a i { width: 25px; }
        .main-content { margin-left: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 12px; }
        .btn-primary { background-color: #cc0000; border: none; }
        .btn-primary:hover { background-color: #a30000; }
        .nav-view-site { background: #cc0000 !important; margin-bottom: 20px !important; text-align: center; font-weight: bold; }
        .quick-actions { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .quick-action-card { background: linear-gradient(135deg, #ffffff 0%, #f9fbfd 100%); border-radius: 16px; padding: 22px; box-shadow: 0 10px 25px rgba(44, 62, 80, 0.08); text-decoration: none; color: #2c3e50; transition: 0.3s; border: 1px solid rgba(204,0,0,0.08); }
        .quick-action-card:hover { transform: translateY(-4px); box-shadow: 0 16px 30px rgba(44, 62, 80, 0.14); color: #cc0000; }
        .quick-action-card i { width: 56px; height: 56px; display: inline-flex; align-items: center; justify-content: center; border-radius: 14px; background: rgba(204,0,0,0.1); color: #cc0000; font-size: 1.4rem; margin-bottom: 15px; }
        .quick-action-card h5 { font-weight: 700; margin-bottom: 8px; }
        .quick-action-card p { margin: 0; color: #6c757d; line-height: 1.7; }
        .sidebar-brand { text-align: center; padding: 10px 0 20px; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 15px; }
        .sidebar-brand h4 { font-size: 1rem; margin: 0; }
        .sidebar-brand small { color: rgba(255,255,255,0.5); font-size: 0.75rem; }
        .lang-badge { display: inline-block; background: #cc0000; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.7rem; font-weight: bold; margin-left: 5px; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-brand">
        <h4 class="fw-bold text-white">Admin Panel</h4>
        <small>English Dashboard <span class="lang-badge">EN</span></small>
    </div>
    <a href="../index_en.php" target="_blank" class="nav-view-site"><i class="fas fa-external-link-alt"></i> View EN Site</a>
    <a href="../index.php" target="_blank" style="background: rgba(255,255,255,0.08) !important; margin-bottom: 10px !important;"><i class="fas fa-globe"></i> View AR Site</a>
    <a href="control_panel_en.php" class="active"><i class="fas fa-cog"></i> General Settings</a>
    <a href="manage_about.php"><i class="fas fa-user"></i> About Me</a>
    <a href="manage_programs.php"><i class="fas fa-tv"></i> Programs</a>
    <a href="manage_blog.php"><i class="fas fa-blog"></i> Blog</a>
    <a href="manage_gallery.php"><i class="fas fa-images"></i> Gallery</a>
    <a href="manage_awards.php"><i class="fas fa-trophy"></i> Awards</a>
    <a href="manage_podcasts.php"><i class="fas fa-microphone"></i> Podcast</a>
    <a href="manage_events.php"><i class="fas fa-calendar-alt"></i> Events</a>
    <a href="manage_collaborations.php"><i class="fas fa-handshake"></i> Collaborations</a>
    <a href="manage_faqs.php"><i class="fas fa-question-circle"></i> FAQs</a>
    <a href="manage_messages.php"><i class="fas fa-envelope"></i> Messages</a>
    <a href="manage_pages.php"><i class="fas fa-file-circle-plus"></i> Add Page</a>
    <a href="change_password.php"><i class="fas fa-key"></i> Change Password</a>
    <hr style="border-color: rgba(255,255,255,0.1);">
    <a href="control_panel.php" style="color: #ffc107 !important;"><i class="fas fa-language"></i> Arabic Admin Panel</a>
    <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main-content">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1 fw-bold text-dark">General Settings</h2>
                <p class="text-muted mb-0">Manage your website's basic settings, social links, and app store URLs.</p>
            </div>
            <span class="badge bg-danger fs-6 px-3 py-2">English Dashboard</span>
        </div>

        <div class="quick-actions">
            <a href="manage_pages.php" class="quick-action-card">
                <span class="badge bg-danger mb-2">New Feature</span><br>
                <i class="fas fa-file-circle-plus"></i>
                <h5>Add New Page</h5>
                <p>Create custom pages with title, URL, and full content to expand your site easily.</p>
            </a>
            <a href="change_password.php" class="quick-action-card">
                <span class="badge bg-warning text-dark mb-2">Security</span><br>
                <i class="fas fa-user-shield"></i>
                <h5>Change Password</h5>
                <p>Update your admin panel login password quickly and securely.</p>
            </a>
            <a href="../index_en.php" target="_blank" class="quick-action-card">
                <span class="badge bg-success mb-2">Live</span><br>
                <i class="fas fa-globe"></i>
                <h5>View English Site</h5>
                <p>Preview the English version of your website as visitors see it.</p>
            </a>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success border-0 shadow-sm"><?php echo $success; ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST" action="control_panel_en.php" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-12 mb-4">
                            <label class="form-label fw-bold">Site Title</label>
                            <input type="text" name="site_title" class="form-control" value="<?php echo htmlspecialchars($siteSettings['site_title'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label fw-bold">Contact Email</label>
                            <input type="email" name="contact_email" class="form-control" value="<?php echo htmlspecialchars($siteSettings['contact_email'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label fw-bold">Phone Number</label>
                            <input type="text" name="contact_phone" class="form-control" value="<?php echo htmlspecialchars($siteSettings['contact_phone'] ?? ''); ?>">
                        </div>
                        <div class="col-md-4 mb-4">
                            <label class="form-label fw-bold">Site Logo</label>
                            <input type="file" name="site_logo" class="form-control">
                            <?php if(!empty($siteSettings['site_logo'])): ?>
                                <img src="../uploads/<?php echo $siteSettings['site_logo']; ?>" class="mt-2 rounded border" height="50">
                            <?php endif; ?>
                        </div>
                        <div class="col-md-4 mb-4">
                            <label class="form-label fw-bold">Favicon</label>
                            <input type="file" name="site_favicon" class="form-control">
                            <?php if(!empty($siteSettings['site_favicon'])): ?>
                                <img src="../uploads/<?php echo $siteSettings['site_favicon']; ?>" class="mt-2 rounded border" height="30">
                            <?php endif; ?>
                        </div>
                        <div class="col-md-4 mb-4">
                            <label class="form-label fw-bold">Header Image</label>
                            <input type="file" name="header_image" class="form-control">
                            <?php if(!empty($siteSettings['header_image'])): ?>
                                <img src="../uploads/<?php echo $siteSettings['header_image']; ?>" class="mt-2 rounded border" height="50">
                            <?php endif; ?>
                        </div>
                        <hr class="my-4">
                        <h5 class="mb-4 fw-bold text-danger"><i class="fas fa-share-alt me-2"></i> Social Media Links</h5>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fab fa-facebook me-1 text-primary"></i> Facebook</label>
                            <input type="url" name="facebook_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['facebook_url'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fab fa-x-twitter me-1"></i> Twitter / X</label>
                            <input type="url" name="twitter_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['twitter_url'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fab fa-instagram me-1 text-danger"></i> Instagram</label>
                            <input type="url" name="instagram_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['instagram_url'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fab fa-youtube me-1 text-danger"></i> YouTube</label>
                            <input type="url" name="youtube_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['youtube_url'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fab fa-tiktok me-1"></i> TikTok</label>
                            <input type="url" name="tiktok_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['tiktok_url'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fab fa-snapchat me-1 text-warning"></i> Snapchat</label>
                            <input type="url" name="snapchat_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['snapchat_url'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fab fa-linkedin me-1 text-primary"></i> LinkedIn</label>
                            <input type="url" name="linkedin_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['linkedin_url'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fab fa-whatsapp me-1 text-success"></i> WhatsApp (without +)</label>
                            <input type="text" name="whatsapp_number" class="form-control" value="<?php echo htmlspecialchars($siteSettings['whatsapp_number'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fab fa-telegram me-1 text-primary"></i> Telegram</label>
                            <input type="url" name="telegram_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['telegram_url'] ?? ''); ?>" placeholder="https://t.me/username">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fab fa-threads me-1"></i> Threads</label>
                            <input type="url" name="threads_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['threads_url'] ?? ''); ?>" placeholder="https://www.threads.net/@username">
                        </div>
                        <hr class="my-4">
                        <h5 class="mb-4 fw-bold text-danger"><i class="fas fa-mobile-alt me-2"></i> App Store Links</h5>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fab fa-google-play me-1 text-success"></i> Google Play URL</label>
                            <input type="url" name="google_play_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['google_play_url'] ?? ''); ?>" placeholder="https://play.google.com/store/apps/details?id=...">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="fab fa-app-store me-1"></i> App Store URL</label>
                            <input type="url" name="app_store_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['app_store_url'] ?? ''); ?>" placeholder="https://apps.apple.com/app/...">
                        </div>
                    </div>
                    <div class="text-center mt-5">
                        <button type="submit" class="btn btn-primary btn-lg px-5 fw-bold">Save Settings</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
