<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }
include '../includes/db.php';

// تحديث قاعدة البيانات التلقائي - إضافة جميع الأعمدة المفقودة
try {
    // الأعمدة الأساسية
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS hero_title_en VARCHAR(255) DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS hero_description_en TEXT DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS site_title_en VARCHAR(255) DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS contact_phone VARCHAR(20) DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS contact_email VARCHAR(255) DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS facebook_url VARCHAR(500) DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS twitter_url VARCHAR(500) DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS instagram_url VARCHAR(500) DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS youtube_url VARCHAR(500) DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS tiktok_url VARCHAR(500) DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS snapchat_url VARCHAR(500) DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS linkedin_url VARCHAR(500) DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS telegram_url VARCHAR(500) DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS threads_url VARCHAR(500) DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS whatsapp_number VARCHAR(20) DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS google_play_url VARCHAR(500) DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS app_store_url VARCHAR(500) DEFAULT NULL");
    
    // أعمدة التحكم في الظهور للهيدر والفوتر
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS facebook_show_header TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS facebook_show_footer TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS twitter_show_header TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS twitter_show_footer TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS instagram_show_header TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS instagram_show_footer TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS youtube_show_header TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS youtube_show_footer TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS tiktok_show_header TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS tiktok_show_footer TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS snapchat_show_header TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS snapchat_show_footer TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS linkedin_show_header TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS linkedin_show_footer TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS telegram_show_header TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS telegram_show_footer TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS threads_show_header TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS threads_show_footer TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS whatsapp_show_header TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS whatsapp_show_footer TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS google_play_show_header TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS google_play_show_footer TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS app_store_show_header TINYINT(1) DEFAULT 1");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS app_store_show_footer TINYINT(1) DEFAULT 1");
    
    // أعمدة جديدة للتحكم في سرعة المعرض ونص الفوتر
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS gallery_speed INT DEFAULT 5000");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS footer_about_text TEXT DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS footer_about_text_en TEXT DEFAULT NULL");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS footer_icons_per_row INT DEFAULT 5");
} catch (PDOException $e) {
    // تجاهل الأخطاء إذا كانت الأعمدة موجودة بالفعل
}

$success = '';
$siteSettings = getSettings($pdo);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['site_title'] ?? '';
    $title_en = $_POST['site_title_en'] ?? '';
    $hero_title = $_POST['hero_title'] ?? 'الإعلامي تامر فتحي';
    $hero_title_en = $_POST['hero_title_en'] ?? '';
    $hero_description = $_POST['hero_description'] ?? '';
    $hero_description_en = $_POST['hero_description_en'] ?? '';
    $phone = $_POST['contact_phone'] ?? '';
    $email = $_POST['contact_email'] ?? '';
    $facebook = $_POST['facebook_url'] ?? '';
    $twitter = $_POST['twitter_url'] ?? '';
    $instagram = $_POST['instagram_url'] ?? '';
    $youtube = $_POST['youtube_url'] ?? '';
    $tiktok = $_POST['tiktok_url'] ?? '';
    $snapchat = $_POST['snapchat_url'] ?? '';
    $linkedin = $_POST['linkedin_url'] ?? '';
    $whatsapp = $_POST['whatsapp_number'] ?? '';
    $google_play = $_POST['google_play_url'] ?? '';
    $app_store = $_POST['app_store_url'] ?? '';
    $telegram = $_POST['telegram_url'] ?? '';
    $threads = $_POST['threads_url'] ?? '';
    $show_header_image = isset($_POST['show_header_image']) ? 1 : 0;
    $gallery_speed = intval($_POST['gallery_speed'] ?? 5000);
    $footer_about_text = $_POST['footer_about_text'] ?? '';
    $footer_about_text_en = $_POST['footer_about_text_en'] ?? '';
    $footer_icons_per_row = intval($_POST['footer_icons_per_row'] ?? 5);
    if ($footer_icons_per_row < 1) $footer_icons_per_row = 1;
    if ($footer_icons_per_row > 10) $footer_icons_per_row = 10;

    // التأكد من وجود مجلد uploads
    $uploads_dir = '../uploads';
    if (!is_dir($uploads_dir)) {
        mkdir($uploads_dir, 0755, true);
    }

    $logo = $siteSettings['site_logo'];
    if (!empty($_FILES['site_logo']['name'])) {
        $logo = time() . '_logo_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $_FILES['site_logo']['name']);
        $logo_path = $uploads_dir . '/' . $logo;
        if (move_uploaded_file($_FILES['site_logo']['tmp_name'], $logo_path)) {
            // تم الرفع بنجاح
        }
    }

    $favicon = $siteSettings['site_favicon'];
    if (!empty($_FILES['site_favicon']['name'])) {
        $favicon = time() . '_fav_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $_FILES['site_favicon']['name']);
        $favicon_path = $uploads_dir . '/' . $favicon;
        if (move_uploaded_file($_FILES['site_favicon']['tmp_name'], $favicon_path)) {
            // تم الرفع بنجاح
        }
    }

    $header_image = $siteSettings['header_image'];
    if (!empty($_FILES['header_image']['name'])) {
        $header_image = time() . '_head_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $_FILES['header_image']['name']);
        $header_image_path = $uploads_dir . '/' . $header_image;
        if (move_uploaded_file($_FILES['header_image']['tmp_name'], $header_image_path)) {
            // تم الرفع بنجاح
        }
    }

    $hero_image = $siteSettings['hero_image'];
    if (!empty($_FILES['hero_image']['name'])) {
        $hero_image = time() . '_hero_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $_FILES['hero_image']['name']);
        $hero_image_path = $uploads_dir . '/' . $hero_image;
        if (move_uploaded_file($_FILES['hero_image']['tmp_name'], $hero_image_path)) {
            // تم الرفع بنجاح
        }
    }

    // جمع خيارات الإظهار/الإخفاء
    $facebook_header = isset($_POST['facebook_show_header']) ? 1 : 0;
    $facebook_footer = isset($_POST['facebook_show_footer']) ? 1 : 0;
    $twitter_header = isset($_POST['twitter_show_header']) ? 1 : 0;
    $twitter_footer = isset($_POST['twitter_show_footer']) ? 1 : 0;
    $instagram_header = isset($_POST['instagram_show_header']) ? 1 : 0;
    $instagram_footer = isset($_POST['instagram_show_footer']) ? 1 : 0;
    $youtube_header = isset($_POST['youtube_show_header']) ? 1 : 0;
    $youtube_footer = isset($_POST['youtube_show_footer']) ? 1 : 0;
    $tiktok_header = isset($_POST['tiktok_show_header']) ? 1 : 0;
    $tiktok_footer = isset($_POST['tiktok_show_footer']) ? 1 : 0;
    $snapchat_header = isset($_POST['snapchat_show_header']) ? 1 : 0;
    $snapchat_footer = isset($_POST['snapchat_show_footer']) ? 1 : 0;
    $linkedin_header = isset($_POST['linkedin_show_header']) ? 1 : 0;
    $linkedin_footer = isset($_POST['linkedin_show_footer']) ? 1 : 0;
    $telegram_header = isset($_POST['telegram_show_header']) ? 1 : 0;
    $telegram_footer = isset($_POST['telegram_show_footer']) ? 1 : 0;
    $threads_header = isset($_POST['threads_show_header']) ? 1 : 0;
    $threads_footer = isset($_POST['threads_show_footer']) ? 1 : 0;
    $whatsapp_header = isset($_POST['whatsapp_show_header']) ? 1 : 0;
    $whatsapp_footer = isset($_POST['whatsapp_show_footer']) ? 1 : 0;
    $google_play_header = isset($_POST['google_play_show_header']) ? 1 : 0;
    $google_play_footer = isset($_POST['google_play_show_footer']) ? 1 : 0;
    $app_store_header = isset($_POST['app_store_show_header']) ? 1 : 0;
    $app_store_footer = isset($_POST['app_store_show_footer']) ? 1 : 0;

    $stmt = $pdo->prepare("UPDATE settings SET site_title = ?, site_title_en = ?, hero_title = ?, hero_title_en = ?, hero_description = ?, hero_description_en = ?, hero_image = ?, site_logo = ?, site_favicon = ?, header_image = ?, show_header_image = ?, contact_phone = ?, contact_email = ?, facebook_url = ?, twitter_url = ?, instagram_url = ?, youtube_url = ?, tiktok_url = ?, snapchat_url = ?, linkedin_url = ?, whatsapp_number = ?, google_play_url = ?, app_store_url = ?, telegram_url = ?, threads_url = ?, facebook_show_header = ?, facebook_show_footer = ?, twitter_show_header = ?, twitter_show_footer = ?, instagram_show_header = ?, instagram_show_footer = ?, youtube_show_header = ?, youtube_show_footer = ?, tiktok_show_header = ?, tiktok_show_footer = ?, snapchat_show_header = ?, snapchat_show_footer = ?, linkedin_show_header = ?, linkedin_show_footer = ?, telegram_show_header = ?, telegram_show_footer = ?, threads_show_header = ?, threads_show_footer = ?, whatsapp_show_header = ?, whatsapp_show_footer = ?, google_play_show_header = ?, google_play_show_footer = ?, app_store_show_header = ?, app_store_show_footer = ?, gallery_speed = ?, footer_about_text = ?, footer_about_text_en = ?, footer_icons_per_row = ? WHERE id = 1");
    if ($stmt->execute([$title, $title_en, $hero_title, $hero_title_en, $hero_description, $hero_description_en, $hero_image, $logo, $favicon, $header_image, $show_header_image, $phone, $email, $facebook, $twitter, $instagram, $youtube, $tiktok, $snapchat, $linkedin, $whatsapp, $google_play, $app_store, $telegram, $threads, $facebook_header, $facebook_footer, $twitter_header, $twitter_footer, $instagram_header, $instagram_footer, $youtube_header, $youtube_footer, $tiktok_header, $tiktok_footer, $snapchat_header, $snapchat_footer, $linkedin_header, $linkedin_footer, $telegram_header, $telegram_footer, $threads_header, $threads_footer, $whatsapp_header, $whatsapp_footer, $google_play_header, $google_play_footer, $app_store_header, $app_store_footer, $gallery_speed, $footer_about_text, $footer_about_text_en, $footer_icons_per_row])) {
        $success = "تم تحديث الإعدادات بنجاح!";
        $siteSettings = getSettings($pdo);
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>الإعدادات العامة</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.tiny.cloud/1/d6i6qfdtjejdaj7tmki3r3180lhn7nagpexwc26vwzlos32z/tinymce/6/tinymce.min.js"></script>
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #f4f6f9; }
        .sidebar { width: 260px; height: 100vh; background: #2c3e50; color: #fff; position: fixed; top: 0; right: 0; padding: 20px 10px; overflow-y: auto; }
        .sidebar a { color: #ecf0f1; text-decoration: none; display: block; padding: 12px 15px; margin-bottom: 5px; border-radius: 8px; transition: 0.3s; font-size: 0.95rem; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }
        .main-content { margin-right: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.08); border-radius: 12px; }
        .lang-section-ar { border-right: 4px solid #cc0000; padding-right: 12px; }
        .lang-section-en { border-right: 4px solid #0066cc; padding-right: 12px; }
        .lang-badge-ar { background: #cc0000; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .lang-badge-en { background: #0066cc; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }
        .auto-translate-badge { background: #28a745; color: #fff; padding: 2px 6px; border-radius: 5px; font-size: 0.7rem; margin-right: 5px; }
    </style>
</head>
<body>
<div class="sidebar">
    <h4 class="text-center mb-4 fw-bold">لوحة التحكم</h4>
    <a href="../index.php" target="_blank" class="nav-view-site"><i class="fas fa-external-link-alt"></i> عرض الموقع</a>
    <a href="control_panel.php" class="active"><i class="fas fa-cog"></i> الإعدادات العامة</a>
    <a href="manage_about.php"><i class="fas fa-user"></i> من أنا</a>
    <a href="manage_programs.php"><i class="fas fa-tv"></i> البرامج</a>
    <a href="manage_blog.php"><i class="fas fa-blog"></i> المدونة</a>
    <a href="manage_gallery.php"><i class="fas fa-images"></i> الصور والكواليس</a>
    <a href="manage_awards.php"><i class="fas fa-trophy"></i> الجوائز</a>
    <a href="manage_podcasts.php"><i class="fas fa-microphone"></i> البودكاست</a>
    <a href="manage_events.php"><i class="fas fa-calendar-alt"></i> الفعاليات</a>
    <a href="manage_ticker.php"><i class="fas fa-bolt"></i> شريط الأخبار</a>
    <a href="manage_collaborations.php"><i class="fas fa-handshake"></i> صناع المحتوى</a>
    <a href="manage_faqs.php"><i class="fas fa-question-circle"></i> الأسئلة الشائعة</a>
    <a href="manage_messages.php"><i class="fas fa-envelope"></i> الرسالل</a>
    <a href="manage_pages.php"><i class="fas fa-file-circle-plus"></i> إدارة الصفحات</a>
    <a href="change_password.php"><i class="fas fa-key"></i> تغيير كلمة المرور</a>
    <hr>
    <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
</div>
<div class="main-content">
    <div class="container-fluid">
        <h2 class="mb-4 fw-bold">الإعدادات العامة والترجمة</h2>
        <?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
        <form method="POST" enctype="multipart/form-data">
            <div class="card mb-4">
                <div class="card-body p-4">
                    <h5 class="mb-4 fw-bold text-primary">هوية الموقع والهيرو</h5>
                    <div class="row g-3">
                        <!-- AR -->
                        <div class="col-12"><div class="lang-section-ar"><span class="lang-badge-ar">عربي</span></div></div>
                        <div class="col-md-6"><label class="form-label fw-bold">عنوان الموقع</label><input type="text" name="site_title" id="site_title_ar" class="form-control" value="<?php echo htmlspecialchars($siteSettings['site_title'] ?? ''); ?>"></div>
                        <div class="col-md-6"><label class="form-label fw-bold">الاسم في الهيرو</label><input type="text" name="hero_title" id="hero_title_ar" class="form-control" value="<?php echo htmlspecialchars($siteSettings['hero_title'] ?? ''); ?>"></div>
                        <div class="col-12"><label class="form-label fw-bold">وصف الهيرو</label><textarea name="hero_description" id="hero_description_ar" class="form-control" rows="2"><?php echo htmlspecialchars($siteSettings['hero_description'] ?? ''); ?></textarea></div>
                        
                        <!-- EN -->
                        <div class="col-12 mt-3"><hr><div class="lang-section-en"><span class="lang-badge-en">English</span> <span class="auto-translate-badge">ترجمة تلقائية</span></div></div>
                        <div class="col-md-6"><label class="form-label fw-bold">Site Title (EN)</label><input type="text" name="site_title_en" id="site_title_en" class="form-control" dir="ltr" value="<?php echo htmlspecialchars($siteSettings['site_title_en'] ?? ''); ?>"></div>
                        <div class="col-md-6"><label class="form-label fw-bold">Hero Title (EN)</label><input type="text" name="hero_title_en" id="hero_title_en" class="form-control" dir="ltr" value="<?php echo htmlspecialchars($siteSettings['hero_title_en'] ?? ''); ?>"></div>
                        <div class="col-12"><label class="form-label fw-bold">Hero Description (EN)</label><textarea name="hero_description_en" id="hero_description_en" class="form-control" rows="2" dir="ltr"><?php echo htmlspecialchars($siteSettings['hero_description_en'] ?? ''); ?></textarea></div>
                    </div>
                </div>
            </div>
            <div class="card mb-4">
                <div class="card-body p-4">
                    <h5 class="mb-4 fw-bold text-primary">الصور والوسائط</h5>
                    <div class="row g-3">
                        <div class="col-md-3"><label class="form-label fw-bold">اللوجو</label><input type="file" name="site_logo" class="form-control"></div>
                        <div class="col-md-3"><label class="form-label fw-bold">الأيقونة</label><input type="file" name="site_favicon" class="form-control"></div>
                        <div class="col-md-3"><label class="form-label fw-bold">صورة الهيرو</label><input type="file" name="hero_image" class="form-control"></div>
                        <div class="col-md-3"><label class="form-label fw-bold">صورة الهيدر</label><input type="file" name="header_image" class="form-control"></div>
                    </div>
                </div>
            </div>
            <div class="card mb-4">
                <div class="card-body p-4">
                    <h5 class="mb-4 fw-bold text-primary">بيانات الاتصال</h5>
                    <div class="row g-3">
                        <div class="col-md-6"><label class="form-label fw-bold">رقم الهاتف</label><input type="text" name="contact_phone" class="form-control" value="<?php echo htmlspecialchars($siteSettings['contact_phone'] ?? ''); ?>"></div>
                        <div class="col-md-6"><label class="form-label fw-bold">البريد الإلكتروني</label><input type="email" name="contact_email" class="form-control" value="<?php echo htmlspecialchars($siteSettings['contact_email'] ?? ''); ?>"></div>
                    </div>
                </div>
            </div>
            <div class="card mb-4">
                <div class="card-body p-4">
                    <h5 class="mb-4 fw-bold text-primary">وسائل التواصل الاجتماعي</h5>
                    <div class="row g-3">
                        <div class="col-md-6"><label class="form-label fw-bold"><i class="fab fa-facebook"></i> Facebook</label><input type="url" name="facebook_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['facebook_url'] ?? ''); ?>"></div>
                        <div class="col-md-6"><label class="form-label fw-bold"><i class="fab fa-x-twitter"></i> X (Twitter)</label><input type="url" name="twitter_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['twitter_url'] ?? ''); ?>"></div>
                        <div class="col-md-6"><label class="form-label fw-bold"><i class="fab fa-instagram"></i> Instagram</label><input type="url" name="instagram_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['instagram_url'] ?? ''); ?>"></div>
                        <div class="col-md-6"><label class="form-label fw-bold"><i class="fab fa-youtube"></i> YouTube</label><input type="url" name="youtube_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['youtube_url'] ?? ''); ?>"></div>
                        <div class="col-md-6"><label class="form-label fw-bold"><i class="fab fa-tiktok"></i> TikTok</label><input type="url" name="tiktok_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['tiktok_url'] ?? ''); ?>"></div>
                        <div class="col-md-6"><label class="form-label fw-bold"><i class="fab fa-snapchat"></i> Snapchat</label><input type="url" name="snapchat_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['snapchat_url'] ?? ''); ?>"></div>
                        <div class="col-md-6"><label class="form-label fw-bold"><i class="fab fa-linkedin"></i> LinkedIn</label><input type="url" name="linkedin_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['linkedin_url'] ?? ''); ?>"></div>
                        <div class="col-md-6"><label class="form-label fw-bold"><i class="fab fa-telegram"></i> Telegram</label><input type="url" name="telegram_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['telegram_url'] ?? ''); ?>"></div>
                        <div class="col-md-6"><label class="form-label fw-bold"><i class="fab fa-threads"></i> Threads</label><input type="url" name="threads_url" class="form-control" value="<?php echo htmlspecialchars($siteSettings['threads_url'] ?? ''); ?>"></div>
                        <div class="col-md-6"><label class="form-label fw-bold"><i class="fab fa-whatsapp"></i> WhatsApp (رقم بدون +)</label><input type="text" name="whatsapp_number" class="form-control" placeholder="201012345678" value="<?php echo htmlspecialchars($siteSettings['whatsapp_number'] ?? ''); ?>"></div>
                    </div>
                </div>
            </div>
            <div class="card mb-4">
                <div class="card-body p-4">
                    <h5 class="mb-4 fw-bold text-primary">روابط تحميل التطبيق</h5>
                    <div class="row g-3">
                        <div class="col-md-6"><label class="form-label fw-bold"><i class="fab fa-google-play"></i> Google Play</label><input type="url" name="google_play_url" class="form-control" placeholder="https://play.google.com/store/apps/details?id=..." value="<?php echo htmlspecialchars($siteSettings['google_play_url'] ?? ''); ?>"></div>
                        <div class="col-md-6"><label class="form-label fw-bold"><i class="fab fa-apple"></i> App Store</label><input type="url" name="app_store_url" class="form-control" placeholder="https://apps.apple.com/app/..." value="<?php echo htmlspecialchars($siteSettings['app_store_url'] ?? ''); ?>"></div>
                    </div>
                </div>
            </div>
            <div class="card mb-4">
                <div class="card-body p-4">
                    <h5 class="mb-4 fw-bold text-primary">التحكم في ظهور الأيقونات والتطبيقات</h5>
                    <p class="text-muted mb-4">اختر أين تريد ظهور كل أيقونة (في الهيدر أو الفوتر أو كليهما):</p>
                    <div class="row g-4">
                        <!-- Facebook -->
                        <div class="col-md-6">
                            <div class="border rounded p-3" style="background: #f8f9fa;">
                                <h6 class="fw-bold mb-3"><i class="fab fa-facebook" style="color: #1877F2;"></i> Facebook</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="facebook_show_header" id="facebook_header" <?php echo ($siteSettings['facebook_show_header'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="facebook_header">عرض في الهيدر</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="facebook_show_footer" id="facebook_footer" <?php echo ($siteSettings['facebook_show_footer'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="facebook_footer">عرض في الفوتر</label>
                                </div>
                            </div>
                        </div>
                        <!-- Twitter -->
                        <div class="col-md-6">
                            <div class="border rounded p-3" style="background: #f8f9fa;">
                                <h6 class="fw-bold mb-3"><i class="fab fa-x-twitter" style="color: #000;"></i> X (Twitter)</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="twitter_show_header" id="twitter_header" <?php echo ($siteSettings['twitter_show_header'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="twitter_header">عرض في الهيدر</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="twitter_show_footer" id="twitter_footer" <?php echo ($siteSettings['twitter_show_footer'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="twitter_footer">عرض في الفوتر</label>
                                </div>
                            </div>
                        </div>
                        <!-- Instagram -->
                        <div class="col-md-6">
                            <div class="border rounded p-3" style="background: #f8f9fa;">
                                <h6 class="fw-bold mb-3"><i class="fab fa-instagram" style="color: #E4405F;"></i> Instagram</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="instagram_show_header" id="instagram_header" <?php echo ($siteSettings['instagram_show_header'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="instagram_header">عرض في الهيدر</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="instagram_show_footer" id="instagram_footer" <?php echo ($siteSettings['instagram_show_footer'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="instagram_footer">عرض في الفوتر</label>
                                </div>
                            </div>
                        </div>
                        <!-- YouTube -->
                        <div class="col-md-6">
                            <div class="border rounded p-3" style="background: #f8f9fa;">
                                <h6 class="fw-bold mb-3"><i class="fab fa-youtube" style="color: #FF0000;"></i> YouTube</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="youtube_show_header" id="youtube_header" <?php echo ($siteSettings['youtube_show_header'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="youtube_header">عرض في الهيدر</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="youtube_show_footer" id="youtube_footer" <?php echo ($siteSettings['youtube_show_footer'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="youtube_footer">عرض في الفوتر</label>
                                </div>
                            </div>
                        </div>
                        <!-- TikTok -->
                        <div class="col-md-6">
                            <div class="border rounded p-3" style="background: #f8f9fa;">
                                <h6 class="fw-bold mb-3"><i class="fab fa-tiktok" style="color: #000;"></i> TikTok</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="tiktok_show_header" id="tiktok_header" <?php echo ($siteSettings['tiktok_show_header'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="tiktok_header">عرض في الهيدر</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="tiktok_show_footer" id="tiktok_footer" <?php echo ($siteSettings['tiktok_show_footer'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="tiktok_footer">عرض في الفوتر</label>
                                </div>
                            </div>
                        </div>
                        <!-- Snapchat -->
                        <div class="col-md-6">
                            <div class="border rounded p-3" style="background: #f8f9fa;">
                                <h6 class="fw-bold mb-3"><i class="fab fa-snapchat" style="color: #FFFC00;"></i> Snapchat</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="snapchat_show_header" id="snapchat_header" <?php echo ($siteSettings['snapchat_show_header'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="snapchat_header">عرض في الهيدر</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="snapchat_show_footer" id="snapchat_footer" <?php echo ($siteSettings['snapchat_show_footer'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="snapchat_footer">عرض في الفوتر</label>
                                </div>
                            </div>
                        </div>
                        <!-- LinkedIn -->
                        <div class="col-md-6">
                            <div class="border rounded p-3" style="background: #f8f9fa;">
                                <h6 class="fw-bold mb-3"><i class="fab fa-linkedin" style="color: #0A66C2;"></i> LinkedIn</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="linkedin_show_header" id="linkedin_header" <?php echo ($siteSettings['linkedin_show_header'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="linkedin_header">عرض في الهيدر</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="linkedin_show_footer" id="linkedin_footer" <?php echo ($siteSettings['linkedin_show_footer'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="linkedin_footer">عرض في الفوتر</label>
                                </div>
                            </div>
                        </div>
                        <!-- Telegram -->
                        <div class="col-md-6">
                            <div class="border rounded p-3" style="background: #f8f9fa;">
                                <h6 class="fw-bold mb-3"><i class="fab fa-telegram" style="color: #0088cc;"></i> Telegram</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="telegram_show_header" id="telegram_header" <?php echo ($siteSettings['telegram_show_header'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="telegram_header">عرض في الهيدر</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="telegram_show_footer" id="telegram_footer" <?php echo ($siteSettings['telegram_show_footer'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="telegram_footer">عرض في الفوتر</label>
                                </div>
                            </div>
                        </div>
                        <!-- Threads -->
                        <div class="col-md-6">
                            <div class="border rounded p-3" style="background: #f8f9fa;">
                                <h6 class="fw-bold mb-3"><i class="fab fa-threads" style="color: #000;"></i> Threads</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="threads_show_header" id="threads_header" <?php echo ($siteSettings['threads_show_header'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="threads_header">عرض في الهيدر</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="threads_show_footer" id="threads_footer" <?php echo ($siteSettings['threads_show_footer'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="threads_footer">عرض في الفوتر</label>
                                </div>
                            </div>
                        </div>
                        <!-- WhatsApp -->
                        <div class="col-md-6">
                            <div class="border rounded p-3" style="background: #f8f9fa;">
                                <h6 class="fw-bold mb-3"><i class="fab fa-whatsapp" style="color: #25D366;"></i> WhatsApp</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="whatsapp_show_header" id="whatsapp_header" <?php echo ($siteSettings['whatsapp_show_header'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="whatsapp_header">عرض في الهيدر</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="whatsapp_show_footer" id="whatsapp_footer" <?php echo ($siteSettings['whatsapp_show_footer'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="whatsapp_footer">عرض في الفوتر</label>
                                </div>
                            </div>
                        </div>
                        <!-- Google Play -->
                        <div class="col-md-6">
                            <div class="border rounded p-3" style="background: #f8f9fa;">
                                <h6 class="fw-bold mb-3"><i class="fab fa-google-play" style="color: #34A853;"></i> Google Play</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="google_play_show_header" id="google_play_header" <?php echo ($siteSettings['google_play_show_header'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="google_play_header">عرض في الهيدر</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="google_play_show_footer" id="google_play_footer" <?php echo ($siteSettings['google_play_show_footer'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="google_play_footer">عرض في الفوتر</label>
                                </div>
                            </div>
                        </div>
                        <!-- App Store -->
                        <div class="col-md-6">
                            <div class="border rounded p-3" style="background: #f8f9fa;">
                                <h6 class="fw-bold mb-3"><i class="fab fa-apple" style="color: #000;"></i> App Store</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="app_store_show_header" id="app_store_header" <?php echo ($siteSettings['app_store_show_header'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="app_store_header">عرض في الهيدر</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="app_store_show_footer" id="app_store_footer" <?php echo ($siteSettings['app_store_show_footer'] ?? 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="app_store_footer">عرض في الفوتر</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- قسم سرعة معرض الصور -->
            <div class="card mb-4">
                <div class="card-body p-4">
                    <h5 class="mb-4 fw-bold text-primary">إعدادات معرض الصور (Slide Gallery)</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">سرعة التقليب (بالملي ثانية)</label>
                            <input type="number" name="gallery_speed" class="form-control" value="<?php echo $siteSettings['gallery_speed'] ?? 5000; ?>" min="1000" max="10000" step="500">
                            <small class="text-muted d-block mt-2">القيمة الافتراضية: 5000 (ملي ثانية)</small>
                        </div>
                    </div>
                </div>
            </div>
            <!-- قسم نص الفوتر -->
            <div class="card mb-4">
                <div class="card-body p-4">
                    <h5 class="mb-4 fw-bold text-primary">نص "عن تامر فتحي" في الفوتر</h5>
                    <div class="lang-section-ar mb-4">
                        <h6 class="mb-3 fw-bold">النص بالعربية</h6>
                        <textarea id="footer_about_text_editor" name="footer_about_text" class="form-control tinymce-editor" rows="4" placeholder="أدخل نص عن تامر فتحي..."><?php echo htmlspecialchars($siteSettings['footer_about_text'] ?? ''); ?></textarea>
                    </div>
                    <div class="lang-section-en mb-4">
                        <h6 class="mb-3 fw-bold">النص بالإنجليزية</h6>
                        <textarea id="footer_about_text_en_editor" name="footer_about_text_en" class="form-control tinymce-editor" rows="4" placeholder="Enter about text in English..."><?php echo htmlspecialchars($siteSettings['footer_about_text_en'] ?? ''); ?></textarea>
                    </div>
                </div>
            </div>
            <!-- قسم عدد الأيقونات في الفوتر -->
            <div class="card mb-4">
                <div class="card-body p-4">
                    <h5 class="mb-4 fw-bold text-primary">عدد الأيقونات في كل صف بالفوتر (قسم تابعنا)</h5>
                    <p class="text-muted mb-3">حدد عدد الأيقونات التي ستظهر في كل صف بالفوتر</p>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">عدد الأيقونات لكل صف</label>
                            <input type="number" name="footer_icons_per_row" class="form-control" value="<?php echo $siteSettings['footer_icons_per_row'] ?? 5; ?>" min="1" max="10">
                            <small class="text-muted d-block mt-2">القيمة الافتراضية: 5 أيقونات</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center mb-5"><button type="submit" class="btn btn-success btn-lg px-5 fw-bold">حفظ جميع الإعدادات</button></div>
        </form>
    </div>
</div>
<script src="auto_translate.js"></script>
<script>
tinymce.init({
    selector: '.tinymce-editor',
    language: 'ar',
    directionality: 'rtl',
    plugins: 'lists link image table code help wordcount',
    toolbar: 'undo redo | formatselect | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image table | removeformat | help',
    height: 300,
    menubar: 'file edit view insert format tools table help',
    branding: false
});

document.addEventListener('DOMContentLoaded', function() {
    liveTranslator.bindTranslationField('#site_title_ar', '#site_title_en', 800);
    liveTranslator.bindTranslationField('#hero_title_ar', '#hero_title_en', 800);
    liveTranslator.bindTranslationField('#hero_description_ar', '#hero_description_en', 1000);
    
    setTimeout(function() {
        const tinyEditor = tinymce.get('footer_about_text_editor');
        if(tinyEditor) {
            // استخدام 'change' و 'keyup' لضمان التقاط التغييرات فوراً
            const updateTranslation = function() {
                const arabicText = tinyEditor.getContent();
                if(arabicText.trim().length > 0) {
                    fetch('translate.php', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'text=' + encodeURIComponent(arabicText) + '&from=ar&to=en'
                    })
                    .then(response => response.json())
                    .then(data => {
                        // التحقق من كلاً من 'translatedText' و 'translated' لضمان التوافق
                        const translatedContent = data.translatedText || data.translated;
                        if(translatedContent) {
                            const enEditor = tinymce.get('footer_about_text_en_editor');
                            if(enEditor) {
                                enEditor.setContent(translatedContent);
                            }
                        }
                    })
                    .catch(error => console.error('Translation error:', error));
                }
            };
            
            tinyEditor.on('change', updateTranslation);
            tinyEditor.on('blur', updateTranslation);
        }
    }, 1500);
});
</script>
</body>
</html>
