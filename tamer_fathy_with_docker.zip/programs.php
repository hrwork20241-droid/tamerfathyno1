<?php 
$lang = isset($_GET['lang']) && $_GET['lang'] == 'en' ? 'en' : 'ar';
if ($lang == 'en') {
    include 'includes/header_en.php';
} else {
    include 'includes/header.php';
}
?>

<section class="py-5 bg-light">
    <div class="container">
        <h2 class="section-title"><?php echo $lang == 'en' ? 'My TV <span class="gold-text">Programs</span>' : 'برامجي <span class="gold-text">التلفزيونية</span>'; ?></h2>
        <div class="row g-4">
            <?php
            // محاولة جلب البيانات بالترتيب، وإذا فشل الحقل نستخدم الترتيب العادي
            try {
                $stmt = $pdo->query("SELECT * FROM programs ORDER BY sort_order ASC");
            } catch (PDOException $e) {
                $stmt = $pdo->query("SELECT * FROM programs ORDER BY id DESC");
            }
            
            while ($row = $stmt->fetch()) {
                $v_url = isset($row['video_url']) ? $row['video_url'] : '';
                // عرض المحتوى بناءً على اللغة المختارة مع منطق الترجمة التلقائية
                $title = ($lang == 'en' && !empty($row['title_en'])) ? $row['title_en'] : $row['title'];
                $description = ($lang == 'en' && !empty($row['description_en'])) ? $row['description_en'] : $row['description'];
                $channel = ($lang == 'en' && !empty($row['channel_en'])) ? $row['channel_en'] : $row['channel'];
            ?>
            <div class="col-md-6 col-lg-4">
                <div class="card h-100 border-0 shadow-sm overflow-hidden">
                    <div class="position-relative">
                        <img src="uploads/<?php echo $row['image']; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($title); ?>" style="height: 250px; object-fit: cover;">
                        <?php if(!empty($v_url)): ?>
                            <a href="<?php echo $v_url; ?>" target="_blank" class="position-absolute top-50 start-50 translate-middle text-white">
                                <i class="fas fa-play-circle fa-4x opacity-75"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title fw-bold text-danger"><?php echo htmlspecialchars($title); ?></h5>
                        <p class="card-text text-muted small"><?php echo $description; ?></p>
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <span class="badge bg-dark"><?php echo $lang == 'en' ? 'Channel: ' : 'قناة: '; ?><?php echo htmlspecialchars($channel); ?></span>
                            <span class="badge bg-danger"><?php echo $lang == 'en' ? 'Season: ' : 'موسم: '; ?><?php echo $row['seasons']; ?></span>
                        </div>
                        <?php if(!empty($v_url)): ?>
                            <div class="mt-3">
                                <a href="<?php echo $v_url; ?>" target="_blank" class="btn btn-sm btn-outline-danger w-100 fw-bold"><i class="fab fa-youtube me-2"></i><?php echo $lang == 'en' ? 'Watch Episode' : 'شاهد الحلقة'; ?></a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php } ?>
            <?php if ($stmt->rowCount() == 0): ?>
                <div class="col-12 text-center py-5"><h4 class="text-muted"><?php echo $lang == 'en' ? 'Programs coming soon...' : 'سيتم إضافة البرامج قريباً...'; ?></h4></div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php 
if ($lang == 'en') {
    include 'includes/footer_en.php';
} else {
    include 'includes/footer.php';
}
?>
