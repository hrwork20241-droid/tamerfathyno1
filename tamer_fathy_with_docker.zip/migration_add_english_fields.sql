-- ملف الترحيل: إضافة أعمدة اللغة الإنجليزية إلى جميع الجداول
-- هذا الملف يفصل المحتوى العربي عن الإنجليزي في قاعدة البيانات

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- 1. تحديث جدول الإعدادات
ALTER TABLE `settings` ADD COLUMN `site_title_en` varchar(255) DEFAULT 'Media Professional Tamer Fathy' AFTER `site_title`;

-- 2. تحديث جدول البرامج
ALTER TABLE `programs` ADD COLUMN `title_en` varchar(255) DEFAULT NULL AFTER `title`;
ALTER TABLE `programs` ADD COLUMN `description_en` text DEFAULT NULL AFTER `description`;
ALTER TABLE `programs` ADD COLUMN `channel_en` varchar(100) DEFAULT 'Al Hadath Today' AFTER `channel`;

-- 3. تحديث جدول البودكاست
ALTER TABLE `podcasts` ADD COLUMN `title_en` varchar(255) DEFAULT NULL AFTER `title`;
ALTER TABLE `podcasts` ADD COLUMN `description_en` text DEFAULT NULL AFTER `description`;

-- 4. تحديث جدول من أنا
ALTER TABLE `about_me` ADD COLUMN `content_en` text DEFAULT NULL AFTER `content`;

-- 5. تحديث جدول المدونة
ALTER TABLE `blog` ADD COLUMN `title_en` varchar(255) DEFAULT NULL AFTER `title`;
ALTER TABLE `blog` ADD COLUMN `content_en` text DEFAULT NULL AFTER `content`;

-- 6. تحديث جدول الصور والكواليس
ALTER TABLE `gallery` ADD COLUMN `title_en` varchar(255) DEFAULT NULL AFTER `title`;

-- 7. تحديث جدول الجوائز
ALTER TABLE `awards` ADD COLUMN `title_en` varchar(255) DEFAULT NULL AFTER `title`;
ALTER TABLE `awards` ADD COLUMN `description_en` text DEFAULT NULL AFTER `description`;
ALTER TABLE `awards` ADD COLUMN `year_en` varchar(10) DEFAULT NULL AFTER `year`;

-- 8. تحديث جدول الفعاليات
ALTER TABLE `events` ADD COLUMN `title_en` varchar(255) DEFAULT NULL AFTER `title`;
ALTER TABLE `events` ADD COLUMN `location_en` varchar(255) DEFAULT NULL AFTER `location`;
ALTER TABLE `events` ADD COLUMN `description_en` text DEFAULT NULL AFTER `description`;

-- 9. تحديث جدول التعاون مع صناع المحتوى
ALTER TABLE `collaborations` ADD COLUMN `title_en` varchar(255) DEFAULT NULL AFTER `title`;
ALTER TABLE `collaborations` ADD COLUMN `description_en` text DEFAULT NULL AFTER `description`;

-- 10. تحديث جدول الأسئلة الشائعة
ALTER TABLE `faqs` ADD COLUMN `question_en` text DEFAULT NULL AFTER `question`;
ALTER TABLE `faqs` ADD COLUMN `answer_en` text DEFAULT NULL AFTER `answer`;

-- 11. تحديث جدول الصفحات المخصصة
ALTER TABLE `custom_pages` ADD COLUMN `title_en` varchar(255) DEFAULT NULL AFTER `title`;
ALTER TABLE `custom_pages` ADD COLUMN `slug_en` varchar(255) DEFAULT NULL AFTER `slug`;
ALTER TABLE `custom_pages` ADD COLUMN `meta_description_en` varchar(255) DEFAULT NULL AFTER `meta_description`;
ALTER TABLE `custom_pages` ADD COLUMN `content_en` longtext DEFAULT NULL AFTER `content`;

COMMIT;
