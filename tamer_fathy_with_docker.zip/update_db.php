<?php
include 'includes/db.php';

try {
    echo "<h2>بدء تحديث قاعدة البيانات...</h2>";

    // 1. إضافة حقول لجدول البرامج (programs)
    $pdo->exec("ALTER TABLE programs ADD COLUMN IF NOT EXISTS video_url VARCHAR(255) AFTER image");
    $pdo->exec("ALTER TABLE programs ADD COLUMN IF NOT EXISTS sort_order INT DEFAULT 0 AFTER seasons");
    echo "<p style='color:green;'>✓ تم تحديث جدول البرامج بنجاح.</p>";

    // 2. إضافة حقول لجدول البودكاست (podcasts)
    $pdo->exec("ALTER TABLE podcasts ADD COLUMN IF NOT EXISTS video_file VARCHAR(255) AFTER audio_url");
    $pdo->exec("ALTER TABLE podcasts ADD COLUMN IF NOT EXISTS video_url VARCHAR(255) AFTER video_file");
    $pdo->exec("ALTER TABLE podcasts ADD COLUMN IF NOT EXISTS thumbnail VARCHAR(255) AFTER video_url");
    $pdo->exec("ALTER TABLE podcasts ADD COLUMN IF NOT EXISTS sort_order INT DEFAULT 0 AFTER description");
    echo "<p style='color:green;'>✓ تم تحديث جدول البودكاست بنجاح.</p>";

    // 3. إضافة حقول لجدول الإعدادات (settings) لروابط التواصل الجديدة
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS tiktok_url VARCHAR(255) AFTER youtube_url");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS snapchat_url VARCHAR(255) AFTER tiktok_url");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS linkedin_url VARCHAR(255) AFTER snapchat_url");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS whatsapp_number VARCHAR(20) AFTER linkedin_url");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS google_play_url VARCHAR(255) AFTER whatsapp_number");
    $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS app_store_url VARCHAR(255) AFTER google_play_url");
    echo "<p style='color:green;'>✓ تم تحديث جدول الإعدادات بنجاح.</p>";

    echo "<h3 style='color:blue;'>تم التحديث بنجاح! يمكنك الآن استخدام لوحة التحكم والبرامج بدون مشاكل.</h3>";
    echo "<a href='index.php' style='padding:10px 20px; background:#cc0000; color:#fff; text-decoration:none; border-radius:5px;'>العودة للموقع</a>";

} catch (PDOException $e) {
    echo "<p style='color:red;'>خطأ أثناء التحديث: " . $e->getMessage() . "</p>";
}
?>
