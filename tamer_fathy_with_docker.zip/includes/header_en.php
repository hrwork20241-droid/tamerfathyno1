<?php 
include_once 'db.php'; 
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ($siteSettings['site_title'] ?? 'Tamer Fathy') . ' - Media Professional'; ?></title>
    <link rel="icon" type="image/x-icon" href="uploads/<?php echo $siteSettings['site_favicon'] ?? 'favicon.ico'; ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #ffffff; color: #333; }
        .navbar { background-color: #cc0000 !important; box-shadow: 0 2px 4px rgba(0,0,0,0.1); border-bottom: 4px solid #000; transition: 0.3s; }
        .navbar-brand, .nav-link { color: #fff !important; font-weight: bold; }
        .nav-link { display: inline-flex; align-items: center; gap: 3px; padding: 6px 8px !important; border-radius: 999px; transition: 0.3s; font-size: 0.85rem; white-space: nowrap; }
        .nav-link i { font-size: 0.8rem; background: rgba(255,255,255,0.14); width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; border-radius: 50%; transition: 0.3s; }
        .nav-link:hover { color: #ffeb3b !important; background: rgba(255,255,255,0.08); }
        .nav-link:hover i { background: rgba(255,235,59,0.22); transform: scale(1.08); }
        .nav-link { position: relative; }
        .nav-link.active::after {
            content: '';
            position: absolute;
            bottom: 2px;
            left: 15%;
            width: 70%;
            height: 3px;
            background: linear-gradient(90deg, #D4AF37, #FFFACD, #D4AF37);
            border-radius: 5px;
            box-shadow: 0 0 8px rgba(255, 215, 0, 0.6);
            animation: shine-sweep 2s linear infinite;
        }
        .nav-link.active { color: #ffeb3b !important; }
        .nav-link.active i { background: rgba(255,235,59,0.3) !important; color: #ffeb3b !important; }
        .social-icons-container { display: flex !important; align-items: center !important; gap: 10px !important; margin-left: 10px; flex-wrap: wrap; }
        .social-icons-container a { width: 36px !important; height: 36px !important; display: inline-flex !important; align-items: center !important; justify-content: center !important; border-radius: 50% !important; transition: 0.3s !important; text-decoration: none !important; font-size: 1.1rem !important; box-shadow: 0 2px 8px rgba(0,0,0,0.2) !important; }
        .social-icons-container a:hover { transform: translateY(-4px) scale(1.1); box-shadow: 0 4px 12px rgba(0,0,0,0.3) !important; }
        .social-icons-container a.facebook { background: #1877F2 !important; color: white !important; }
        .social-icons-container a.twitter { background: #000000 !important; color: white !important; }
        .social-icons-container a.instagram { background: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%) !important; color: white !important; }
        .social-icons-container a.youtube { background: #FF0000 !important; color: white !important; }
        .social-icons-container a.tiktok { background: #000000 !important; color: white !important; }
        .social-icons-container a.snapchat { background: #FFFC00 !important; color: #000 !important; }
        .social-icons-container a.linkedin { background: #0A66C2 !important; color: white !important; }
        .social-icons-container a.telegram { background: #0088cc !important; color: white !important; }
        .social-icons-container a.threads { background: #000000 !important; color: white !important; }
        .social-icons-container a.whatsapp { background: #25D366 !important; color: white !important; }
        .app-download-btn { display: inline-flex !important; align-items: center !important; gap: 6px !important; background: rgba(255,255,255,0.95) !important; border: none !important; color: #333 !important; border-radius: 8px !important; padding: 6px 12px !important; font-size: 0.75rem !important; font-weight: bold !important; text-decoration: none !important; transition: 0.3s !important; white-space: nowrap !important; box-shadow: 0 2px 8px rgba(0,0,0,0.15) !important; }
        .app-download-btn:hover { background: rgba(255,255,255,1) !important; color: #000 !important; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.25) !important; }
        .app-download-btn i { font-size: 1rem !important; }
        .app-download-btn.google-play { background: linear-gradient(135deg, #34A853 0%, #1F9E3A 100%) !important; color: white !important; }
        .app-download-btn.google-play:hover { background: linear-gradient(135deg, #2d8e47 0%, #1a8830 100%) !important; }
        .app-download-btn.app-store { background: linear-gradient(135deg, #555555 0%, #222222 100%) !important; color: white !important; }
        .app-download-btn.app-store:hover { background: linear-gradient(135deg, #444444 0%, #111111 100%) !important; }
        .section-title { position: relative; padding-bottom: 25px; margin-bottom: 45px; text-align: center; font-weight: 800; color: #cc0000; font-size: 2.5rem; text-shadow: 1px 1px 2px rgba(0,0,0,0.05); }
        .section-title span.gold-text { 
            background: linear-gradient(90deg, #B8860B 0%, #D4AF37 20%, #FFD700 40%, #FFFACD 50%, #FFD700 60%, #D4AF37 80%, #B8860B 100%);
            background-size: 200% auto;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: 900;
            filter: drop-shadow(0px 2px 4px rgba(184, 134, 11, 0.6)) brightness(1.1);
            display: inline-block;
            animation: shine-sweep 2s linear infinite;
        }
        .section-title::after { 
            content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); 
            width: 180px; height: 5px; 
            background: linear-gradient(90deg, transparent, #B8860B, #D4AF37, #FFD700, #FFFACD, #FFD700, #D4AF37, #B8860B, transparent); 
            background-size: 200% auto;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(212, 175, 55, 0.9), 0 0 40px rgba(212, 175, 55, 0.4);
            animation: shine-sweep 2s linear infinite;
        }
        @keyframes shine-sweep { to { background-position: 200% center; } }
        .footer { background-color: #000000 !important; color: #fff !important; padding: 50px 0; }
        .float {
            position: fixed; width: 60px; height: 60px; bottom: 40px; right: 40px;
            background-color: #25d366; color: #FFF; border-radius: 50px; text-align: center;
            font-size: 30px; box-shadow: 2px 2px 3px #999; z-index: 1000;
            display: flex; align-items: center; justify-content: center;
            text-decoration: none; transition: 0.3s;
        }
        .float:hover { background-color: #128c7e; color: #fff; transform: scale(1.1); }
        .back-to-top {
            position: fixed; bottom: 115px; right: 40px; width: 50px; height: 50px;
            background-color: #cc0000; color: #fff; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            z-index: 999; cursor: pointer; transition: 0.3s; opacity: 0; visibility: hidden; text-decoration: none;
        }
        .back-to-top.show { opacity: 1; visibility: visible; }
        .back-to-top:hover { background-color: #000; color: #fff; transform: translateY(-5px); }
        /* Language switcher */
        .lang-switcher { background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.4); color: #fff !important; border-radius: 20px; padding: 4px 12px; font-size: 0.85rem; font-weight: bold; text-decoration: none; transition: 0.3s; }
        .lang-switcher:hover { background: rgba(255,255,255,0.3); color: #ffeb3b !important; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container-fluid px-4">
        <a class="navbar-brand d-flex align-items-center" href="index_en.php">
            <?php if(!empty($siteSettings['site_logo'])): ?>
                <img src="uploads/<?php echo $siteSettings['site_logo']; ?>" alt="Logo" height="45" class="me-2">
            <?php endif; ?>
            <span>Media Professional Tamer Fathy</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavEN">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavEN">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'index_en.php') ? 'active' : ''; ?>" href="index_en.php"><i class="fas fa-house"></i><span>Home</span></a></li>
                <li class="nav-item"><a class="nav-link" href="about.php?lang=en"><i class="fas fa-user-tie"></i><span>About</span></a></li>
                <li class="nav-item"><a class="nav-link" href="programs.php?lang=en"><i class="fas fa-tv"></i><span>Programs</span></a></li>
                <li class="nav-item"><a class="nav-link" href="blog.php?lang=en"><i class="fas fa-pen-nib"></i><span>Blog</span></a></li>
                <li class="nav-item"><a class="nav-link" href="gallery.php?lang=en"><i class="fas fa-image"></i><span>Gallery</span></a></li>
                <li class="nav-item"><a class="nav-link" href="awards.php?lang=en"><i class="fas fa-trophy"></i><span>Awards</span></a></li>
                <li class="nav-item"><a class="nav-link" href="podcasts.php?lang=en"><i class="fas fa-podcast"></i><span>Podcast</span></a></li>
                <li class="nav-item"><a class="nav-link" href="events.php?lang=en"><i class="fas fa-calendar-days"></i><span>Events</span></a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php?lang=en"><i class="fas fa-envelope-open-text"></i><span>Contact</span></a></li>
            </ul>
            <div class="d-flex align-items-center gap-2 flex-wrap">
                <a href="index.php" class="lang-switcher"><i class="fas fa-globe me-1"></i> العربية</a>
                <div class="social-icons-container">
                    <?php if(!empty($siteSettings['facebook_url'])): ?><a href="<?php echo $siteSettings['facebook_url']; ?>" target="_blank" title="Facebook" class="facebook"><i class="fab fa-facebook-f"></i></a><?php endif; ?>
                    <?php if(!empty($siteSettings['twitter_url'])): ?><a href="<?php echo $siteSettings['twitter_url']; ?>" target="_blank" title="X (Twitter)" class="twitter"><i class="fab fa-x-twitter"></i></a><?php endif; ?>
                    <?php if(!empty($siteSettings['instagram_url'])): ?><a href="<?php echo $siteSettings['instagram_url']; ?>" target="_blank" title="Instagram" class="instagram"><i class="fab fa-instagram"></i></a><?php endif; ?>
                    <?php if(!empty($siteSettings['youtube_url'])): ?><a href="<?php echo $siteSettings['youtube_url']; ?>" target="_blank" title="YouTube" class="youtube"><i class="fab fa-youtube"></i></a><?php endif; ?>
                    <?php if(!empty($siteSettings['tiktok_url'])): ?><a href="<?php echo $siteSettings['tiktok_url']; ?>" target="_blank" title="TikTok" class="tiktok"><i class="fab fa-tiktok"></i></a><?php endif; ?>
                    <?php if(!empty($siteSettings['snapchat_url'])): ?><a href="<?php echo $siteSettings['snapchat_url']; ?>" target="_blank" title="Snapchat" class="snapchat"><i class="fab fa-snapchat"></i></a><?php endif; ?>
                    <?php if(!empty($siteSettings['linkedin_url'])): ?><a href="<?php echo $siteSettings['linkedin_url']; ?>" target="_blank" title="LinkedIn" class="linkedin"><i class="fab fa-linkedin-in"></i></a><?php endif; ?>
                    <?php if(!empty($siteSettings['telegram_url'])): ?><a href="<?php echo $siteSettings['telegram_url']; ?>" target="_blank" title="Telegram" class="telegram"><i class="fab fa-telegram"></i></a><?php endif; ?>
                    <?php if(!empty($siteSettings['threads_url'])): ?><a href="<?php echo $siteSettings['threads_url']; ?>" target="_blank" title="Threads" class="threads"><i class="fab fa-threads"></i></a><?php endif; ?>
                    <?php if(!empty($siteSettings['whatsapp_number'])): ?><a href="https://wa.me/<?php echo $siteSettings['whatsapp_number']; ?>" target="_blank" title="WhatsApp" class="whatsapp"><i class="fab fa-whatsapp"></i></a><?php endif; ?>
                </div>
                <?php if(!empty($siteSettings['google_play_url']) || !empty($siteSettings['app_store_url'])): ?>
                <div class="d-flex align-items-center gap-2">
                    <?php if(!empty($siteSettings['google_play_url'])): ?>
                    <a href="<?php echo htmlspecialchars($siteSettings['google_play_url']); ?>" target="_blank" class="app-download-btn google-play" title="Download on Google Play">
                        <i class="fab fa-google-play"></i> <span class="d-none d-lg-inline">Google Play</span>
                    </a>
                    <?php endif; ?>
                    <?php if(!empty($siteSettings['app_store_url'])): ?>
                    <a href="<?php echo htmlspecialchars($siteSettings['app_store_url']); ?>" target="_blank" class="app-download-btn app-store" title="Download on App Store">
                        <i class="fab fa-apple"></i> <span class="d-none d-lg-inline">App Store</span>
                    </a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<!-- WhatsApp Float -->
<a href="https://wa.me/<?php echo $siteSettings['whatsapp_number'] ?? '0096560022415'; ?>" class="float" target="_blank" title="Contact us via WhatsApp">
    <i class="fab fa-whatsapp"></i>
</a>

<!-- Back to Top -->
<a href="javascript:void(0)" class="back-to-top" id="backToTopEN" onclick="window.scrollTo({top: 0, behavior: 'smooth'});" title="Back to Top">
    <i class="fas fa-chevron-up"></i>
</a>

<script>
    window.addEventListener('scroll', function() {
        var backToTop = document.getElementById('backToTopEN');
        if (window.pageYOffset > 300) {
            backToTop.classList.add('show');
        } else {
            backToTop.classList.remove('show');
        }
    });
</script>
