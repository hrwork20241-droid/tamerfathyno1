<?php
/**
 * ملف الترجمة التلقائية
 * يستخدم Google Translate API للترجمة من العربية إلى الإنجليزية
 */

class AutoTranslator {
    private $apiKey = '';
    private $useGoogleAPI = false;
    
    public function __construct() {
        // يمكن إضافة مفتاح API هنا إذا توفر
        // $this->apiKey = getenv('GOOGLE_TRANSLATE_API_KEY');
        // $this->useGoogleAPI = !empty($this->apiKey);
    }
    
    /**
     * ترجمة النص من العربية إلى الإنجليزية
     * تستخدم Google Translate عبر واجهة ويب (بدون API)
     */
    public function translateArabicToEnglish($text) {
        if (empty($text)) {
            return '';
        }
        
        // إذا كان النص يحتوي على أحرف إنجليزية فقط، لا تترجم
        if (!$this->containsArabic($text)) {
            return $text;
        }
        
        try {
            // استخدام Google Translate عبر واجهة ويب
            $translatedText = $this->translateViaGoogleWeb($text);
            return $translatedText;
        } catch (Exception $e) {
            // في حالة الفشل، إرجاع النص الأصلي
            return $text;
        }
    }
    
    /**
     * التحقق من وجود أحرف عربية في النص
     */
    private function containsArabic($text) {
        return preg_match('/[\x{0600}-\x{06FF}]/u', $text);
    }
    
    /**
     * الترجمة عبر واجهة Google Translate
     */
    private function translateViaGoogleWeb($text) {
        // ترميز النص
        $encodedText = urlencode($text);
        
        // بناء رابط الترجمة
        $url = "https://translate.googleapis.com/translate_a/element.js?cb=googleTranslateElementInit";
        
        // محاولة استخدام طريقة بديلة عبر cURL
        $translatedText = $this->translateViaCurl($text);
        
        return $translatedText;
    }
    
    /**
     * الترجمة باستخدام cURL
     */
    private function translateViaCurl($text) {
        try {
            $ch = curl_init();
            
            // إعدادات cURL
            curl_setopt($ch, CURLOPT_URL, 'https://translate.googleapis.com/translate_a/single');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
                'client' => 'gtx',
                'sl' => 'ar',
                'tl' => 'en',
                'dt' => 't',
                'q' => $text
            ]));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode == 200 && !empty($response)) {
                // معالجة الاستجابة
                $result = json_decode($response, true);
                
                if (is_array($result) && isset($result[0]) && is_array($result[0])) {
                    $translatedText = '';
                    foreach ($result[0] as $item) {
                        if (is_array($item) && isset($item[0])) {
                            $translatedText .= $item[0];
                        }
                    }
                    return $translatedText;
                }
            }
        } catch (Exception $e) {
            // في حالة الخطأ، إرجاع النص الأصلي
        }
        
        return $text;
    }
    
    /**
     * ترجمة بسيطة باستخدام قائمة كلمات شائعة (بديل سريع)
     */
    public function translateSimple($text) {
        if (empty($text)) {
            return '';
        }
        
        // قائمة الكلمات الشائعة والترجمات
        $translations = [
            'السلام عليكم' => 'Hello',
            'مرحبا' => 'Hello',
            'شكرا' => 'Thank you',
            'من فضلك' => 'Please',
            'نعم' => 'Yes',
            'لا' => 'No',
            'عذرا' => 'Sorry',
            'معذرة' => 'Excuse me',
        ];
        
        foreach ($translations as $ar => $en) {
            if (stripos($text, $ar) !== false) {
                return str_ireplace($ar, $en, $text);
            }
        }
        
        return $text;
    }
}

// إنشاء instance عام للاستخدام
$translator = new AutoTranslator();

/**
 * دالة مساعدة للترجمة السريعة
 */
function translateToEnglish($text) {
    global $translator;
    return $translator->translateArabicToEnglish($text);
}
?>
