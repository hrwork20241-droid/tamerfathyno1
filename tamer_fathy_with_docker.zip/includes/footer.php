<?php
// جلب الصفحات المخصصة التي يجب أن تظهر في الفوتر
$custom_footer_pages = $pdo->query("SELECT * FROM custom_pages WHERE is_active = 1 AND (display_location = 'footer' OR display_location = 'both') ORDER BY sort_order ASC, id DESC")->fetchAll();
?>
<footer class="footer" style="background-color: #000000 !important; color: #ffffff !important; padding: 50px 0;">
    <div class="container text-center">
        <div class="row g-4">
            <div class="col-md-4">
                <h5 class="fw-bold mb-3">عن تامر فتحي</h5>
                <div class="text-light opacity-75 footer-about-content" style="line-height: 1.6; text-align: center; width: 100%; display: block;">
                    <style>
                        .footer-about-content p, .footer-about-content div { margin-bottom: 8px !important; text-align: center !important; width: 100% !important; display: block !important; }
                    </style>
                    <?php echo $siteSettings['footer_about_text'] ?? 'إعلامي ومقدم برامج تلفزيونية متميز، مقدم برنامج "نمبر وان" على قناة الحدث اليوم. نسعى لتقديم محتوى إعلامي هادف يخدم المجتمع.'; ?>
                </div>
            </div>
            <div class="col-md-4">
                <h5 class="fw-bold mb-3">روابط سريعة</h5>
                <ul class="list-unstyled">
                    <li><a href="about.php" class="text-light text-decoration-none opacity-75 hover-opacity-100 mb-2 d-block">من أنا</a></li>
                    <li><a href="programs.php" class="text-light text-decoration-none opacity-75 hover-opacity-100 mb-2 d-block">البرامج</a></li>
                    
                    <!-- عرض الصفحات المضافة مسبقاً في الفوتر -->
                    <?php foreach ($custom_footer_pages as $cp): ?>
                        <li><a href="page.php?slug=<?php echo $cp['slug']; ?>" class="text-light text-decoration-none opacity-75 hover-opacity-100 mb-2 d-block"><?php echo htmlspecialchars($cp['title']); ?></a></li>
                    <?php endforeach; ?>

                    <li><a href="contact.php" class="text-light text-decoration-none opacity-75 hover-opacity-100 mb-2 d-block">اتصل بي</a></li>
                    <li><a href="faqs.php" class="text-light text-decoration-none opacity-75 hover-opacity-100 mb-2 d-block">الأسئلة الشائعة</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5 class="fw-bold mb-3">تابعني على</h5>
                <?php 
                    $icons_per_row = intval($siteSettings['footer_icons_per_row'] ?? 5);
                    $social_icons = [];
                    if(!empty($siteSettings['facebook_url']) && ($siteSettings['facebook_show_footer'] ?? 1)) $social_icons[] = ['url' => $siteSettings['facebook_url'], 'icon' => 'fab fa-facebook-f', 'title' => 'Facebook'];
                    if(!empty($siteSettings['twitter_url']) && ($siteSettings['twitter_show_footer'] ?? 1)) $social_icons[] = ['url' => $siteSettings['twitter_url'], 'icon' => 'fab fa-x-twitter', 'title' => 'X (Twitter)'];
                    if(!empty($siteSettings['instagram_url']) && ($siteSettings['instagram_show_footer'] ?? 1)) $social_icons[] = ['url' => $siteSettings['instagram_url'], 'icon' => 'fab fa-instagram', 'title' => 'Instagram'];
                    if(!empty($siteSettings['youtube_url']) && ($siteSettings['youtube_show_footer'] ?? 1)) $social_icons[] = ['url' => $siteSettings['youtube_url'], 'icon' => 'fab fa-youtube', 'title' => 'YouTube'];
                    if(!empty($siteSettings['tiktok_url']) && ($siteSettings['tiktok_show_footer'] ?? 1)) $social_icons[] = ['url' => $siteSettings['tiktok_url'], 'icon' => 'fab fa-tiktok', 'title' => 'TikTok'];
                    if(!empty($siteSettings['snapchat_url']) && ($siteSettings['snapchat_show_footer'] ?? 1)) $social_icons[] = ['url' => $siteSettings['snapchat_url'], 'icon' => 'fab fa-snapchat', 'title' => 'Snapchat'];
                    if(!empty($siteSettings['linkedin_url']) && ($siteSettings['linkedin_show_footer'] ?? 1)) $social_icons[] = ['url' => $siteSettings['linkedin_url'], 'icon' => 'fab fa-linkedin-in', 'title' => 'LinkedIn'];
                    if(!empty($siteSettings['whatsapp_number']) && ($siteSettings['whatsapp_show_footer'] ?? 1)) $social_icons[] = ['url' => 'https://wa.me/' . $siteSettings['whatsapp_number'], 'icon' => 'fab fa-whatsapp', 'title' => 'WhatsApp'];
                    if(!empty($siteSettings['telegram_url']) && ($siteSettings['telegram_show_footer'] ?? 1)) $social_icons[] = ['url' => $siteSettings['telegram_url'], 'icon' => 'fab fa-telegram', 'title' => 'Telegram'];
                    if(!empty($siteSettings['threads_url']) && ($siteSettings['threads_show_footer'] ?? 1)) $social_icons[] = ['url' => $siteSettings['threads_url'], 'icon' => 'fab fa-threads', 'title' => 'Threads'];
                    
                    $total_icons = count($social_icons);
                    $rows = ceil($total_icons / $icons_per_row);
                    $icon_index = 0;
                    
                    for ($row = 0; $row < $rows; $row++) {
                        echo '<div class="social-links mt-3 d-flex justify-content-center flex-wrap gap-3 mb-3">';
                        for ($col = 0; $col < $icons_per_row && $icon_index < $total_icons; $col++, $icon_index++) {
                            $icon = $social_icons[$icon_index];
                            echo '<a href="' . htmlspecialchars($icon['url']) . '" target="_blank" class="social-forced-link" title="' . htmlspecialchars($icon['title']) . '" data-platform="' . strtolower(str_replace(' ', '-', $icon['title'])) . '"><i class="' . $icon['icon'] . ' fa-lg"></i></a>';
                        }
                        echo '</div>';
                    }
                ?>
                
                <h5 class="fw-bold mb-3 mt-3">حمل التطبيق</h5>
                <div class="app-download-section d-flex justify-content-center flex-wrap gap-3">
                    <?php if(!empty($siteSettings['google_play_url']) && ($siteSettings['google_play_show_footer'] ?? 1)): ?>
                        <a href="<?php echo $siteSettings['google_play_url']; ?>" target="_blank" class="btn fw-bold px-4 py-2 d-flex align-items-center gap-2" style="background: linear-gradient(135deg, #34A853 0%, #1F9E3A 100%); color: white; font-size: 0.85rem; border: none; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.2); transition: 0.3s;" onmouseover="this.style.boxShadow='0 4px 12px rgba(0,0,0,0.3)'; this.style.transform='translateY(-2px)';" onmouseout="this.style.boxShadow='0 2px 8px rgba(0,0,0,0.2)'; this.style.transform='translateY(0)';">
                            <i class="fab fa-google-play" style="font-size: 1.1rem;"></i>
                            <span>Google Play</span>
                        </a>
                    <?php endif; ?>
                    <?php if(!empty($siteSettings['app_store_url']) && ($siteSettings['app_store_show_footer'] ?? 1)): ?>
                        <a href="<?php echo $siteSettings['app_store_url']; ?>" target="_blank" class="btn fw-bold px-4 py-2 d-flex align-items-center gap-2" style="background: linear-gradient(135deg, #555555 0%, #222222 100%); color: white; font-size: 0.85rem; border: none; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.2); transition: 0.3s;" onmouseover="this.style.boxShadow='0 4px 12px rgba(0,0,0,0.3)'; this.style.transform='translateY(-2px)';" onmouseout="this.style.boxShadow='0 2px 8px rgba(0,0,0,0.2)'; this.style.transform='translateY(0);">
                            <i class="fab fa-apple" style="font-size: 1.1rem;"></i>
                            <span>App Store</span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <hr class="my-4 border-secondary">
        <div class="d-flex justify-content-center align-items-center gap-3 flex-wrap">
            <p class="mb-0 opacity-75">جميع الحقوق محفوظة &copy; <?php echo date('Y'); ?> للإعلامي تامر فتحي | تصميم وتطوير احترافي</p>
            <a href="index_en.php" class="btn btn-outline-light btn-sm rounded-pill px-3 fw-bold" style="font-size: 0.8rem; border-color: rgba(255,255,255,0.3);"><i class="fas fa-globe me-1"></i> English Version (EN)</a>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<style>
    .hover-opacity-100:hover { opacity: 1 !important; transition: 0.3s; }
    .social-forced-link { 
        transition: 0.3s !important; 
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        width: 50px !important; 
        height: 50px !important;
        border-radius: 50% !important;
        text-decoration: none !important;
        visibility: visible !important;
        opacity: 1 !important;
        color: white !important;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3) !important;
    }
    .social-forced-link:hover { 
        transform: translateY(-3px) !important; 
        box-shadow: 0 4px 12px rgba(0,0,0,0.4) !important;
    }
    /* ألوان المنصات الرسمية */
    .social-forced-link[data-platform="facebook"] { background: #1877F2 !important; }
    .social-forced-link[data-platform="x-twitter"] { background: #000000 !important; }
    .social-forced-link[data-platform="instagram"] { background: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%) !important; }
    .social-forced-link[data-platform="youtube"] { background: #FF0000 !important; }
    .social-forced-link[data-platform="tiktok"] { background: linear-gradient(135deg, #000000 0%, #25F4EE 100%) !important; }
    .social-forced-link[data-platform="snapchat"] { background: #FFFC00 !important; color: #000 !important; }
    .social-forced-link[data-platform="linkedin"] { background: #0A66C2 !important; }
    .social-forced-link[data-platform="whatsapp"] { background: #25D366 !important; }
    .social-forced-link[data-platform="telegram"] { background: #0088cc !important; }
    .social-forced-link[data-platform="threads"] { background: #000000 !important; }
</style>
