<?php
/**
 * إعدادات قاعدة البيانات
 * 
 * ملاحظة هامة: إذا ظهر لك خطأ "Unknown database 'tamer_fathy'"، 
 * فهذا يعني أنك بحاجة لإنشاء قاعدة بيانات بهذا الاسم في phpMyAdmin 
 * ثم استيراد ملف database.sql الموجود في المجلد الرئيسي للموقع.
 */

$host = 'localhost';
$db   = 'tamer_fathy'; // تأكد من إنشاء قاعدة بيانات بهذا الاسم في السيرفر
$user = 'root';
$pass = ''; // ضع كلمة مرور قاعدة البيانات هنا إذا وجدت
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

if (!isset($pdo)) {
    try {
         $pdo = new PDO($dsn, $user, $pass, $options);
         
         // إنشاء جدول شريط الأخبار تلقائياً إذا لم يكن موجوداً
         $pdo->exec("CREATE TABLE IF NOT EXISTS news_ticker (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title_ar VARCHAR(255) NOT NULL,
            title_en VARCHAR(255) DEFAULT NULL,
            link VARCHAR(255) DEFAULT NULL,
            is_active TINYINT(1) DEFAULT 1,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
         ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

         // إضافة حقول الترجمة الإنجليزية لجدول الإعدادات تلقائياً
         try {
            $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS site_title_en VARCHAR(255) DEFAULT NULL AFTER site_title");
            $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS hero_title_en VARCHAR(255) DEFAULT NULL AFTER hero_title");
            $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS hero_description_en TEXT DEFAULT NULL AFTER hero_description");
            $pdo->exec("ALTER TABLE settings ADD COLUMN IF NOT EXISTS footer_text_en TEXT DEFAULT NULL AFTER footer_text");
         } catch (Exception $e) { }

    } catch (\PDOException $e) {
         // عرض رسالة خطأ واضحة مع إرشادات الحل
         echo "<div style='direction:rtl; text-align:right; font-family:tahoma; padding:20px; border:2px solid red; background:#fff5f5;'>";
         echo "<h2 style='color:red;'>خطأ في الاتصال بقاعدة البيانات</h2>";
         echo "<p><b>السبب:</b> " . $e->getMessage() . "</p>";
         echo "<hr>";
         echo "<h3>كيفية حل المشكلة:</h3>";
         echo "<ol>";
         echo "<li>افتح <b>phpMyAdmin</b> في السيرفر الخاص بك.</li>";
         echo "<li>قم بإنشاء قاعدة بيانات جديدة باسم: <b style='color:blue;'>$db</b></li>";
         echo "<li>بعد إنشاء القاعدة، اضغط على تبويب <b>Import (استيراد)</b>.</li>";
         echo "<li>اختر ملف <b>database.sql</b> الموجود في مجلد الموقع الرئيسي واضغط Go.</li>";
         echo "<li>إذا كنت تستخدم بيانات اتصال مختلفة (اسم مستخدم أو كلمة مرور)، قم بتعديلها في ملف: <code>includes/db.php</code></li>";
         echo "</ol>";
         echo "</div>";
         exit;
    }
}

// حماية الدالة من التكرار
if (!function_exists('getSettings')) {
    function getSettings($pdo) {
        try {
            $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
            return $stmt->fetch();
        } catch (Exception $e) {
            return [];
        }
    }
}

// جلب الإعدادات مرة واحدة فقط
if (!isset($siteSettings)) {
    $siteSettings = getSettings($pdo);
}
?>
