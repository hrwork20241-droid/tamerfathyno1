<?php
/**
 * ملف مساعد قوي لجلب وتحليل RSS feeds مع دعم الترجمة التلقائية ونظام التخزين المؤقت
 * يستخدم cURL للتعامل مع القيود الشائعة
 * يدعم الترجمة من العربية إلى الإنجليزية تلقائياً مع حفظ النتائج في ذاكرة مؤقتة
 */

// تضمين ملف التخزين المؤقت
include_once __DIR__ . '/cache_helper.php';

// دالة ترجمة نصية بسيطة باستخدام Google Translate API (بدون مفتاح)
if (!function_exists('translateText')) {
    function translateText($text, $from_lang = 'ar', $to_lang = 'en') {
        if (empty($text) || strlen($text) < 2) {
            return $text;
        }
        
        // التحقق من الذاكرة المؤقتة للترجمة
        $cache_key = 'translate_' . md5($text . '_' . $from_lang . '_' . $to_lang);
        $cached_translation = getFromCache($cache_key, 86400); // 24 ساعة
        
        if ($cached_translation !== null) {
            return $cached_translation['text'];
        }
        
        // تجنب ترجمة النصوص الطويلة جداً (أكثر من 500 حرف)
        if (strlen($text) > 500) {
            $text = mb_substr($text, 0, 500) . '...';
        }
        
        try {
            // استخدام Google Translate API (الطريقة المجانية)
            $encoded_text = urlencode($text);
            $translate_url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl={$from_lang}&tl={$to_lang}&dt=t&q={$encoded_text}";
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $translate_url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            
            $result = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($http_code == 200 && !empty($result)) {
                // محاولة استخراج النص المترجم من الاستجابة
                $json = json_decode($result, true);
                if (is_array($json) && isset($json[0][0][0])) {
                    $translated = $json[0][0][0];
                    // حفظ الترجمة في الذاكرة المؤقتة
                    saveToCache($cache_key, ['text' => $translated]);
                    return $translated;
                }
            }
        } catch (Exception $e) {
            // في حالة الخطأ، نعيد النص الأصلي
        }
        
        // إذا فشلت الترجمة، نعيد النص الأصلي وحفظه في الذاكرة المؤقتة
        saveToCache($cache_key, ['text' => $text]);
        return $text;
    }
}

if (!function_exists('fetchRSSWithCurl')) {
    /**
     * جلب RSS feed باستخدام cURL مع معالجة محسّنة والترجمة التلقائية ونظام التخزين المؤقت
     */
    function fetchRSSWithCurl($url, $limit = 10, $lang = 'ar', $translate = false) {
        $items = [];
        
        // التحقق من الذاكرة المؤقتة أولاً
        $cache_key = 'rss_' . md5($url . '_' . $lang . '_' . $limit);
        $cached_items = getFromCache($cache_key, 3600); // الصلاحية ساعة واحدة
        
        if ($cached_items !== null) {
            return $cached_items;
        }
        
        try {
            // استخدام cURL لجلب المحتوى
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            
            $xml_content = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($http_code != 200 || !$xml_content) {
                return $items;
            }
            
            // تحويل المحتوى إلى XML
            $xml = @simplexml_load_string($xml_content);
            
            if (!$xml) {
                return $items;
            }
            
            $count = 0;
            foreach ($xml->channel->item as $item) {
                if ($count >= $limit) break;
                
                $title = (string)$item->title;
                $link = (string)$item->link;
                $pubDate = (string)$item->pubDate;
                $description = (string)$item->description;
                
                // ترجمة العنوان والوصف إذا كانت اللغة المطلوبة إنجليزية
                if ($translate && $lang == 'en') {
                    $title = translateText($title, 'ar', 'en');
                    $description = translateText($description, 'ar', 'en');
                }
                
                // استخراج الصورة بطرق متعددة
                $image = extractImageFromRSS($description, $url);
                
                // تنظيف الوصف
                $clean_desc = strip_tags($description);
                $clean_desc = mb_substr($clean_desc, 0, 150) . '...';
                
                $items[] = [
                    'title' => $title,
                    'link' => $link,
                    'date' => $pubDate,
                    'description' => $clean_desc,
                    'image' => $image,
                    'source' => parse_url($url, PHP_URL_HOST)
                ];
                $count++;
            }
            
            // حفظ النتائج في الذاكرة المؤقتة
            saveToCache($cache_key, $items);
            
        } catch (Exception $e) {
            // في حالة الخطأ، نعيد مصفوفة فارغة
            return [];
        }
        
        return $items;
    }
}

if (!function_exists('extractImageFromRSS')) {
    /**
     * استخراج الصورة من محتوى RSS بطرق متعددة
     */
    function extractImageFromRSS($description, $source_url = '') {
        // الطريقة 1: البحث عن وسم img مباشرة مع src
        if (preg_match('/<img[^>]+src=[\'"]([^\'"]+)[\'"][^>]*>/i', $description, $matches)) {
            $img_url = trim($matches[1]);
            if (!empty($img_url)) {
                return $img_url;
            }
        }
        
        // الطريقة 2: البحث عن أول رابط صورة (jpg, png, gif, webp)
        if (preg_match('/(https?:\/\/[^\s<>"{}|\\^`\[\]]*\.(jpg|jpeg|png|gif|webp))/i', $description, $matches)) {
            return trim($matches[0]);
        }
        
        // الطريقة 3: البحث عن media:content
        if (preg_match('/<media:content[^>]+url=[\'"]([^\'"]+)[\'"][^>]*>/i', $description, $matches)) {
            return trim($matches[1]);
        }
        
        // الطريقة 4: البحث عن media:thumbnail
        if (preg_match('/<media:thumbnail[^>]+url=[\'"]([^\'"]+)[\'"][^>]*>/i', $description, $matches)) {
            return trim($matches[1]);
        }
        
        // الطريقة 5: البحث عن أي رابط يبدأ بـ http ينتهي بصيغة صورة
        if (preg_match('/(https?:\/\/[^\s<>]+\.(jpg|jpeg|png|gif|webp))/i', $description, $matches)) {
            return trim($matches[0]);
        }
        
        // الطريقة 6: البحث عن روابط من موقع عالم التقنية المحددة
        if (strpos($source_url, 'tech-wd.com') !== false) {
            // محاولة استخراج من wp-content/uploads
            if (preg_match('/(https?:\/\/www\.tech-wd\.com\/wd\/wp-content\/uploads\/[^\s<>"\']+\.(jpg|jpeg|png|gif|webp))/i', $description, $matches)) {
                return trim($matches[0]);
            }
        }
        
        // الطريقة 7: البحث عن أي رابط يحتوي على /uploads/
        if (preg_match('/(https?:\/\/[^\s<>"\']*\/uploads\/[^\s<>"\']*\.(jpg|jpeg|png|gif|webp))/i', $description, $matches)) {
            return trim($matches[0]);
        }
        
        return '';
    }
}

if (!function_exists('fetchTickerNewsWithCurl')) {
    /**
     * جلب أخبار الشريط المتحرك مع دعم الترجمة التلقائية ونظام التخزين المؤقت
     */
    function fetchTickerNewsWithCurl($url, $limit = 10, $lang = 'ar', $translate = false) {
        $items = [];
        
        // التحقق من الذاكرة المؤقتة أولاً
        $cache_key = 'ticker_' . md5($url . '_' . $lang . '_' . $limit);
        $cached_items = getFromCache($cache_key, 3600); // الصلاحية ساعة واحدة
        
        if ($cached_items !== null) {
            return $cached_items;
        }
        
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            
            $xml_content = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($http_code != 200 || !$xml_content) {
                return $items;
            }
            
            $xml = @simplexml_load_string($xml_content);
            
            if (!$xml) {
                return $items;
            }
            
            $count = 0;
            foreach ($xml->channel->item as $item) {
                if ($count >= $limit) break;
                
                $title = (string)$item->title;
                $link = (string)$item->link;
                
                // ترجمة العنوان إذا كانت اللغة المطلوبة إنجليزية
                if ($translate && $lang == 'en') {
                    $title = translateText($title, 'ar', 'en');
                }
                
                $items[] = [
                    'title' => $title,
                    'link' => $link,
                ];
                $count++;
            }
            
            // حفظ النتائج في الذاكرة المؤقتة
            saveToCache($cache_key, $items);
            
        } catch (Exception $e) {
            return [];
        }
        
        return $items;
    }
}
?>
