<?php
/**
 * ملف مساعد لنظام التخزين المؤقت (Caching) للترجمة الآلية
 * يقوم بحفظ الأخبار المترجمة لمدة ساعة لتحسين الأداء
 */

if (!function_exists('getCacheDir')) {
    function getCacheDir() {
        $cache_dir = __DIR__ . '/../cache';
        if (!is_dir($cache_dir)) {
            @mkdir($cache_dir, 0755, true);
        }
        return $cache_dir;
    }
}

if (!function_exists('getCacheFile')) {
    function getCacheFile($key) {
        return getCacheDir() . '/' . md5($key) . '.cache';
    }
}

if (!function_exists('getFromCache')) {
    /**
     * جلب البيانات من الذاكرة المؤقتة
     */
    function getFromCache($key, $expiry = 3600) {
        $cache_file = getCacheFile($key);
        
        if (file_exists($cache_file)) {
            $cache_time = filemtime($cache_file);
            $current_time = time();
            
            // التحقق من انتهاء صلاحية الـ cache (افتراضياً ساعة واحدة)
            if (($current_time - $cache_time) < $expiry) {
                $cached_data = file_get_contents($cache_file);
                return json_decode($cached_data, true);
            } else {
                // حذف الملف المنتهي صلاحيته
                @unlink($cache_file);
            }
        }
        
        return null;
    }
}

if (!function_exists('saveToCache')) {
    /**
     * حفظ البيانات في الذاكرة المؤقتة
     */
    function saveToCache($key, $data) {
        $cache_file = getCacheFile($key);
        $json_data = json_encode($data);
        
        // حفظ البيانات في الملف
        @file_put_contents($cache_file, $json_data, LOCK_EX);
        
        // تعيين صلاحيات الملف
        @chmod($cache_file, 0644);
    }
}

if (!function_exists('clearCache')) {
    /**
     * حذف جميع ملفات الـ cache
     */
    function clearCache() {
        $cache_dir = getCacheDir();
        
        if (is_dir($cache_dir)) {
            $files = glob($cache_dir . '/*.cache');
            foreach ($files as $file) {
                if (is_file($file)) {
                    @unlink($file);
                }
            }
        }
    }
}

if (!function_exists('clearCacheByKey')) {
    /**
     * حذف ملف cache محدد
     */
    function clearCacheByKey($key) {
        $cache_file = getCacheFile($key);
        if (file_exists($cache_file)) {
            @unlink($cache_file);
        }
    }
}
?>
