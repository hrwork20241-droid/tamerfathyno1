<?php include 'includes/header_en.php'; ?>
<?php include 'includes/rss_helper.php'; ?>

<?php
// Set English language
$lang = 'en';

// جلب الأخبار المتحركة من قاعدة البيانات (النظام الجديد)
$ticker_news = [];
try {
    $ticker_news = $pdo->query("SELECT * FROM news_ticker WHERE is_active = 1 ORDER BY sort_order ASC, id DESC")->fetchAll();
} catch (Exception $e) { }

// جلب الاسم والوصف من الإعدادات العامة (Hero)
$hero_name = !empty($siteSettings['hero_title_en']) ? $siteSettings['hero_title_en'] : (!empty($siteSettings['hero_title']) ? $siteSettings['hero_title'] : 'Media Professional Tamer Fathy');
$hero_description = !empty($siteSettings['hero_description_en']) ? $siteSettings['hero_description_en'] : (!empty($siteSettings['hero_description']) ? $siteSettings['hero_description'] : 'Host of "Number One" on Al-Hadath Today Channel Distinguished Media Experience for Two Consecutive Seasons');

// جلب صورة الهيرو
$hero_img_src = '';
if (!empty($siteSettings['hero_image'])) {
    $hero_img_src = 'uploads/' . $siteSettings['hero_image'];
} else {
    $stmt_img = $pdo->query("SELECT image FROM about_me LIMIT 1");
    $about_img = $stmt_img->fetch();
    if (!empty($about_img['image'])) {
        $hero_img_src = 'uploads/' . $about_img['image'];
    }
}
?>

<!-- Hero Section -->
<section class="hero-section-white" style="background-color: #ffffff; padding: 40px 0; border-bottom: 1px solid #eee;">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-between g-0" style="min-height: 300px;">
            <div class="col-md-3 d-flex align-items-center justify-content-center" style="padding: 20px;">
                <?php if(!empty($siteSettings['site_logo'])): ?>
                    <img src="uploads/<?php echo $siteSettings['site_logo']; ?>" alt="Logo" class="img-fluid" style="max-width: 200px; max-height: 200px; object-fit: contain;">
                <?php else: ?>
                    <div class="bg-light rounded d-flex align-items-center justify-content-center" style="width: 200px; height: 200px; border: 2px dashed #ccc;">
                        <i class="fas fa-image fa-4x text-muted"></i>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-4 d-flex flex-column align-items-center justify-content-center text-center" style="padding: 20px;">
                <h1 class="display-5 fw-bold mb-3" style="color: #333; line-height: 1.3;">
                    <?php echo htmlspecialchars($hero_name); ?>
                </h1>
                <div style="color: #333; font-size: 1.2rem; line-height: 1.8; text-align: justify; text-align-last: center; font-weight: bold; max-width: 500px;">
                    <?php echo htmlspecialchars($hero_description); ?>
                </div>
            </div>
            <div class="col-md-3 d-flex align-items-center justify-content-center" style="padding: 20px;">
                <?php if(!empty($hero_img_src)): ?>
                    <img src="<?php echo $hero_img_src; ?>" class="img-fluid rounded-circle shadow-lg" alt="Tamer Fathy" style="width: 250px; height: 250px; object-fit: cover; border: 8px solid #f8f9fa;">
                <?php else: ?>
                    <div class="bg-light rounded-circle d-flex align-items-center justify-content-center shadow-sm" style="width: 250px; height: 250px; border: 2px dashed #ccc;">
                        <i class="fas fa-user-tie fa-6x text-muted"></i>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- News Ticker -->
<?php if (!empty($ticker_news)): ?>
<div class="news-ticker-section" style="background: #000000; color: white; padding: 12px 0; overflow: hidden; position: relative; width: 100%;">
    <div class="container-fluid">
        <div class="row align-items-center g-0">
            <div class="col-auto" style="flex-shrink: 0; padding-left: 15px;">
                <span class="badge bg-white text-dark fw-bold px-3 py-2" style="font-size: 0.9rem; white-space: nowrap;"><i class="fas fa-bolt me-1"></i> Latest News</span>
            </div>
            <div class="col" style="overflow: hidden; position: relative; min-height: 45px;">
                <div class="news-ticker-track" id="newsTickerEN" style="display: flex; white-space: nowrap; position: relative;">
                    <?php foreach ($ticker_news as $news): ?>
                        <?php 
                            $news_title = !empty($news['title_en']) ? $news['title_en'] : $news['title_ar'];
                            if (!empty($news['content_ar']) || !empty($news['content_en'])) {
                                $news_link = "news_detail.php?id=" . $news['id'] . "&lang=en";
                            } else {
                                $news_link = !empty($news['link']) ? $news['link'] : '#';
                            }
                        ?>
                        <a href="<?php echo htmlspecialchars($news_link); ?>" class="ticker-item" style="color: white; text-decoration: none; padding: 0 20px; display: inline-block; font-size: 0.95rem; flex-shrink: 0; line-height: 45px; font-weight: bold;">
                            <i class="fas fa-circle" style="font-size: 0.4rem; margin: 0 10px;"></i><?php echo htmlspecialchars($news_title); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    <style>
        .news-ticker-track { animation: ticker-scroll-en 20s linear infinite; }
        .news-ticker-section:hover .news-ticker-track { animation-play-state: paused; }
        .ticker-item:hover { color: #ffeb3b !important; text-decoration: underline; }
        @keyframes ticker-scroll-en { 0% { transform: translateX(0); } 100% { transform: translateX(-100%); } }
    </style>
</div>
<?php endif; ?>

<!-- قسم شارك معنا (مترجم بالإنجليزية) -->
<section class="participation-section py-5" style="background: linear-gradient(135deg, #D4AF37 0%, #FFD700 50%, #D4AF37 100%); color: #000; border-top: 4px solid #b8860b; border-bottom: 4px solid #b8860b;">
    <div class="container">
        <div class="row g-4 text-center">
            <div class="col-md-4">
                <div class="p-4 rounded h-100" style="background: rgba(255, 255, 255, 0.2); border: 1px solid rgba(0,0,0,0.1);">
                    <i class="fas fa-microphone-alt fa-3x mb-3"></i>
                    <h3 class="fw-bold h4 mb-3">Join as Guest</h3>
                    <p style="color: #000; font-size: 1rem; font-weight: bold; line-height: 1.8;">Welcome as a distinguished guest in our upcoming episodes</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-4 rounded h-100" style="background: rgba(255, 255, 255, 0.2); border: 1px solid rgba(0,0,0,0.1);">
                    <i class="fas fa-handshake fa-3x mb-3"></i>
                    <h3 class="fw-bold h4 mb-3">Join as Sponsor</h3>
                    <p style="color: #000; font-size: 1rem; font-weight: bold; line-height: 1.8;">Be a partner in our success and sponsor our program content</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-4 rounded h-100" style="background: rgba(255, 255, 255, 0.2); border: 1px solid rgba(0,0,0,0.1);">
                    <i class="fas fa-ad fa-3x mb-3"></i>
                    <h3 class="fw-bold h4 mb-3">Advertise with us</h3>
                    <p style="color: #000; font-size: 1rem; font-weight: bold; line-height: 1.8;">Great advertising opportunities to reach a wide audience</p>
                </div>
            </div>
        </div>
        <div class="text-center mt-5">
            <h4 class="fw-bold mb-4">Contact us on WhatsApp</h4>
            <?php if(!empty($siteSettings['whatsapp_number'])): ?>
                <a href="https://wa.me/<?php echo $siteSettings['whatsapp_number']; ?>" target="_blank" class="btn btn-dark btn-lg fw-bold px-5 py-3 shadow-lg" style="border-radius: 50px; background-color: #000;">
                    <i class="fab fa-whatsapp me-2" style="color: #25D366; font-size: 1.5rem;"></i> Chat Now
                </a>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Photo Gallery -->
<section class="py-5">
    <div class="container">
        <h2 class="section-title">Photo <span class="gold-text">Gallery</span></h2>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
        <style>
            .gallery-swiper-container { width: 100%; margin: 0 auto; padding: 20px 0; }
            .gallery-swiper { max-width: 100%; margin: 0 auto; position: relative; }
            .gallery-swiper .swiper-slide { display: flex; justify-content: center; align-items: center; padding: 10px; }
            .gallery-swiper .card { width: 100%; height: 350px; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1); transition: 0.3s; }
            .gallery-swiper .card:hover { box-shadow: 0 6px 30px rgba(0,0,0,0.15); }
            .gallery-swiper .card img { width: 100%; height: 280px; object-fit: cover; transition: 0.5s; }
            .gallery-swiper .card:hover img { transform: scale(1.08); }
            .gallery-swiper .card-body { padding: 15px; text-align: center; background: #f8f9fa; }
            .swiper-button-next, .swiper-button-prev { color: #fff; background: #cc0000; width: 50px; height: 50px; border-radius: 50%; box-shadow: 0 2px 8px rgba(0,0,0,0.3); top: 50%; transform: translateY(-50%); }
            .swiper-button-next:hover, .swiper-button-prev:hover { background: #990000; }
            .swiper-button-next::after, .swiper-button-prev::after { font-size: 20px; font-weight: bold; }
            .swiper-pagination { bottom: 10px !important; }
            .swiper-pagination-bullet { background: #cc0000; width: 12px; height: 12px; }
            .swiper-pagination-bullet-active { background: #990000; }
        </style>
        <div class="gallery-swiper-container">
        <div class="swiper gallery-swiper">
            <div class="swiper-wrapper">
                <?php
                $stmt = $pdo->query("SELECT * FROM gallery ORDER BY sort_order ASC LIMIT 12");
                while ($row = $stmt->fetch()) {
                    $title = !empty($row['title_en']) ? $row['title_en'] : $row['title'];
                ?>
                <div class="swiper-slide">
                    <div class="card border-0 shadow-sm overflow-hidden">
                        <img src="uploads/<?php echo $row['image']; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($title); ?>">
                        <div class="card-body">
                            <small class="fw-bold text-muted"><?php echo htmlspecialchars($title); ?></small>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-pagination"></div>
        </div>
        <div class="text-center mt-5">
            <a href="gallery.php?lang=en" class="btn btn-danger px-4 fw-bold" style="background-color: #cc0000; color: white; border: none;">View Full Gallery</a>
        </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script>
        const gallerySpeed = <?php echo intval($siteSettings['gallery_speed'] ?? 5000); ?>;
        const gallerySwiper = new Swiper('.gallery-swiper', {
            slidesPerView: 1,
            spaceBetween: 20,
            loop: true,
            autoplay: { delay: gallerySpeed, disableOnInteraction: false },
            pagination: { el: '.swiper-pagination', clickable: true },
            navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
            breakpoints: {
                640: { slidesPerView: 2 },
                1024: { slidesPerView: 3 }
            }
        });
    </script>
</section>

<!-- TV Programs -->
<section class="py-5">
    <div class="container">
        <h2 class="section-title">My TV <span class="gold-text">Programs</span></h2>
        <div class="row g-4">
            <?php
            $stmt = $pdo->query("SELECT * FROM programs ORDER BY sort_order ASC LIMIT 3");
            while ($row = $stmt->fetch()) {
                $title = !empty($row['title_en']) ? $row['title_en'] : $row['title'];
                $desc = !empty($row['description_en']) ? $row['description_en'] : $row['description'];
                $channel = !empty($row['channel_en']) ? $row['channel_en'] : $row['channel'];
            ?>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <img src="uploads/<?php echo $row['image']; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($title); ?>" style="height: 200px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title fw-bold text-danger"><?php echo htmlspecialchars($title); ?></h5>
                        <p class="card-text text-muted"><?php echo mb_substr(strip_tags($desc), 0, 100) . '...'; ?></p>
                        <div class="mt-2">
                            <span class="badge bg-dark">Channel: <?php echo htmlspecialchars($channel); ?></span>
                            <span class="badge bg-secondary">Seasons: <?php echo $row['seasons']; ?></span>
                        </div>
                        <?php if(!empty($row['video_url'])): ?>
                        <div class="mt-3">
                            <a href="<?php echo htmlspecialchars($row['video_url']); ?>" target="_blank" class="btn btn-danger w-100 fw-bold" style="background-color: #cc0000; border: none; transition: 0.3s;" onmouseover="this.style.backgroundColor='#990000'; this.style.transform='scale(1.02)';" onmouseout="this.style.backgroundColor='#cc0000'; this.style.transform='scale(1);">
                                <i class="fas fa-play me-2"></i>Watch Episode
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
        <div class="text-center mt-4">
            <a href="programs.php?lang=en" class="btn btn-danger px-4 fw-bold" style="background-color: #cc0000; color: white; border: none;">View All Programs</a>
        </div>
    </div>
</section>

<?php include 'includes/footer_en.php'; ?>
