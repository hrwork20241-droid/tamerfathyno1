<?php 
$lang = isset($_GET['lang']) && $_GET['lang'] == 'en' ? 'en' : 'ar';
if ($lang == 'en') {
    include 'includes/header_en.php';
} else {
    include 'includes/header.php';
}
?>

<section class="py-5 bg-light">
    <div class="container">
        <h2 class="section-title"><?php echo $lang == 'en' ? 'Frequently Asked <span class="gold-text">Questions</span>' : 'الأسئلة <span class="gold-text">الشائعة</span>'; ?></h2>
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="accordion shadow-sm" id="faqAccordion">
                    <?php
                    $stmt = $pdo->query("SELECT * FROM faqs");
                    $i = 0;
                    while ($row = $stmt->fetch()) {
                        $i++;
                        // عرض المحتوى بناءً على اللغة
                        $question = ($lang == 'en' && !empty($row['question_en'])) ? $row['question_en'] : $row['question'];
                        $answer = ($lang == 'en' && !empty($row['answer_en'])) ? $row['answer_en'] : $row['answer'];
                    ?>
                    <div class="accordion-item border-0 mb-3 shadow-sm rounded">
                        <h2 class="accordion-header" id="heading<?php echo $i; ?>">
                            <button class="accordion-button <?php echo $i == 1 ? '' : 'collapsed'; ?> fw-bold text-danger" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $i; ?>" aria-expanded="<?php echo $i == 1 ? 'true' : 'false'; ?>" aria-controls="collapse<?php echo $i; ?>">
                                <?php echo $question; ?>
                            </button>
                        </h2>
                        <div id="collapse<?php echo $i; ?>" class="accordion-collapse collapse <?php echo $i == 1 ? 'show' : ''; ?>" aria-labelledby="heading<?php echo $i; ?>" data-bs-parent="#faqAccordion">
                            <div class="accordion-body text-muted">
                                <?php echo $answer; ?>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
            <?php if ($stmt->rowCount() == 0): ?>
                <div class="col-12 text-center py-5">
                    <h4 class="text-muted"><?php echo $lang == 'en' ? 'FAQs coming soon...' : 'سيتم إضافة الأسئلة قريباً...'; ?></h4>
                </div>
            <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
if ($lang == 'en') {
    include 'includes/footer_en.php';
} else {
    include 'includes/footer.php';
}
?>
