-- =====================================================
-- Migration: إضافة حقول الوسائط لجدول الفعاليات
-- التاريخ: 2025
-- الإصدار: v69
-- =====================================================
-- قم بتشغيل هذا الملف مرة واحدة فقط إذا كان موقعك
-- يعمل بالفعل وتريد إضافة الحقول الجديدة فقط.
-- =====================================================

ALTER TABLE `events`
    ADD COLUMN IF NOT EXISTS `image`        VARCHAR(255) DEFAULT NULL COMMENT 'صورة الفعالية',
    ADD COLUMN IF NOT EXISTS `video_file`   VARCHAR(255) DEFAULT NULL COMMENT 'ملف فيديو الفعالية المرفوع',
    ADD COLUMN IF NOT EXISTS `video_url`    VARCHAR(255) DEFAULT NULL COMMENT 'رابط فيديو خارجي (YouTube وغيره)',
    ADD COLUMN IF NOT EXISTS `schedule_pdf` VARCHAR(255) DEFAULT NULL COMMENT 'PDF جدول الفعالية',
    ADD COLUMN IF NOT EXISTS `sort_order`   INT DEFAULT 0;
